# CV. CHALISTA EXPRESS – Aplikasi Pengiriman Barang

Aplikasi web berbasis PHP prosedural untuk manajemen pengiriman barang, dikembangkan dengan pendekatan **pemrograman terstruktur** (tanpa framework) untuk memudahkan pembelajaran dan pengembangan bisnis keluarga.

Dikembangkan oleh **Chalista Sasi Kirani** sebagai bagian dari proyek akademik dan pengembangan digital **CV. CHALISTA EXPRESS**.

---

## 🔧 Fitur Utama

- ✅ **Role-based access**: `admin` dan `customer`
- ✅ **CRUD Pengiriman**: Tambah, lihat, edit (oleh admin), dan lacak paket
- ✅ **Tracking Paket**:  
  - Halaman publik (`/tracking/`) – lacak via nomor resi  
  - Visualisasi lokasi real-time menggunakan **Leaflet + OpenStreetMap** (gratis, tanpa API key)
- ✅ **Auto-generate nomor resi**: Format `EXP20251126001`
- ✅ **Tampilan modern**: Bootstrap 5 + desain clean dengan warna biru dan oranye
- ✅ **Keamanan**:  
  - Password hashing (`password_hash`)  
  - CSRF protection  
  - Prepared statement (hindari SQL injection)  
  - Session security

---

## 📁 Struktur Proyek
