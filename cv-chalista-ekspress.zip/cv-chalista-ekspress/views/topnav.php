<?php
// Load role label for display
$menuConfig = loadMenuConfig();
$roleLabel = getRoleLabel($_SESSION['role'] ?? 'user');
?>

<nav class="navbar navbar-dark bg-primary sticky-top flex-md-nowrap shadow">
  <div class="container-fluid">
    <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="#">
      <strong>CHALISTA EXPRESS</strong>
    </a>
    <div class="navbar-nav">
      <div class="nav-item text-nowrap">
        <span class="nav-link text-white">
          Halo, <?= htmlspecialchars($_SESSION['username'] ?? 'User') ?>
          (<?= htmlspecialchars($roleLabel) ?>)
        </span>
      </div>
    </div>
  </div>
</nav>