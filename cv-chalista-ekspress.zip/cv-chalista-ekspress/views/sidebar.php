<?php
$menuConfig = loadMenuConfig();
?>

<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse">
  <div class="position-sticky pt-3">
    <ul class="nav flex-column">
      <!-- Modul dari menu.json -->
      <?php foreach ($menuConfig['modules'] ?? [] as $module => $config): ?>
        <?php if (userCanAccess($config['allowed_roles'])): ?>
          <li class="nav-item">
            <a class="nav-link text-white" href="../<?= $module ?>/index.php">
              <?= htmlspecialchars($config['label']) ?>
            </a>
          </li>
        <?php endif; ?>
      <?php endforeach; ?>

      <!-- Custom link: khusus customer, tambahkan "Buat Pengiriman" -->
      <?php if (getUserRole() === 'customer'): ?>
        <li class="nav-item">
          <a class="nav-link text-white" href="../customer/tambah.php">
            + Buat Pengiriman
          </a>
        </li>
      <?php endif; ?>

      <!-- Logout -->
      <li class="nav-item mt-3">
        <a class="nav-link text-white" href="../logout.php">
          🔙 Logout
        </a>
      </li>
    </ul>
  </div>
</nav>