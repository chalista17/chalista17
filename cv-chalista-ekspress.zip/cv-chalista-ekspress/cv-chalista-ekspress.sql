-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 29 Nov 2025 pada 12.38
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cv-chalista-ekspress`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengiriman`
--

CREATE TABLE `pengiriman` (
  `id` int(11) NOT NULL,
  `resi` varchar(50) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `alamat_pengirim` text NOT NULL,
  `nama_penerima` varchar(100) NOT NULL,
  `nomor_telepon` varchar(15) NOT NULL,
  `alamat_pengiriman` text NOT NULL,
  `kota_tujuan` varchar(100) NOT NULL,
  `berat_kg` decimal(5,2) DEFAULT NULL,
  `ongkos_kirim` decimal(10,2) NOT NULL DEFAULT 0.00,
  `jenis_barang` varchar(100) DEFAULT NULL,
  `status` enum('Pending','Diproses','Dikirim','Dalam Perjalanan','Tiba di Kota Tujuan','Diterima') DEFAULT 'Pending',
  `payment_status` enum('COD','Transfer') NOT NULL DEFAULT 'COD',
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pengiriman`
--

INSERT INTO `pengiriman` (`id`, `resi`, `customer_id`, `alamat_pengirim`, `nama_penerima`, `nomor_telepon`, `alamat_pengiriman`, `kota_tujuan`, `berat_kg`, `ongkos_kirim`, `jenis_barang`, `status`, `payment_status`, `latitude`, `longitude`, `created_at`) VALUES
(8, 'EXP20250008', 2, 'Plumbon-Cirebon', 'Fadhil', '08899001234', 'Jl. Dr. Setiabudi, isola', 'Bandung', 4.00, 80000.00, '0', 'Dalam Perjalanan', 'Transfer', NULL, NULL, '2025-11-27 16:20:47'),
(9, 'EXP20250009', 4, 'Depok-Cirebon, Jawa Barat', 'Ainul', '08229988776', 'Jatiwangi-Cikarang', 'Bekasi', 85.00, 1275000.00, '0', 'Pending', 'Transfer', NULL, NULL, '2025-11-27 16:59:07'),
(11, 'EXP20250011', 6, 'watubelah,cirebon', 'fitri', '08922334455', 'Summarecon Mall kelapa gading', 'Jakarta', 15.00, 225000.00, '0', 'Dalam Perjalanan', 'COD', NULL, NULL, '2025-11-28 13:33:35');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','customer') NOT NULL DEFAULT 'customer',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'admin', 'admin_chalista@ekspress.com', '$2a$12$y/pKmo3LrUKEHO0Q2vX38uoBtbrdZvH.WBn0/tp4TYW9OXGTkJGvu', 'admin', '2025-11-26 03:15:11'),
(2, 'kirani', 'kirani123@gmail.com', '$2y$10$KmxTlwEcbfRVvLZxHiyVnuqTzDp3dyxN7.322/bAKnr0KUG7KTZt6', 'customer', '2025-11-26 03:54:51'),
(3, 'anggi', 'anggi12@gmail.com', '$2y$10$O1lqtGwUXMfdCz3keMcniOONmaY9sPbW3jQRd1VVqmyzC/2wfyDqy', 'customer', '2025-11-26 06:49:13'),
(4, 'Alya Putri', 'Alyaputri11@gmail.com', '$2y$10$GkzbtiWugY.W5jHTcx0dAetKEYlMC0ETYD8mhZBMqApN9ncV7vUQy', 'customer', '2025-11-27 16:56:09'),
(5, 'aulia', 'aulia12@gmail.com', '$2y$10$.kWyTAsFI0ciTTjO7gw2Pu9beEaSH7AUZTHviSJ86twhul0AplaPO', 'customer', '2025-11-28 13:09:14'),
(6, 'bunga', 'bunga11@gmail.com', '$2y$10$1GF6FJQVuWOSNHGnT.K15.dkhA8DD0JKRx12p3U06sEHmYxpSwGrS', 'customer', '2025-11-28 13:30:32');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `pengiriman`
--
ALTER TABLE `pengiriman`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `resi` (`resi`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `pengiriman`
--
ALTER TABLE `pengiriman`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `pengiriman`
--
ALTER TABLE `pengiriman`
  ADD CONSTRAINT `pengiriman_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
