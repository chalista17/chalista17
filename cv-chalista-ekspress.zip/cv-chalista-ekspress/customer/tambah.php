<?php
session_start();
require_once '../lib/functions.php';
require_once '../lib/auth.php';

// Hanya customer yang bisa akses
requireAuth();
requireRoleAccess(['customer']);

require_once '../config/database.php';

$error = $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $alamat_pengirim = trim($_POST['alamat_pengirim'] ?? '');
    $nama_penerima = trim($_POST['nama_penerima'] ?? '');
    $nomor_telepon = trim($_POST['nomor_telepon'] ?? '');
    $alamat_pengiriman = trim($_POST['alamat_pengiriman'] ?? '');
    $kota_tujuan = trim($_POST['kota_tujuan'] ?? '');
    $berat_kg = (float)($_POST['berat_kg'] ?? 0);
    $jenis_barang = trim($_POST['jenis_barang'] ?? '');
    $payment_status = $_POST['payment_status'] ?? 'COD';

    // Validasi
    if (empty($alamat_pengirim) || empty($nama_penerima) || empty($nomor_telepon) || empty($alamat_pengiriman) || empty($kota_tujuan) || $berat_kg <= 0) {
        $error = "Semua field bertanda * wajib diisi.";
    } else {
        // Hitung ongkir otomatis
        $ongkos_kirim = hitungOngkir($kota_tujuan, $berat_kg);

        // Generate nomor resi
        $lastId = mysqli_fetch_assoc(mysqli_query($connection, "SELECT MAX(id) as last FROM pengiriman"));
        $nextId = ($lastId['last'] ?? 0) + 1;
        $resi = 'EXP' . date('Y') . sprintf('%04d', $nextId);

        // Simpan ke database
        $stmt = mysqli_prepare($connection, "
            INSERT INTO pengiriman(
                resi, customer_id, alamat_pengirim, nama_penerima,
                nomor_telepon, alamat_pengiriman, kota_tujuan,
                berat_kg, jenis_barang, ongkos_kirim, payment_status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        mysqli_stmt_bind_param(
            $stmt, "sissssssdss",
            $resi, $_SESSION['user_id'], $alamat_pengirim, $nama_penerima,
            $nomor_telepon, $alamat_pengiriman, $kota_tujuan,
            $berat_kg, $jenis_barang, $ongkos_kirim, $payment_status
        );

        if (mysqli_stmt_execute($stmt)) {
            $success = "Pengiriman berhasil dibuat!<br><strong>Resi:</strong> $resi<br><strong>Ongkos Kirim:</strong> Rp " . number_format($ongkos_kirim, 0, ',', '.');
        } else {
            $error = "Gagal menyimpan data.";
        }
        mysqli_stmt_close($stmt);
    }
}
?>

<?php include '../views/header.php'; ?>
<?php include '../views/topnav.php'; ?>
<div class="container-fluid">
  <div class="row">
    <?php include '../views/sidebar.php'; ?>
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
      <h2>Buat Pengiriman Baru</h2>
      <?php if ($error): ?>
        <?= showAlert($error, 'danger') ?>
      <?php endif; ?>
      <?php if ($success): ?>
        <?= showAlert($success, 'success') ?>
        <a href="index.php" class="btn btn-secondary">Lihat Daftar Pengiriman</a>
      <?php else: ?>
        <form method="POST">
          <div class="mb-3">
            <label class="form-label">Alamat Pengirim *</label>
            <textarea name="alamat_pengirim" class="form-control" rows="2" required></textarea>
          </div>
          <div class="mb-3">
            <label class="form-label">Nama Penerima *</label>
            <input type="text" name="nama_penerima" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Nomor Telepon *</label>
            <input type="text" name="nomor_telepon" class="form-control" required placeholder="081234567890">
          </div>
          <div class="mb-3">
            <label class="form-label">Alamat Tujuan *</label>
            <textarea name="alamat_pengiriman" class="form-control" rows="2" required></textarea>
          </div>
          <div class="mb-3">
            <label class="form-label">Kota Tujuan *</label>
            <input type="text" name="kota_tujuan" class="form-control" required placeholder="Contoh: Jakarta, Bandung">
          </div>
          <div class="mb-3">
            <label class="form-label">Jenis Barang</label>
            <input type="text" name="jenis_barang" class="form-control">
          </div>
          <div class="mb-3">
            <label class="form-label">Berat (kg) *</label>
            <input type="number" step="0.01" name="berat_kg" class="form-control" required min="0.1">
          </div>
          <div class="mb-3">
            <label class="form-label">Metode Pembayaran *</label>
            <select name="payment_status" class="form-select" required>
              <option value="COD">COD (Bayar di Tempat)</option>
              <option value="Transfer">Transfer</option>
            </select>
          </div>
          <button type="submit" class="btn btn-primary">Buat Pengiriman</button>
          <a href="index.php" class="btn btn-secondary">Batal</a>
        </form>
      <?php endif; ?>
    </main>
  </div>
</div>
<?php include '../views/footer.php'; ?>