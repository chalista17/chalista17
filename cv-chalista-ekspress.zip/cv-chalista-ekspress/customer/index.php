<?php
session_start();
require_once '../lib/functions.php';
require_once '../lib/auth.php';
requireAuth();
if (getUserRole() !== 'customer') {
    redirect('/login.php');
}

require_once '../config/database.php';

// Ambil hanya data pengiriman milik customer
$result = mysqli_query($connection, "
    SELECT * FROM pengiriman 
    WHERE customer_id = " . (int)$_SESSION['user_id'] . " 
    ORDER BY id DESC
");
?>

<?php include '../views/header.php'; ?>
<?php include '../views/topnav.php'; ?>

<style>
    .page-title {
        font-weight: 700;
        color: #0d6efd;
    }
    .table thead th {
        background: #0d6efd;
        color: white;
        border: none;
    }
    .table tbody tr:hover {
        background: #f8faff;
    }
    .btn-track {
        padding: 4px 14px;
        font-size: 13px;
        border-radius: 50px;
    }
</style>

<div class="container-fluid">
    <div class="row">

        <?php include '../views/sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">

            <h2 class="page-title mb-3">🚚 Pengiriman Saya</h2>
            <p class="mb-4">Halo, <strong><?= htmlspecialchars($_SESSION['username']) ?></strong>. Berikut daftar pengiriman milik Anda:</p>

            <?php if (mysqli_num_rows($result) > 0): ?>

                <div class="card shadow-sm border-0">
                    <div class="card-body">

                        <div class="table-responsive">
                            <table class="table table-hover table-bordered align-middle">
                                <thead>
                                    <tr>
                                        <th>Nama Penerima</th>
                                        <th>Status</th>
                                        <th>Payment</th>
                                        <th>Alamat Pengirim</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($row['nama_penerima']) ?></td>

                                            <td>
                                                <span class="badge 
                                                    <?php 
                                                        if ($row['status'] === 'Pending') echo 'bg-warning text-dark';
                                                        elseif ($row['status'] === 'Dikirim') echo 'bg-primary';
                                                        elseif ($row['status'] === 'Selesai') echo 'bg-success';
                                                        else echo 'bg-secondary';
                                                    ?>">
                                                    <?= htmlspecialchars($row['status']) ?>
                                                </span>
                                            </td>

                                            <td><?= $row['payment_status'] === 'COD' ? 'COD' : 'Transfer' ?></td>

                                            <td><?= htmlspecialchars($row['alamat_pengirim']) ?></td>

                                            <td>
                                                <a href="lihat.php?resi=<?= urlencode($row['resi']) ?>" 
                                                   class="btn btn-info btn-track">
                                                    Detail & Lacak
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>

            <?php else: ?>
                <div class="alert alert-info">Anda belum membuat pengiriman.</div>
            <?php endif; ?>

        </main>
    </div>
</div>

<?php include '../views/footer.php'; ?>
