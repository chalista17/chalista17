<?php
session_start();
require_once '../lib/functions.php';
require_once '../lib/auth.php';
requireAuth();
if (getUserRole() !== 'customer') {
    redirect('../login.php');
}

require_once '../config/database.php';

$resi = trim($_GET['resi'] ?? '');
if (!$resi) {
    redirect('index.php');
}

$stmt = mysqli_prepare($connection, "
    SELECT * FROM pengiriman 
    WHERE resi = ? AND customer_id = ?
");
mysqli_stmt_bind_param($stmt, "si", $resi, $_SESSION['user_id']);
mysqli_stmt_execute($stmt);
$shipment = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
mysqli_stmt_close($stmt);

if (!$shipment) {
    die("Pengiriman tidak ditemukan.");
}
?>

<?php include '../views/header.php'; ?>
<?php include '../views/topnav.php'; ?>
<div class="container-fluid">
  <div class="row">
    <?php include '../views/sidebar.php'; ?>
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
      <h2>Detail Pengiriman</h2>

      <!-- Informasi teks lengkap -->
      <div class="card mb-4">
        <div class="card-body">
          <p><strong>Resi:</strong> <?= htmlspecialchars($shipment['resi']) ?></p>
          <p><strong>Nama Penerima:</strong> <?= htmlspecialchars($shipment['nama_penerima']) ?></p>
          <p><strong>Nomor Telepon:</strong> <?= htmlspecialchars($shipment['nomor_telepon']) ?></p>
          <p><strong>Alamat Pengirim:</strong> <?= htmlspecialchars($shipment['alamat_pengirim']) ?></p>
          <p><strong>Alamat Tujuan:</strong> <?= htmlspecialchars($shipment['alamat_pengiriman']) ?></p>
          <p><strong>Kota Tujuan:</strong> <?= htmlspecialchars($shipment['kota_tujuan']) ?></p>
          <p><strong>Berat:</strong> <?= $shipment['berat_kg'] ?> kg</p>
          <p><strong>Ongkos Kirim:</strong> Rp <?= number_format($shipment['ongkos_kirim'], 0, ',', '.') ?></p>
          <p><strong>Status:</strong> <span class="badge bg-info"><?= htmlspecialchars($shipment['status']) ?></span></p>
          <p><strong>Metode Pembayaran:</strong> 
            <?= $shipment['payment_status'] === 'COD' ? 'COD (Bayar di Tempat)' : 'Transfer' ?>
          </p>
        </div>
      </div>

      <!-- Peta Tracking -->
      <div id="map" style="height: 400px; border-radius: 12px; margin-top: 1rem;"></div>

      <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />

<script>
  const lat = <?= $shipment['latitude'] ?: 'null' ?>;
  const lng = <?= $shipment['longitude'] ?: 'null' ?>;

  const cityCoordinates = {
    'CIREBON': [-6.735756, 108.559448],
    'JAKARTA': [-6.2088, 106.8456],
    'BANDUNG': [-6.9175, 107.6192],
    'SURABAYA': [-7.2575, 112.7525],
    'SEMARANG': [-6.9667, 110.4167]
  };

  const destinationCity = "<?= strtoupper($shipment['kota_tujuan']) ?>";
  const destinationCoords = cityCoordinates[destinationCity] || [-6.2, 106.8];

  // koordinat awal (paket kalau ada, kota tujuan jika tidak)
  const coords = (lat !== null && lng !== null) ? [lat, lng] : destinationCoords;

  // Inisialisasi map
  const map = L.map('map').setView(coords, 13);

  // TILE LAYER → ini yang bikin map tampil seperti OSM biasa
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap'
  }).addTo(map);

  // Marker paket
  if (lat !== null && lng !== null) {
      const packageMarker = L.marker([lat, lng]).addTo(map);
      packageMarker.bindPopup("Paket Anda saat ini di sini").openPopup();
  }

  // Marker tujuan
  const destinationMarker = L.marker(destinationCoords).addTo(map);
  destinationMarker.bindPopup(`Tujuan: ${destinationCity}`).openPopup();

  // Garis
  if (lat !== null && lng !== null) {
      const polyline = L.polyline([coords, destinationCoords], { color: 'blue' }).addTo(map);
      map.fitBounds(polyline.getBounds());
  }
</script>

      <a href="index.php" class="btn btn-secondary mt-3">Kembali ke Daftar</a>
    </main>
  </div>
</div>
<?php include '../views/footer.php'; ?>