@echo off
setlocal enabledelayedexpansion

echo Creating folder structure and files...

:: Create directories
mkdir admin
mkdir assets\css
mkdir assets\js
mkdir assets\images
mkdir config
mkdir lib
mkdir views

:: Create files in admin directory
type nul > admin\index.php

:: Create files in config directory
type nul > config\database.php
type nul > config\menu.json

:: Create files in lib directory
type nul > lib\auth.php
type nul > lib\functions.php

:: Create files in views directory
type nul > views\footer.php
type nul > views\header.php
type nul > views\sidebar.php
type nul > views\topnav.php

:: Create root directory files
type nul > .htaccess
type nul > .env
type nul > composer.json
type nul > index.php
type nul > login.php
type nul > logout.php
type nul > register.php

echo Folder structure and files created successfully!
pause