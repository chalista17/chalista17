<?php
require_once '../config/database.php';

$resi = trim($_GET['resi'] ?? '');
$shipment = null;

if ($resi) {
    $stmt = mysqli_prepare($connection, "SELECT * FROM pengiriman WHERE resi = ?");
    mysqli_stmt_bind_param($stmt, "s", $resi);
    mysqli_stmt_execute($stmt);
    $shipment = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Lacak Pengiriman - CV. CHALISTA EXPRESS</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
  <style>
    body { background: #f8fafc; }
    #map { height: 300px; border-radius: 12px; margin-top: 1rem; }
  </style>
</head>
<body class="bg-light">
  <div class="container py-5">
    <div class="card shadow-sm">
      <div class="card-header bg-primary text-white">
        <h4 class="mb-0">Lacak Pengiriman</h4>
      </div>
      <div class="card-body">
        <form method="GET" class="mb-4">
          <div class="input-group">
            <input type="text" name="resi" class="form-control" placeholder="Masukkan nomor resi (contoh: EXP20251126001)" value="<?= htmlspecialchars($resi) ?>" required>
            <button class="btn btn-primary" type="submit">Lacak</button>
          </div>
        </form>

        <?php if ($resi): ?>
          <?php if ($shipment): ?>
            <h5>Resi: <?= htmlspecialchars($shipment['resi']) ?></h5>
            <p><strong>Penerima:</strong> <?= htmlspecialchars($shipment['nama_penerima']) ?></p>
            <p><strong>Tujuan:</strong> <?= htmlspecialchars($shipment['kota_tujuan']) ?></p>
            <p><strong>Status:</strong> <span class="badge bg-info"><?= htmlspecialchars($shipment['status']) ?></span></p>

            <?php if ($shipment['latitude'] && $shipment['longitude']): ?>
              <div id="map"></div>
              <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
              <script>
                const map = L.map('map').setView([<?= $shipment['latitude'] ?>, <?= $shipment['longitude'] ?>], 13);
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                  attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                }).addTo(map);
                  .addTo(map)
                  .bindPopup("Paket Anda saat ini di sini")
                  .openPopup();
              </script>
            <?php else: ?>
              <div class="alert alert-warning">Lokasi paket belum tersedia.</div>
            <?php endif; ?>
          <?php else: ?>
            <div class="alert alert-danger">Resi tidak ditemukan.</div>
          <?php endif; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
</body>
</html>