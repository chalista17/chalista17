<?php
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 0); // Set to 1 in production with HTTPS
ini_set('session.use_strict_mode', 1);
session_start();

require_once 'lib/functions.php';
require_once 'lib/auth.php';

$error = $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        die('Invalid request. CSRF token mismatch.');
    }

    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($email) || empty($password)) {
        $error = "Semua field wajib diisi.";
    } else {
        // Nonaktifkan validasi password jika tidak diperlukan
        $passwordErrors = validatePassword($password, false); // false = bebas password
        if (!empty($passwordErrors)) {
            $error = implode(' ', $passwordErrors);
        } else {
            // Daftar sebagai customer saja
            if (registerUserWithEmail($username, $email, $password)) {
                $success = "Pendaftaran berhasil! Silakan login.";
            } else {
                $error = "Username atau email sudah terdaftar.";
            }
        }
    }
}

$csrfToken = generateCSRFToken();
?>

<style>
    body {
      margin: 0;
      padding: 0;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      font-family: 'Inter', sans-serif;

      /* Background modern ekspedisi */
      background: linear-gradient(135deg, rgba(30,64,175,0.85), rgba(59,130,246,0.85)),
                  url('https://cdn.pixabay.com/photo/2017/03/28/05/09/truck-2181037_640.png');
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
    }

    .login-box {
      background: rgba(255, 255, 255, 0.85);
      backdrop-filter: blur(10px);
      border-radius: 16px;
      padding: 2rem 2.2rem;
      width: 380px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.15);
      animation: fadeIn 0.8s ease-in-out;
    }

    .login-box h3 {
      text-align: center;
      font-weight: 700;
      color: #1e3a8a;
      margin-bottom: 1.5rem;
    }

    .form-control {
      border-radius: 8px;
    }

    .btn-primary {
      background: #1e3a8a;
      border: none;
      border-radius: 8px;
      font-weight: 600;
    }

    .btn-primary:hover {
      background: #1e40af;
    }

    .register-link {
      display: block;
      margin-top: 10px;
      text-align: center;
      font-size: 0.9rem;
    }

    /* Animasi */
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
</style>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Daftar - CV. Chalista Express</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container d-flex justify-content-center align-items-center min-vh-100">
        <div class="card p-4 shadow" style="width: 100%; max-width: 400px;">
            <h3 class="text-center mb-4">Daftar Customer</h3>
            <?php if ($error): ?>
                <?= showAlert($error, 'danger') ?>
            <?php endif; ?>
            <?php if ($success): ?>
                <?= showAlert($success, 'success') ?>
            <?php endif; ?>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES) ?>">

                <div class="mb-3">
                    <label class="form-label">Username</label>
                    <input type="text" name="username" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-success w-100">Daftar</button>
                <div class="text-center mt-3">
                    <a href="login.php">Sudah punya akun? Login</a>
                </div>
            </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>