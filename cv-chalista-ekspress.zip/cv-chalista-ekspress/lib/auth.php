<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';

/**
 * Authenticates user and sets session data.
 * Assumes session_start() was called BEFORE this function.
 */
function login($username, $password) {
    global $connection;
    $username = mysqli_real_escape_string($connection, sanitize($username));
    $sql = "SELECT id, username, password, role FROM users WHERE username = ?";
    $stmt = mysqli_prepare($connection, $sql);
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user = mysqli_fetch_assoc($result);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        mysqli_stmt_close($stmt);
        return $user['role'];
    }
    mysqli_stmt_close($stmt);
    return false;
}

function registerUser($username, $password, $role) {
    global $connection;

    // Get allowed roles from menu.json
    $menuConfig = loadMenuConfig();
    $allowedRoles = array_keys($menuConfig['roles'] ?? []);

    $username = mysqli_real_escape_string($connection, sanitize($username));
    $role = in_array($role, $allowedRoles) ? $role : 'mahasiswa';
    $hashedPass = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (username, password, role) VALUES (?, ?, ?)";
    $stmt = mysqli_prepare($connection, $sql);
    mysqli_stmt_bind_param($stmt, "sss", $username, $hashedPass, $role);
    $result = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    return $result;
}

function requireAuth() {
    if (!isset($_SESSION['user_id'])) {
        redirect('login.php');
    }
}

function hasRole($role) {
    return isset($_SESSION['role']) && $_SESSION['role'] === $role;
}

/**
 * Register user as 'customer' only (no role selection in form)
 * Compatible with table: users(username, email, password, role)
 */
function registerUserWithEmail($username, $email, $password) {
    global $connection;

    // Hanya role 'customer' yang diizinkan via register
    $role = 'customer';

    // Sanitize input
    $username = trim($username);
    $email = trim($email);
    $hashedPass = password_hash($password, PASSWORD_DEFAULT);

    // Validasi dasar
    if (empty($username) || empty($email)) {
        return false;
    }

    // Cek duplikat username atau email
    $check = mysqli_prepare($connection, "SELECT id FROM users WHERE username = ? OR email = ?");
    if (!$check) {
        return false;
    }
    mysqli_stmt_bind_param($check, "ss", $username, $email);
    mysqli_stmt_execute($check);
    $exists = mysqli_stmt_get_result($check);
    if (mysqli_num_rows($exists) > 0) {
        mysqli_stmt_close($check);
        return false;
    }
    mysqli_stmt_close($check);

    // Insert user baru
    $stmt = mysqli_prepare($connection, "INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
    if (!$stmt) {
        return false;
    }
    mysqli_stmt_bind_param($stmt, "ssss", $username, $email, $hashedPass, $role);
    $result = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    return $result;
}
?>