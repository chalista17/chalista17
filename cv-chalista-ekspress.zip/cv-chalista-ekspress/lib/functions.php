<?php

function sanitize($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

function redirect($url) {
    header("Location: " . $url);
    exit();
}

function showAlert($message, $type = 'danger') {
    $safeMessage = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');
    echo "<div class='alert alert-$type alert-dismissible fade show' role='alert'>
            $safeMessage
            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
          </div>";
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function getUserRole() {
    return $_SESSION['role'] ?? null;
}

// === CSRF Functions ===
function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function validateCSRFToken($token) {
    return hash_equals($_SESSION['csrf_token'] ?? '', $token);
}

function validatePassword($password, $enabled = true) {
    if (!$enabled) {
        return [];
    }

    $errors = [];
    if (strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters.";
    }
    if (!preg_match('/[A-Z]/', $password)) {
        $errors[] = "Password must contain at least one uppercase letter.";
    }
    if (!preg_match('/[a-z]/', $password)) {
        $errors[] = "Password must contain at least one lowercase letter.";
    }
    if (!preg_match('/[0-9]/', $password)) {
        $errors[] = "Password must contain at least one number.";
    }
    return $errors;
}

/**
 * Periksa apakah role pengguna termasuk dalam daftar yang diizinkan.
 * Default: hanya admin dan customer yang diizinkan (sesuai ekspedisi).
 */
function userCanAccess($allowedRoles = ['admin', 'customer']) {
    if (!isset($_SESSION['user_id'])) {
        return false;
    }
    $userRole = $_SESSION['role'] ?? '';
    return in_array($userRole, $allowedRoles);
}

/**
 * Tampilkan halaman "Akses Ditolak"
 */
function showAccessDenied($allowedRoles = ['admin', 'customer']) {
    $roleLabels = getRoleLabels();
    $allowedLabels = array_map(fn($r) => $roleLabels[$r] ?? $r, $allowedRoles);
    $allowedText = implode(' atau ', $allowedLabels);

    include __DIR__ . '/../views/header.php';
    include __DIR__ . '/../views/topnav.php';
    ?>
    <div class="container-fluid">
        <div class="row">
            <?php include __DIR__ . '/../views/sidebar.php'; ?>
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="alert alert-danger">
                    <h4>🔒 Akses Ditolak</h4>
                    <p>Halaman ini hanya dapat diakses oleh: <strong><?= htmlspecialchars($allowedText) ?></strong>.</p>
                    <p>Anda login sebagai <strong><?= htmlspecialchars(getRoleLabel($_SESSION['role'] ?? 'user')) ?></strong>.</p>
                    <a href="../<?= htmlspecialchars($_SESSION['role'] ?? 'login') ?>/index.php" class="btn btn-primary">Kembali ke Dashboard</a>
                </div>
            </main>
        </div>
    </div>
    <?php
    include __DIR__ . '/../views/footer.php';
    exit();
}

/**
 * Wajibkan akses berdasarkan role.
 * Default: hanya 'admin' dan 'customer' yang diizinkan.
 */
function requireRoleAccess($allowedRoles = ['admin', 'customer'], $redirectUrl = null) {
    if (!userCanAccess($allowedRoles)) {
        if ($redirectUrl) {
            redirect($redirectUrl);
        } else {
            showAccessDenied($allowedRoles);
        }
    }
}

/**
 * Muat konfigurasi menu dari config/menu.json
 */
function loadMenuConfig() {
    $configFile = __DIR__ . '/../config/menu.json';
    if (file_exists($configFile)) {
        $jsonContent = file_get_contents($configFile);
        return json_decode($jsonContent, true) ?: [];
    }
    return [];
}

/**
 * Dapatkan label tampilan role (misal: 'customer' → 'Customer')
 */
function getRoleLabel($role) {
    $menuConfig = loadMenuConfig();
    return $menuConfig['roles'][$role]['label'] ?? $role;
}

/**
 * Dapatkan semua label role
 */
function getRoleLabels() {
    $menuConfig = loadMenuConfig();
    $labels = [];
    foreach ($menuConfig['roles'] ?? [] as $role => $config) {
        $labels[$role] = $config['label'];
    }
    return $labels;
}
function redirectBasedOnRole($role) {
    $menuConfig = loadMenuConfig();

    if (isset($menuConfig['roles'][$role])) {
        $dashboard = $menuConfig['roles'][$role]['dashboard'] ?? 'login.php';
        header('Location: ' . $dashboard);
        exit();
    } else {
        header('Location: login.php');
        exit();
    }
}
function isJabodetabek($kota) {
    $jabodetabek = [
        'JAKARTA', 'BOGOR', 'DEPOK', 'TANGERANG', 'TANGERANG SELATAN', 'BEKASI',
        'JAKARTA PUSAT', 'JAKARTA UTARA', 'JAKARTA BARAT', 'JAKARTA SELATAN', 'JAKARTA TIMUR'
    ];
    return in_array(strtoupper(trim($kota)), $jabodetabek);
}

/**
 * Hitung ongkos kirim otomatis
 */
function hitungOngkir($kota_tujuan, $berat_kg) {
    $tarif = isJabodetabek($kota_tujuan) ? 15000 : 20000;
    return $tarif * $berat_kg;
}
?>