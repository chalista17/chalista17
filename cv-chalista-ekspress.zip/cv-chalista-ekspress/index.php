<?php
session_start();
require_once 'lib/functions.php';
require_once 'lib/auth.php';

// Jika sudah login → redirect ke dashboard
if (isset($_SESSION['user_id'])) {
    redirectBasedOnRole($_SESSION['role']);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CV. Chalista Express</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Google Font -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">

  <style>
    body {
      margin: 0;
      font-family: 'Inter', sans-serif;
      background: #f8fafc;
    }

    /* Navbar */
    .navbar-custom {
      padding: 1rem 2rem;
      background: #1e3a8a;
    }
    .navbar-custom a {
      color: white !important;
      font-weight: 600;
    }
    .btn-login {
      background: #fbbf24;
      color: #1e3a8a !important;
      font-weight: 700;
      padding: 10px 18px;
      border-radius: 10px;
      
    }

    /* Hero Section */
    .hero {
      background: linear-gradient(120deg, #1e3a8a, #3b82f6);
      padding: 80px 20px;
      color: white;
      text-align: center;
    }
    .hero h1 {
      font-size: 3rem;
      font-weight: 700;
    }
    .hero p {
      font-size: 1.25rem;
      opacity: 0.9;
    }
    .hero img {
      width: 260px;
      margin-top: 20px;
      animation: float 3s ease-in-out infinite;
    }

    @keyframes float {
      0% { transform: translateY(0px); }
      50% { transform: translateY(-10px); }
      100% { transform: translateY(0px); }
    }

    /* Feature Section */
    .features {
      padding: 60px 20px;
      text-align: center;
    }
    .feature-card {
      padding: 25px;
      background: white;
      border-radius: 16px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.07);
      transition: .3s;
    }
    .feature-card:hover {
      transform: translateY(-5px);
    }
    .feature-card img {
      width: 70px;
      margin-bottom: 15px;
    }

    /* Footer */
    .footer {
      text-align: center;
      padding: 20px;
      font-size: 0.9rem;
      color: #475569;
      background: #f1f5f9;
      margin-top: 40px;
    }
  </style>
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar navbar-custom navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand fw-bold" href="#">CV. Chalista Express</a>
    <div class="d-flex">
      <a href="login.php" class="btn-login">Login</a>
    </div>
  </div>
</nav>

<!-- HERO SECTION -->
<section class="hero">
  <h1>Pengiriman Cepat, Aman, dan Terpercaya</h1>
  <p style="font-size: 1.2rem;">"Dari Cirebon Untuk Seluruh Indonesia – Kirim Barang Jadi Lebih Mudah"</p>

  <div class="slideshow-container">
      <img id="slideImage" src="https://cdn.pixabay.com/photo/2017/03/28/05/09/truck-2181037_640.png" alt="Truck">
  </div>
</section>


<!-- FEATURES -->
<section class="features container">
  <h2 class="fw-bold mb-4">Kenapa Memilih Chalista Express?</h2>

  <div class="row g-4">
    <div class="col-md-4">
      <div class="feature-card">
        <img src="https://cdn-icons-png.flaticon.com/512/1048/1048953.png">
        <h5>Pengiriman Super Cepat</h5>
        <p class="text-muted">Barang Anda dikirim dengan estimasi waktu yang akurat & terpercaya.</p>
      </div>
    </div>

    <div class="col-md-4">
      <div class="feature-card">
        <img src="https://cdn-icons-png.flaticon.com/512/942/942751.png">
        <h5>Tracking Real-Time</h5>
        <p class="text-muted">Pantau perjalanan paket Anda kapan saja secara langsung.</p>
      </div>
    </div>

    <div class="col-md-4">
      <div class="feature-card">
        <img src="https://cdn-icons-png.flaticon.com/512/1040/1040223.png">
        <h5>Harga Terjangkau</h5>
        <p class="text-muted">Biaya pengiriman hemat tanpa mengurangi kualitas layanan.</p>
      </div>
    </div>
  </div>
</section>

<!-- FOOTER -->
<div class="footer">
  © <?= date('Y') ?> CV. Chalista Express — Cirebon, Indonesia  
</div>

<script>
  const images = [
    "https://cdn.pixabay.com/photo/2017/03/28/05/09/truck-2181037_640.png",
    "https://www.rakgudangheavyduty.com/wp-content/uploads/2023/12/ekspedisi-adalah3.png",
    "https://www.rakgudangheavyduty.com/wp-content/uploads/2023/12/ekspedisi-adalah.png",
    "https://www.linovhr.com/wp-content/uploads/10-Daftar-Perusahaan-Ekspedisi-Indonesia-Terpercaya-di-Indonesia.webp"
  ];

  let index = 0;
  const slideImg = document.getElementById("slideImage");

  setInterval(() => {
    index = (index + 1) % images.length;
    slideImg.src = images[index];
    slideImg.style.animation = "none"; // restart animation
    void slideImg.offsetWidth;        // trick untuk restart animasi
    slideImg.style.animation = "fadeSlide 1s ease-in-out";
  }, 3000);
</script>

</body>
</html>
