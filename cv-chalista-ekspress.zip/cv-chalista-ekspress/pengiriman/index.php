<?php
session_start();
require_once '../lib/functions.php';
require_once '../lib/auth.php';
requireAuth();
if (getUserRole() !== 'admin') {
    redirect('../login.php');
}

require_once '../config/database.php';

$result = mysqli_query($connection, "
    SELECT p.*, u.username AS customer_name 
    FROM pengiriman p 
    JOIN users u ON p.customer_id = u.id 
    ORDER BY p.id DESC
");
?>

<?php include '../views/header.php'; ?>
<?php include '../views/topnav.php'; ?>

<style>
    .page-title {
        font-weight: 700;
        color: #0d6efd;
    }
    .table thead th {
        background: #0d6efd;
        color: white;
        border: none;
    }
    .table tbody tr:hover {
        background: #f5f9ff;
    }
    .btn-action {
        padding: 4px 10px;
        font-size: 13px;
    }
</style>

<div class="container-fluid">
    <div class="row">

        <?php include '../views/sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">

            <h2 class="page-title mb-4">📦 Daftar Pengiriman</h2>
            <p class="mb-4">Selamat datang, <strong><?= htmlspecialchars($_SESSION['username']) ?></strong>. Berikut data seluruh pengiriman:</p>

            <?php if (mysqli_num_rows($result) > 0): ?>
                <div class="card shadow-sm border-0">
                    <div class="card-body">

                        <div class="table-responsive">
                            <table class="table table-hover table-bordered align-middle">
                                <thead>
                                    <tr>
                                        <th>Nama Penerima</th>
                                        <th>Ongkir</th>
                                        <th>Status</th>
                                        <th>Payment</th>
                                        <th>Alamat Pengirim</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($row['nama_penerima']) ?></td>
                                        <td>Rp <?= number_format($row['ongkos_kirim'], 0, ',', '.') ?></td>
                                        <td><span class="badge bg-info"><?= htmlspecialchars($row['status']) ?></span></td>
                                        <td><?= $row['payment_status'] === 'COD' ? 'COD' : 'Transfer' ?></td>
                                        <td><?= htmlspecialchars($row['alamat_pengirim']) ?></td>
                                        <td>
                                            <a href="detail.php?resi=<?= urlencode($row['resi']) ?>" class="btn btn-info btn-action">Detail</a>
                                            <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-action">Edit</a>
                                            <a href="delete.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-action"
                                               onclick="return confirm('Yakin hapus data ini?')">Hapus</a>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>

            <?php else: ?>
                <div class="alert alert-info">Belum ada pengiriman.</div>
            <?php endif; ?>

        </main>
    </div>
</div>

<?php include '../views/footer.php'; ?>
