<?php
session_start();
require_once '../lib/functions.php';
require_once '../lib/auth.php';
requireAuth();
if (getUserRole() !== 'admin') {
    redirect('../login.php');
}

require_once '../config/database.php';

$resi = trim($_GET['resi'] ?? '');
if (!$resi) {
    redirect('index.php');
}

$stmt = mysqli_prepare($connection, "SELECT p.*, u.username AS customer_name FROM pengiriman p JOIN users u ON p.customer_id = u.id WHERE p.resi = ?");
mysqli_stmt_bind_param($stmt, "s", $resi);
mysqli_stmt_execute($stmt);
$shipment = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
mysqli_stmt_close($stmt);

if (!$shipment) {
    die("Pengiriman tidak ditemukan.");
}
?>

<?php include '../views/header.php'; ?>
<?php include '../views/topnav.php'; ?>
<div class="container-fluid">
  <div class="row">
    <?php include '../views/sidebar.php'; ?>
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
      <h2 class="mb-4 fw-bold">Detail Pengiriman</h2>

<div class="card shadow-sm border-0 rounded-4 mb-4">
  <div class="card-body">

    <div class="row">
      <div class="col-md-6 mb-3">
        <label class="text-muted fw-semibold">Resi</label>
        <div class="fs-5 fw-bold"><?= htmlspecialchars($shipment['resi']) ?></div>
      </div>

      <div class="col-md-6 mb-3">
        <label class="text-muted fw-semibold">Nama Penerima</label>
        <div class="fw-semibold"><?= htmlspecialchars($shipment['nama_penerima']) ?></div>
      </div>

      <div class="col-md-6 mb-3">
        <label class="text-muted fw-semibold">Nomor Telepon</label>
        <div><?= htmlspecialchars($shipment['nomor_telepon']) ?></div>
      </div>

      <div class="col-md-6 mb-3">
        <label class="text-muted fw-semibold">Customer</label>
        <div><?= htmlspecialchars($shipment['customer_name']) ?></div>
      </div>

      <div class="col-md-6 mb-3">
        <label class="text-muted fw-semibold">Alamat Tujuan</label>
        <div><?= htmlspecialchars($shipment['alamat_pengiriman']) ?></div>
      </div>

      <div class="col-md-6 mb-3">
        <label class="text-muted fw-semibold">Kota Tujuan</label>
        <div><?= htmlspecialchars($shipment['kota_tujuan']) ?></div>
      </div>

      <div class="col-md-6 mb-3">
        <label class="text-muted fw-semibold">Ongkos Kirim</label>
        <div>Rp <?= number_format($shipment['ongkos_kirim'], 0, ',', '.') ?></div>
      </div>

      <div class="col-md-6 mb-3">
        <label class="text-muted fw-semibold">Status</label><br>
        <span class="badge bg-info px-3 py-2 rounded-pill">
          <?= htmlspecialchars($shipment['status']) ?>
        </span>
      </div>

      <div class="col-md-6 mb-3">
        <label class="text-muted fw-semibold">Metode Pembayaran</label>
        <div><?= $shipment['payment_status'] === 'COD' ? 'COD (Bayar di Tempat)' : 'Transfer' ?></div>
      </div>

      <?php if (isset($shipment['payment_status'])): ?>
      <div class="col-md-6 mb-3">
        <label class="text-muted fw-semibold">Payment Status</label>
        <div><?= htmlspecialchars($shipment['payment_status']) ?></div>
      </div>
      <?php endif; ?>
    </div>

  </div>
</div>
      </div><div id="map" style="height: 300px; border-radius: 12px; margin-top: 1rem;"></div>

        <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />

<script>
  const lat = <?= $shipment['latitude'] ?: 'null' ?>;
  const lng = <?= $shipment['longitude'] ?: 'null' ?>;

  const cityCoordinates = {
    'CIREBON': [-6.735756, 108.559448],
    'JAKARTA': [-6.2088, 106.8456],
    'BANDUNG': [-6.9175, 107.6192],
    'SURABAYA': [-7.2575, 112.7525],
    'SEMARANG': [-6.9667, 110.4167]
  };

  const destinationCity = "<?= strtoupper($shipment['kota_tujuan']) ?>";
  const destinationCoords = cityCoordinates[destinationCity] || [-6.2, 106.8];

  // koordinat awal (paket kalau ada, kota tujuan jika tidak)
  const coords = (lat !== null && lng !== null) ? [lat, lng] : destinationCoords;

  // Inisialisasi map
  const map = L.map('map').setView(coords, 13);

  // TILE LAYER → ini yang bikin map tampil seperti OSM biasa
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap'
  }).addTo(map);

  // Marker paket
  if (lat !== null && lng !== null) {
      const packageMarker = L.marker([lat, lng]).addTo(map);
      packageMarker.bindPopup("Paket Anda saat ini di sini").openPopup();
  }

  // Marker tujuan
  const destinationMarker = L.marker(destinationCoords).addTo(map);
  destinationMarker.bindPopup(`Tujuan: ${destinationCity}`).openPopup();

  // Garis
  if (lat !== null && lng !== null) {
      const polyline = L.polyline([coords, destinationCoords], { color: 'blue' }).addTo(map);
      map.fitBounds(polyline.getBounds());
  }
</script>

      <a href="index.php" class="btn btn-secondary">Kembali ke Daftar</a>
      <a href="edit.php?id=<?= $shipment['id'] ?>" class="btn btn-primary">Edit</a>
    </main>
  </div>
</div>
<?php include '../views/footer.php'; ?>