<?php
session_start();
require_once '../lib/functions.php';
require_once '../lib/auth.php';
requireAuth();
requireRoleAccess(['admin']); // Hanya admin

require_once '../config/database.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) redirect('index.php');

$stmt = mysqli_prepare($connection, "SELECT * FROM pengiriman WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$shipment = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
mysqli_stmt_close($stmt);

if (!$shipment) redirect('index.php');

$error = $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $status = $_POST['status'] ?? 'Pending';
    $lat = !empty($_POST['latitude']) ? $_POST['latitude'] : null;
    $lng = !empty($_POST['longitude']) ? $_POST['longitude'] : null;

    $stmt = mysqli_prepare($connection, "UPDATE pengiriman SET status = ?, latitude = ?, longitude = ? WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "sssi", $status, $lat, $lng, $id);

    if (mysqli_stmt_execute($stmt)) {
        $success = "Status pengiriman berhasil diperbarui.";
        // Refresh data
        mysqli_stmt_close($stmt);
        $stmt = mysqli_prepare($connection, "SELECT * FROM pengiriman WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
        $shipment = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    } else {
        $error = "Gagal memperbarui: " . mysqli_error($connection);
    }
    mysqli_stmt_close($stmt);
}
?>

<?php include '../views/header.php'; ?>
<?php include '../views/topnav.php'; ?>
<div class="container-fluid">
  <div class="row">
    <?php include '../views/sidebar.php'; ?>
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
      <h2>Edit Pengiriman: <?= htmlspecialchars($shipment['resi']) ?></h2>
      <?php if ($error): ?>
        <?= showAlert($error, 'danger') ?>
      <?php endif; ?>
      <?php if ($success): ?>
        <?= showAlert($success, 'success') ?>
      <?php endif; ?>
      <form method="POST">
        <div class="mb-3">
          <label class="form-label">Status Saat Ini</label>
          <select name="status" class="form-select">
            <?php $statuses = ['Pending','Diproses','Dikirim','Dalam Perjalanan','Tiba di Kota Tujuan','Diterima']; ?>
            <?php foreach ($statuses as $s): ?>
              <option value="<?= $s ?>" <?= $shipment['status'] === $s ? 'selected' : '' ?>><?= $s ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="row">
          <div class="col-md-6">
            <div class="mb-3">
              <label class="form-label">Latitude (Opsional)</label>
              <input type="number" step="0.00000001" name="latitude" class="form-control" value="<?= $shipment['latitude'] ?>">
            </div>
          </div>
          <div class="col-md-6">
            <div class="mb-3">
              <label class="form-label">Metode Pembayaran</label>
              <select name="payment_status" class="form-select" required>
                <option value="COD" <?= $shipment['payment_status'] === 'COD' ? 'selected' : '' ?>>COD (Bayar di Tempat)</option>
                <option value="Transfer" <?= $shipment['payment_status'] === 'Transfer' ? 'selected' : '' ?>>Transfer</option>
              </select>
            </div>
            <div class="mb-3">
              <label class="form-label">Longitude (Opsional)</label>
              <input type="number" step="0.00000001" name="longitude" class="form-control" value="<?= $shipment['longitude'] ?>">
            </div>
          </div>
        </div>
        <button type="submit" class="btn btn-primary">Perbarui</button>
        <a href="index.php" class="btn btn-secondary">Batal</a>
      </form>
    </main>
  </div>
</div>
<?php include '../views/footer.php'; ?>