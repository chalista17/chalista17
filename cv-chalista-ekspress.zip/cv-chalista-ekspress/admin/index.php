<?php
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 0); // atur nilai menjadi 1 jika di publish ke real public server
ini_set('session.use_strict_mode', 1);

session_start();
require_once '../lib/auth.php';
require_once '../lib/functions.php';
requireAuth();

if (getUserRole() !== 'admin') {
    redirect('/login.php');
}
?>

<?php include '../views/header.php'; ?>
<?php include '../views/topnav.php'; ?>

<div class="container-fluid">
    <div class="row">
        <?php include '../views/sidebar.php'; ?>
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <h2>Welcome, <?= ucfirst($_SESSION['role']); ?>!</h2>
            <p>You are logged in as: <strong><?= $_SESSION['username']; ?></strong></p>
            <a href="../logout.php" class="btn btn-outline-danger">Logout</a>
        </main>
    </div>
</div>

<?php include '../views/footer.php'; ?>