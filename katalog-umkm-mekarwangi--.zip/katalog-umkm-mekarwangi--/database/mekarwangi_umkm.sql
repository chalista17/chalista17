-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 30 Agu 2026 pada 08.32
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mekarwangi_umkm`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE `kategori` (
  `id` int(11) NOT NULL,
  `nama_kategori` varchar(50) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `icon` varchar(50) DEFAULT 'fa-store',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`id`, `nama_kategori`, `deskripsi`, `icon`, `created_at`) VALUES
(1, 'Makanan & Minuman', 'Usaha di bidang makanan dan minuman olahan', 'fa-utensils', '2026-08-30 06:09:38'),
(2, 'Pertanian', 'Usaha di bidang pertanian dan perkebunan', 'fa-seedling', '2026-08-30 06:09:38'),
(3, 'Kerajinan', 'Usaha kerajinan tangan dan seni', 'fa-hand-sparkles', '2026-08-30 06:09:38'),
(4, 'Perdagangan', 'Usaha perdagangan barang dan jasa', 'fa-store', '2026-08-30 06:09:38'),
(5, 'Jasa', 'Usaha jasa dan pelayanan', 'fa-handshake', '2026-08-30 06:09:38'),
(6, 'Lainnya', 'Usaha lainnya', 'fa-ellipsis-h', '2026-08-30 06:09:38');

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `id` int(11) NOT NULL,
  `umkm_id` int(11) DEFAULT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `harga` decimal(10,2) DEFAULT NULL,
  `foto` varchar(255) DEFAULT 'default-produk.jpg',
  `status` enum('tersedia','tidak_tersedia') DEFAULT 'tersedia',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`id`, `umkm_id`, `nama_produk`, `deskripsi`, `harga`, `foto`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'Parered Original', 'Parered khas dengan rasa gurih dan renyah, dibuat dengan resep turun-temurun', 500.00, 'parered-original.jpg', 'tersedia', '2026-08-30 06:09:39', '2026-08-30 06:09:39'),
(2, 1, 'Parered Pedas', 'Parered dengan cita rasa pedas yang menggugah selera', 500.00, 'parered-pedas.jpg', 'tersedia', '2026-08-30 06:09:39', '2026-08-30 06:09:39'),
(3, 1, 'Parered Keju', 'Parered dengan taburan keju yang gurih', 600.00, 'parered-keju.jpg', 'tersedia', '2026-08-30 06:09:39', '2026-08-30 06:09:39'),
(4, 2, 'Rengginang Kecil', 'Rengginang ukuran kecil, renyah dan gurih', 6000.00, 'rengginang-kecil.jpg', 'tersedia', '2026-08-30 06:09:39', '2026-08-30 06:09:39'),
(5, 2, 'Rengginang Sedang', 'Rengginang ukuran sedang, renyah dan gurih', 12000.00, 'rengginang-sedang.jpg', 'tersedia', '2026-08-30 06:09:39', '2026-08-30 06:09:39'),
(6, 2, 'Rengginang Besar', 'Rengginang ukuran besar, renyah dan gurih', 25000.00, 'rengginang-besar.jpg', 'tersedia', '2026-08-30 06:09:39', '2026-08-30 06:09:39'),
(7, 3, 'Rempeyek Kecil', 'Rempeyek ukuran kecil dengan topping kacang tanah', 6000.00, 'rempeyek-kecil.jpg', 'tersedia', '2026-08-30 06:09:39', '2026-08-30 06:09:39'),
(8, 3, 'Rempeyek Sedang', 'Rempeyek ukuran sedang dengan topping kacang tanah', 12000.00, 'rempeyek-sedang.jpg', 'tersedia', '2026-08-30 06:09:39', '2026-08-30 06:09:39'),
(9, 3, 'Rempeyek Besar', 'Rempeyek ukuran besar dengan topping kacang tanah', 25000.00, 'rempeyek-besar.jpg', 'tersedia', '2026-08-30 06:09:39', '2026-08-30 06:09:39'),
(10, 4, 'Gabin Tape Original', 'Gabin dengan isian tape singkong manis', 200000.00, 'gabin-original.jpg', 'tersedia', '2026-08-30 06:09:39', '2026-08-30 06:09:39'),
(11, 4, 'Gabin Tape Keju', 'Gabin dengan isian tape dan taburan keju', 220000.00, 'gabin-keju.jpg', 'tersedia', '2026-08-30 06:09:39', '2026-08-30 06:09:39');

-- --------------------------------------------------------

--
-- Struktur dari tabel `umkm`
--

CREATE TABLE `umkm` (
  `id` int(11) NOT NULL,
  `nama_usaha` varchar(100) NOT NULL,
  `pemilik` varchar(100) NOT NULL,
  `kategori_id` int(11) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `no_whatsapp` varchar(20) DEFAULT NULL,
  `instagram` varchar(100) DEFAULT NULL,
  `google_maps` text DEFAULT NULL,
  `foto` varchar(255) DEFAULT 'default-umkm.jpg',
  `status` enum('aktif','tidak_aktif') DEFAULT 'aktif',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `umkm`
--

INSERT INTO `umkm` (`id`, `nama_usaha`, `pemilik`, `kategori_id`, `deskripsi`, `alamat`, `no_whatsapp`, `instagram`, `google_maps`, `foto`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Parered Ma Ambang', 'Ibu Asih', 1, 'Parered Ibu Ma Ambang adalah camilan tradisional khas yang dibuat dengan bahan-bahan pilihan dan diolah secara higienis sehingga menghasilkan rasa gurih dan renyah yang khas. Dibuat dengan resep turun-temurun, parered ini memiliki cita rasa autentik yang cocok dinikmati semua kalangan.', 'Blok Minggu RT.02/RW.02, Desa Mekarwangi, Kecamatan Argapura, Kab. Majalengka, Jawa Barat', '085320377426', '@parered_maambang', 'https://maps.google.com/?q=-6.9833,108.3667', 'parered.jpg', 'aktif', '2026-08-30 06:09:39', '2026-08-30 06:09:39'),
(2, 'Rengginang Ibu Titin', 'Ibu Titin', 1, 'Rengginang Ibu Titin - Gurihnya Bikin Nagih! Dibuat dari beras ketan pilihan dengan resep tradisional khas Desa Mekarwangi, rengginang ini punya tekstur super renyah dan rasa gurih otentik tanpa bahan pengawet. Cocok jadi camilan santai maupun oleh-oleh khas desa.', 'Blok Rebo RT.01/RW.01, Desa Mekarwangi, Kecamatan Argapura, Kab. Majalengka, Jawa Barat', '089116959119', '@rengginang_titin', 'https://maps.google.com/?q=-6.9833,108.3667', 'rengginang.jpg', 'aktif', '2026-08-30 06:09:39', '2026-08-30 06:09:39'),
(3, 'Rempeyek Ibu Titin', 'Ibu Titin', 1, 'Rempeyek Ibu Titin dibuat dengan bahan pilihan dan bumbu tradisional yang kaya rasa. Gurih, renyah, dan wangi rempahnya bikin setiap gigitan nagih. Tanpa bahan pengawet, cocok dijadikan camilan keluarga maupun oleh-oleh khas yang selalu bikin kangen.', 'Blok Rebo RT.01/RW.01, Desa Mekarwangi, Kecamatan Argapura, Kab. Majalengka, Jawa Barat', '089116959119', '@rempeyek_titin', 'https://maps.google.com/?q=-6.9833,108.3667', 'rempeyek.jpg', 'aktif', '2026-08-30 06:09:39', '2026-08-30 06:09:39'),
(4, 'Gabin Ibu Yayah', 'Ibu Yayah', 1, 'Gabin Ibu Yayah adalah camilan olahan singkong (tape) yang dipadukan dengan biskuit gabin, menghasilkan camilan renyah berlapis dengan isian manis khas singkong. Usaha ini dirintis oleh Bapak Yon Cahyono bersama Ibu Yayah dari Desa Mekarwangi sejak tahun 2015.', 'Desa Mekarwangi, Kecamatan Argapura, Kab. Majalengka, Jawa Barat', '085320377426', '@gabin_yayah', 'https://maps.google.com/?q=-6.9833,108.3667', 'gabin.jpg', 'aktif', '2026-08-30 06:09:39', '2026-08-30 06:09:39');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`) VALUES
(1, 'admin', '$2a$12$6RS6hzhMs.rFSsKJLFouneeTcMWada72Iusv1AFOQFYOAnvwO6D9K', '2026-08-30 06:09:39');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id`),
  ADD KEY `umkm_id` (`umkm_id`);

--
-- Indeks untuk tabel `umkm`
--
ALTER TABLE `umkm`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kategori_id` (`kategori_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `produk`
--
ALTER TABLE `produk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `umkm`
--
ALTER TABLE `umkm`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD CONSTRAINT `produk_ibfk_1` FOREIGN KEY (`umkm_id`) REFERENCES `umkm` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `umkm`
--
ALTER TABLE `umkm`
  ADD CONSTRAINT `umkm_ibfk_1` FOREIGN KEY (`kategori_id`) REFERENCES `kategori` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
