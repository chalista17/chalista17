<?php
// includes/footer.php - Footer untuk semua halaman frontend
// PASTIKAN TIDAK ADA SESSION_START() ATAU REDIRECT

// Tentukan base URL
$base_url = '';
if (strpos($_SERVER['SCRIPT_NAME'], '/admin/') !== false) {
    $base_url = '../';
} else {
    $base_url = '';
}
?>
    </main>
    
    <!-- Footer -->
    <footer class="footer" id="kontak">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-4">
                    <div class="d-flex align-items-center gap-2">
                        <!-- GANTI LOGO PADI MENJADI DAUN/CENGKEH -->
                        <span class="brand-icon" style="font-size: 30px;">🌿</span>
                        <span class="brand-title" style="color: #F6D365;">Mekarwangi</span>
                    </div>
                    <p class="footer-desc">
                        Katalog UMKM Desa Mekarwangi adalah platform digital untuk mempromosikan 
                        dan mendukung usaha mikro, kecil, dan menengah di Desa Mekarwangi.
                    </p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-youtube"></i></a>
                        <a href="#"><i class="fab fa-tiktok"></i></a>
                        <a href="#"><i class="fab fa-facebook"></i></a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4">
                    <h5>Menu</h5>
                    <ul>
                        <li><a href="<?php echo $base_url; ?>index.php">Beranda</a></li>
                        <li><a href="<?php echo $base_url; ?>umkm.php">UMKM</a></li>
                        <li><a href="<?php echo $base_url; ?>index.php#tentang">Tentang Desa</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-4">
                    <h5>Kontak</h5>
                    <ul>
                        <li><i class="fas fa-map-marker-alt"></i> Desa Mekarwangi, Argapura</li>
                        <li><i class="fas fa-envelope"></i> info@mekarwangi.id</li>
                        <li><i class="fas fa-phone"></i> +62 8123456789</li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-4">
                    <h5>Jam Layanan</h5>
                    <ul>
                        <li>Senin - Jumat: 08:00 - 16:00</li>
                        <li>Sabtu: 08:00 - 12:00</li>
                        <li>Minggu: Tutup</li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                &copy; <?php echo date('Y'); ?> Katalog UMKM Desa Mekarwangi
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script src="<?php echo $base_url; ?>assets/js/script.js"></script>
</body>
</html>