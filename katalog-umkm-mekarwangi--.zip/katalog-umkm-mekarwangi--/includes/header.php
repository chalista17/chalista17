<?php
// includes/header.php - Header untuk semua halaman frontend
// PASTIKAN TIDAK ADA SESSION_START() ATAU REDIRECT

// Tentukan base URL
$base_url = '';
if (strpos($_SERVER['SCRIPT_NAME'], '/admin/') !== false) {
    $base_url = '../';
} else {
    $base_url = '';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Katalog UMKM Desa Mekarwangi - <?php echo isset($page_title) ? $page_title : 'Kenali Produk Lokal'; ?></title>
    
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <!-- Custom CSS - PAKAI BASE_URL -->
    <link rel="stylesheet" href="<?php echo $base_url; ?>assets/css/style.css">
    
    <style>
        /* Anti-flicker */
        .umkm-card, .kategori-card, .stat-card {
            opacity: 1 !important;
            transform: translateY(0) !important;
            visibility: visible !important;
        }
        
        .btn-wa {
            background: #25D366;
            color: white;
            border-radius: 50px;
            padding: 6px 16px;
            font-weight: 600;
            font-size: 13px;
            border: none;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .btn-wa:hover {
            background: #1da851;
            color: white;
            transform: scale(1.05);
        }
        
        * {
            animation-duration: 0.01ms !important;
            animation-iteration-count: 1 !important;
        }
        
        /* Banner KKm 47 */
        .kkm-banner {
            background: linear-gradient(135deg, #14213D 0%, #0B162C 100%);
            color: #F6D365;
            padding: 12px 0;
            text-align: center;
            font-size: 14px;
            font-weight: 500;
            border-bottom: 3px solid #F6D365;
            letter-spacing: 0.5px;
        }
        .kkm-banner span {
            color: #FFFFFF;
            font-weight: 600;
        }
        .kkm-banner i {
            margin: 0 8px;
            color: #F6D365;
        }
        
        /* Foto Bersama UMKM di Hero */
        .hero-foto-bersama {
            width: 100%;
            max-width: 500px;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(20, 33, 61, 0.2);
            border: 4px solid white;
            object-fit: cover;
            aspect-ratio: 4/3;
            background: var(--light-gray);
        }
        
        /* Ukuran kecil untuk hero ilustrasi */
        .hero-illustration .illustration-box {
            max-width: 350px;
            aspect-ratio: 4/3;
            display: flex;
            align-items: center;
            justify-content: center;
            background: transparent;
            box-shadow: none;
        }
        .hero-illustration .illustration-box::after {
            display: none;
        }
        
        /* Logo Cengkeh */
        .logo-cengkeh {
            font-size: 32px;
            line-height: 1;
            display: inline-block;
        }
        
        .navbar-brand .brand-icon {
            font-size: 32px;
            line-height: 1;
        }
    </style>
</head>
<body>
    <!-- KKm 47 Banner -->
    <div class="kkm-banner">
        <i class="fas fa-graduation-cap"></i>
        KKm 47 - Universitas Muhammadiyah Cirebon 
        <i class="fas fa-map-marker-alt"></i>
        <span>Desa Mekarwangi, Argapura, Majalengka</span>
    </div>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg sticky-top">
        <div class="container">
            <a class="navbar-brand" href="<?php echo $base_url; ?>index.php">
                <!-- GANTI LOGO PADI MENJADI DAUN/CENGKEH -->
                <span class="brand-icon">🌿</span>
                <span class="brand-title">Mekarwangi</span>
                <span class="brand-sub">KATALOG UMKM</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item">
                        <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>" href="<?php echo $base_url; ?>index.php">
                            <i class="fas fa-home"></i> Home
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'umkm.php' ? 'active' : ''; ?>" href="<?php echo $base_url; ?>umkm.php">
                            <i class="fas fa-store"></i> UMKM
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo $base_url; ?>index.php#kategori">
                            <i class="fas fa-tags"></i> Kategori
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo $base_url; ?>index.php#tentang">
                            <i class="fas fa-info-circle"></i> Tentang Desa
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo $base_url; ?>index.php#kontak">
                            <i class="fas fa-envelope"></i> Kontak
                        </a>
                    </li>
                </ul>
                <a href="<?php echo $base_url; ?>umkm.php" class="btn btn-primary btn-explore">
                    <i class="fas fa-compass"></i> Jelajahi UMKM
                </a>
            </div>
        </div>
    </nav>
    <main>