<?php
// create_images.php - Buat placeholder gambar otomatis
$dir = 'assets/images/';

if (!is_dir($dir)) {
    mkdir($dir, 0777, true);
}

// Buat default-umkm.jpg
$img = imagecreatetruecolor(400, 300);
$bg = imagecolorallocate($img, 246, 211, 101); // #F6D365
$textColor = imagecolorallocate($img, 20, 33, 61); // #14213D
imagefill($img, 0, 0, $bg);
imagestring($img, 5, 150, 140, 'UMKM', $textColor);
imagejpeg($img, $dir . 'default-umkm.jpg', 90);
imagedestroy($img);

// Buat default-produk.jpg
$img = imagecreatetruecolor(400, 300);
$bg = imagecolorallocate($img, 246, 211, 101);
$textColor = imagecolorallocate($img, 20, 33, 61);
imagefill($img, 0, 0, $bg);
imagestring($img, 5, 140, 140, 'Produk', $textColor);
imagejpeg($img, $dir . 'default-produk.jpg', 90);
imagedestroy($img);

// Buat folder produk
if (!is_dir($dir . 'produk/')) {
    mkdir($dir . 'produk/', 0777, true);
}

echo "✅ SEMUA FILE GAMBAR BERHASIL DIBUAT!<br>";
echo "📍 Lokasi: " . realpath($dir) . "<br>";
echo "<hr>";
echo "<a href='index.php'>🔙 Kembali ke Halaman Utama</a>";
?>