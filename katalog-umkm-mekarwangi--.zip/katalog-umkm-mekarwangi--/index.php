<?php
// index.php - Halaman Utama Katalog UMKM Desa Mekarwangi

require_once 'config/database.php';
$page_title = 'Beranda';

// Ambil data dari database
$total_umkm = getCount($pdo, 'umkm');
$total_kategori = getCount($pdo, 'kategori');
$total_produk = getCount($pdo, 'produk');

// Ambil semua kategori
$kategori_list = getAllKategori($pdo);

// Ambil UMKM unggulan (4 UMKM terbaru)
$stmt = $pdo->query("SELECT u.*, k.nama_kategori FROM umkm u 
                     LEFT JOIN kategori k ON u.kategori_id = k.id 
                     WHERE u.status = 'aktif' 
                     ORDER BY u.created_at DESC LIMIT 4");
$umkm_unggulan = $stmt->fetchAll();

include 'includes/header.php';
?>

<!-- HERO SECTION - FULL BACKGROUND -->
<section class="hero">
    <div class="hero-overlay"></div>
    <div class="hero-content">
        <div class="hero-badge">🌿 DESA MEKARWANGI • UMKM LOKAL</div>
        <h1>
            Selamat Datang di <br>
            <span class="highlight">Katalog UMKM</span> Desa Mekarwangi
        </h1>
        <p>
            Temukan berbagai produk unggulan dan usaha masyarakat Desa Mekarwangi 
            dalam satu katalog digital yang mudah diakses.
        </p>
        <div class="hero-buttons">
            <a href="umkm.php" class="btn-primary-custom">
                <i class="fas fa-compass"></i> Jelajahi UMKM
            </a>
            <a href="#tentang" class="btn-outline-custom">
                <i class="fas fa-info-circle"></i> Tentang Desa
            </a>
        </div>
    </div>
</section>

<!-- STATISTIK -->
<section class="statistik">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-4">
                <div class="stat-card">
                    <span class="stat-icon">🏪</span>
                    <div class="stat-number"><?php echo $total_umkm; ?><span class="plus">+</span></div>
                    <div class="stat-label">UMKM Terdata</div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <span class="stat-icon">📂</span>
                    <div class="stat-number"><?php echo $total_kategori; ?><span class="plus">+</span></div>
                    <div class="stat-label">Kategori Usaha</div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <span class="stat-icon">📦</span>
                    <div class="stat-number"><?php echo $total_produk; ?><span class="plus">+</span></div>
                    <div class="stat-label">Produk Lokal</div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- KATEGORI -->
<section class="py-5" id="kategori">
    <div class="container">
        <div class="text-center">
            <span class="hero-badge" style="background: var(--butter-yellow); color: var(--navy);">JELAJAHI KATALOG</span>
            <h2 class="section-title">Temukan Produk Lokal Mekarwangi</h2>
            <p class="section-subtitle">Jelajahi berbagai usaha dan produk masyarakat Desa Mekarwangi berdasarkan kategorinya.</p>
        </div>
        <div class="row g-4">
            <?php foreach ($kategori_list as $kategori): 
                // Hitung jumlah UMKM per kategori
                $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM umkm WHERE kategori_id = :id AND status = 'aktif'");
                $stmt->execute(['id' => $kategori['id']]);
                $count = $stmt->fetch()['total'];
            ?>
            <div class="col-lg-4 col-md-6">
                <div class="kategori-card">
                    <span class="icon"><i class="fas <?php echo $kategori['icon'] ?? 'fa-store'; ?>"></i></span>
                    <h5><?php echo htmlspecialchars($kategori['nama_kategori']); ?></h5>
                    <div class="count"><?php echo $count; ?> UMKM</div>
                    <div class="desc"><?php echo htmlspecialchars($kategori['deskripsi'] ?? ''); ?></div>
                    <a href="umkm.php?kategori=<?php echo $kategori['id']; ?>" class="btn-kategori">Lihat Kategori →</a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- UMKM UNGGULAN -->
<section class="py-5" style="background: var(--white);" id="unggulan">
    <div class="container">
        <div class="text-center">
            <span class="hero-badge" style="background: var(--butter-yellow); color: var(--navy);">PILIHAN WARGA</span>
            <h2 class="section-title">UMKM Unggulan Desa Mekarwangi</h2>
            <p class="section-subtitle">Produk-produk terbaik dari masyarakat Desa Mekarwangi yang patut Anda kenali.</p>
        </div>
        <div class="row g-4">
            <?php foreach ($umkm_unggulan as $umkm): ?>
            <div class="col-lg-3 col-md-6">
                <div class="umkm-card">
                    <img src="assets/images/<?php echo $umkm['foto'] ?? 'default-umkm.jpg'; ?>" 
                         class="umkm-card-img" 
                         alt="<?php echo htmlspecialchars($umkm['nama_usaha']); ?>"
                         onerror="this.src='assets/images/default-umkm.jpg'">
                    <div class="umkm-card-body">
                        <span class="badge-kategori"><?php echo htmlspecialchars($umkm['nama_kategori'] ?? 'UMKM'); ?></span>
                        <h4><?php echo htmlspecialchars($umkm['nama_usaha']); ?></h4>
                        <div class="owner"><i class="fas fa-user"></i> <?php echo htmlspecialchars($umkm['pemilik']); ?></div>
                        <div class="desc"><?php echo htmlspecialchars(substr($umkm['deskripsi'] ?? '', 0, 80)) . '...'; ?></div>
                        <div class="location"><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($umkm['alamat'] ?? 'Desa Mekarwangi'); ?></div>
                        <a href="detail_umkm.php?id=<?php echo $umkm['id']; ?>" class="btn-detail">
                            Lihat Detail <i class="fas fa-arrow-right"></i>
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="text-center mt-5">
            <a href="umkm.php" class="btn-primary-custom">
                Lihat Semua UMKM <i class="fas fa-arrow-right"></i>
            </a>
        </div>
    </div>
</section>

<!-- TENTANG DESA / POTENSI DESA -->
<section class="tentang-section" id="tentang">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-6">
                <span class="hero-badge" style="background: var(--butter-yellow); color: var(--navy);">TENTANG KAMI</span>
                <h2 class="section-title" style="font-size: 32px;">Potensi UMKM Desa Mekarwangi</h2>
                <p style="color: var(--text-soft); font-size: 16px; line-height: 1.8;">
                    Desa Mekarwangi memiliki berbagai potensi usaha masyarakat yang bergerak di bidang 
                    makanan, kerajinan, pertanian, perdagangan, dan berbagai usaha lokal lainnya.
                </p>
                <p style="color: var(--text-soft); font-size: 16px; line-height: 1.8;">
                    Katalog digital ini hadir untuk memperkenalkan produk-produk unggulan UMKM Desa Mekarwangi 
                    kepada masyarakat luas, membantu digitalisasi usaha, dan mendukung penguatan ekonomi lokal.
                </p>
                <a href="umkm.php" class="btn-primary-custom mt-3">
                    Lihat UMKM <i class="fas fa-arrow-right"></i>
                </a>
            </div>
            <div class="col-lg-6">
                <!-- GANTI EMOJI DENGAN FOTO -->
                <img src="assets/images/potensi-desa.jpg" 
                     alt="Potensi Desa Mekarwangi" 
                     class="tentang-img-foto"
                     onerror="this.src='assets/images/default-umkm.jpg'">
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>