<?php
// create_all_photos.php
$dir = 'assets/images/';

if (!is_dir($dir)) {
    mkdir($dir, 0777, true);
}

$files = [
    'parered.jpg' => 'Parered Ma Ambang',
    'rengginang.jpg' => 'Rengginang',
    'rempeyek.jpg' => 'Rempeyek',
    'gabin.jpg' => 'Gabin',
    'zakky-motor.jpg' => 'Zakky Motor',
    'warung-teh-neng.jpg' => 'Warung Teh Neng',
    'warung-bibi.jpg' => 'Warung Bibi',
    'warung-ekal.jpg' => 'Warung Ekal',
    'cengkeh-kapolaga.jpg' => 'Cengkeh Kapolaga',
    'padi-mekarwangi.jpg' => 'Padi Mekarwangi',
    'minyak-cengkeh.jpg' => 'Minyak Cengkeh',
    'cuci-steam-jajang.jpg' => 'Cuci Steam & Warung'
];

foreach ($files as $filename => $text) {
    $img = imagecreatetruecolor(400, 300);
    $bg = imagecolorallocate($img, 246, 211, 101);
    $textColor = imagecolorallocate($img, 20, 33, 61);
    imagefill($img, 0, 0, $bg);
    imagestring($img, 5, 80, 140, $text, $textColor);
    imagejpeg($img, $dir . $filename, 90);
    imagedestroy($img);
    echo "✅ $filename created<br>";
}

echo "<hr>";
echo "<a href='index.php'>🔙 Kembali ke Halaman Utama</a>";
?>