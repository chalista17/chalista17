<?php
// umkm.php - Halaman Daftar UMKM

require_once 'config/database.php';
$page_title = 'Daftar UMKM';

// Ambil parameter kategori (jika ada)
$kategori_id = isset($_GET['kategori']) ? (int)$_GET['kategori'] : null;

// Ambil data UMKM berdasarkan kategori
$umkm_list = getUMKMByKategori($pdo, $kategori_id);

// Ambil semua kategori untuk filter
$kategori_list = getAllKategori($pdo);

include 'includes/header.php';
?>

<section class="py-5" style="background: var(--cream); min-height: 70vh;">
    <div class="container">
        <div class="row mb-4">
            <div class="col-lg-8">
                <h2 class="section-title mb-2">Daftar UMKM</h2>
                <p class="text-muted">Menampilkan <?php echo count($umkm_list); ?> UMKM dari Desa Mekarwangi</p>
            </div>
            <div class="col-lg-4">
                <form method="GET" class="d-flex gap-2">
                    <select name="kategori" class="form-select" style="border-radius: 12px; border: 2px solid #F4F5F7;" onchange="this.form.submit()">
                        <option value="">Semua Kategori</option>
                        <?php foreach ($kategori_list as $k): ?>
                        <option value="<?php echo $k['id']; ?>" <?php echo $kategori_id == $k['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($k['nama_kategori']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                    <?php if ($kategori_id): ?>
                    <a href="umkm.php" class="btn btn-outline-secondary" style="border-radius: 12px;">Reset</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>
        
        <?php if (count($umkm_list) > 0): ?>
        <div class="row g-4">
            <?php foreach ($umkm_list as $umkm): ?>
            <div class="col-md-6 col-lg-4">
                <div class="umkm-card">
                    <img src="assets/images/<?php echo $umkm['foto'] ?? 'default-umkm.jpg'; ?>" 
                         class="umkm-card-img" 
                         alt="<?php echo htmlspecialchars($umkm['nama_usaha']); ?>"
                         onerror="this.src='assets/images/default-umkm.jpg'">
                    <div class="umkm-card-body">
                        <span class="badge-kategori"><?php echo htmlspecialchars($umkm['nama_kategori'] ?? 'UMKM'); ?></span>
                        <h4><?php echo htmlspecialchars($umkm['nama_usaha']); ?></h4>
                        <div class="owner"><i class="fas fa-user"></i> <?php echo htmlspecialchars($umkm['pemilik']); ?></div>
                        <div class="desc"><?php echo htmlspecialchars(substr($umkm['deskripsi'] ?? '', 0, 100)) . '...'; ?></div>
                        <div class="location"><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($umkm['alamat'] ?? 'Desa Mekarwangi'); ?></div>
                        <div class="d-flex gap-2 flex-wrap mt-2">
                            <!-- ✅ FIX: Link Detail lebih eksplisit -->
                            <a href="detail_umkm.php?id=<?php echo (int)$umkm['id']; ?>" class="btn-detail">
                                <i class="fas fa-eye"></i> Detail
                            </a>
                            <?php if (!empty($umkm['no_whatsapp'])): ?>
                            <a href="https://wa.me/<?php echo $umkm['no_whatsapp']; ?>" target="_blank" class="btn-wa">
                                <i class="fab fa-whatsapp"></i> Chat
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <div class="text-center py-5">
            <i class="fas fa-store fa-4x mb-3" style="color: #ddd;"></i>
            <h4>Belum ada UMKM</h4>
            <p class="text-muted">Belum ada data UMKM pada kategori ini.</p>
            <a href="umkm.php" class="btn-primary-custom">Lihat Semua</a>
        </div>
        <?php endif; ?>
    </div>
</section>

<?php include 'includes/footer.php'; ?>