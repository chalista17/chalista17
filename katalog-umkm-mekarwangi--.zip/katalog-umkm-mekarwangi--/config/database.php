<?php
// config/database.php
// Konfigurasi database untuk Katalog UMKM Desa Mekarwangi

$host = 'localhost';
$dbname = 'mekarwangi_umkm';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Koneksi database gagal: " . $e->getMessage());
}

// ===== FUNGSI UNTUK ADMIN =====

// Fungsi untuk login admin
function loginAdmin($pdo, $username, $password) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
    $stmt->execute(['username' => $username]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        return $user;
    }
    return false;
}

// ===== FUNGSI UNTUK PUBLIC =====

// Fungsi untuk mendapatkan jumlah total
function getCount($pdo, $table) {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM $table");
    $result = $stmt->fetch();
    return $result ? $result['total'] : 0;
}

// Fungsi untuk mendapatkan UMKM berdasarkan kategori
function getUMKMByKategori($pdo, $kategori_id = null) {
    $sql = "SELECT u.*, k.nama_kategori FROM umkm u 
            LEFT JOIN kategori k ON u.kategori_id = k.id 
            WHERE u.status = 'aktif'";
    if ($kategori_id) {
        $sql .= " AND u.kategori_id = :kategori_id";
    }
    $sql .= " ORDER BY u.created_at DESC";
    $stmt = $pdo->prepare($sql);
    if ($kategori_id) {
        $stmt->execute(['kategori_id' => $kategori_id]);
    } else {
        $stmt->execute();
    }
    return $stmt->fetchAll();
}

// Fungsi untuk mendapatkan detail UMKM
// ✅ FIX: Menambahkan u.instagram supaya data Instagram tidak hilang saat edit
function getUMKMDetail($pdo, $id) {
    $stmt = $pdo->prepare("SELECT u.id, u.nama_usaha, u.pemilik, u.kategori_id, 
                                  u.deskripsi, u.alamat, u.no_whatsapp, u.instagram, 
                                  u.google_maps, u.foto, u.status, 
                                  u.created_at, u.updated_at, k.nama_kategori 
                           FROM umkm u 
                           LEFT JOIN kategori k ON u.kategori_id = k.id 
                           WHERE u.id = :id");
    $stmt->execute(['id' => $id]);
    return $stmt->fetch();
}

// Fungsi untuk mendapatkan produk UMKM
function getProdukUMKM($pdo, $umkm_id) {
    $stmt = $pdo->prepare("SELECT * FROM produk WHERE umkm_id = :umkm_id AND status = 'tersedia'");
    $stmt->execute(['umkm_id' => $umkm_id]);
    return $stmt->fetchAll();
}

// Fungsi untuk mendapatkan semua kategori
function getAllKategori($pdo) {
    $stmt = $pdo->query("SELECT * FROM kategori ORDER BY nama_kategori");
    return $stmt->fetchAll();
}

// Fungsi untuk mendapatkan semua UMKM (untuk admin)
function getAllUMKM($pdo) {
    $stmt = $pdo->query("SELECT u.*, k.nama_kategori FROM umkm u 
                         LEFT JOIN kategori k ON u.kategori_id = k.id 
                         ORDER BY u.created_at DESC");
    return $stmt->fetchAll();
}

// Fungsi untuk mendapatkan semua produk (untuk admin)
function getAllProduk($pdo) {
    $stmt = $pdo->query("SELECT p.*, u.nama_usaha as nama_umkm FROM produk p 
                         LEFT JOIN umkm u ON p.umkm_id = u.id 
                         ORDER BY p.created_at DESC");
    return $stmt->fetchAll();
}
?>