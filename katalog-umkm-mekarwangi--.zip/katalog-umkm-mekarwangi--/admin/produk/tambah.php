<?php
// admin/produk/tambah.php - Tambah Produk

session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../login.php');
    exit;
}

require_once '../../config/database.php';

// Ambil data UMKM untuk dropdown
$umkm_list = $pdo->query("SELECT id, nama_usaha FROM umkm ORDER BY nama_usaha")->fetchAll();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $umkm_id = (int)($_POST['umkm_id'] ?? 0);
    $nama_produk = trim($_POST['nama_produk'] ?? '');
    $deskripsi = trim($_POST['deskripsi'] ?? '');
    $harga = (float)($_POST['harga'] ?? 0);
    $status = $_POST['status'] ?? 'tersedia';
    
    if ($umkm_id <= 0 || empty($nama_produk)) {
        $error = 'Nama produk dan UMKM wajib diisi!';
    } else {
        $foto = 'default-produk.jpg';
        if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['foto'];
            $allowed = ['image/jpeg', 'image/png', 'image/webp'];
            
            if (!in_array($file['type'], $allowed)) {
                $error = 'Format foto harus JPG, PNG, atau WEBP!';
            } elseif ($file['size'] > 2 * 1024 * 1024) {
                $error = 'Ukuran foto maksimal 2MB!';
            } else {
                if (!file_exists('../../assets/images/produk/')) {
                    mkdir('../../assets/images/produk/', 0777, true);
                }
                $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                $foto = 'produk_' . time() . '_' . uniqid() . '.' . $ext;
                move_uploaded_file($file['tmp_name'], '../../assets/images/produk/' . $foto);
            }
        }
        
        if (empty($error)) {
            $stmt = $pdo->prepare("INSERT INTO produk (umkm_id, nama_produk, deskripsi, harga, foto, status) 
                                   VALUES (:umkm_id, :nama_produk, :deskripsi, :harga, :foto, :status)");
            $stmt->execute([
                'umkm_id' => $umkm_id,
                'nama_produk' => $nama_produk,
                'deskripsi' => $deskripsi,
                'harga' => $harga,
                'foto' => $foto,
                'status' => $status
            ]);
            header('Location: index.php?success=tambah');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Produk - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background: #F4F5F7; }
        .sidebar { background: #14213D; min-height: 100vh; padding: 20px 0; position: sticky; top: 0; }
        .sidebar .brand { text-align: center; padding: 0 20px 30px; border-bottom: 1px solid rgba(255,255,255,0.06); }
        .sidebar .brand .icon { font-size: 32px; display: block; }
        .sidebar .brand h5 { color: #F6D365; font-family: 'Plus Jakarta Sans', sans-serif; font-weight: 800; margin-top: 8px; }
        .sidebar .brand small { color: rgba(255,255,255,0.5); font-size: 11px; letter-spacing: 1px; }
        .sidebar .nav-link { color: rgba(255,255,255,0.6); padding: 12px 24px; border-radius: 12px; margin: 2px 12px; transition: all 0.3s; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { background: rgba(246, 211, 101, 0.12); color: #F6D365; }
        .sidebar .nav-link i { width: 24px; }
        .sidebar .nav-link.logout { color: #ef4444; margin-top: 20px; border-top: 1px solid rgba(255,255,255,0.06); border-radius: 0; padding-top: 20px; }
        .sidebar .nav-link.logout:hover { background: rgba(239, 68, 68, 0.12); }
        .main-content { padding: 30px; }
        .form-container { background: white; border-radius: 16px; padding: 30px; box-shadow: 0 2px 12px rgba(20,33,61,0.06); }
        .form-label { font-weight: 600; font-size: 14px; }
        .form-control, .form-select { border-radius: 10px; border: 2px solid #F4F5F7; padding: 10px 14px; font-size: 14px; }
        .form-control:focus, .form-select:focus { border-color: #F6D365; box-shadow: 0 0 0 4px rgba(246, 211, 101, 0.15); }
        .btn-submit { background: #14213D; color: #F6D365; border-radius: 12px; padding: 12px 32px; font-weight: 600; border: none; transition: all 0.3s; }
        .btn-submit:hover { background: #0B162C; color: #F6D365; transform: translateY(-2px); box-shadow: 0 8px 25px rgba(20, 33, 61, 0.2); }
        .btn-cancel { background: #F4F5F7; color: #5B647A; border-radius: 12px; padding: 12px 32px; font-weight: 600; border: none; transition: all 0.3s; text-decoration: none; display: inline-block; }
        .btn-cancel:hover { background: #e8e9eb; color: #14213D; }
        .alert-custom { border-radius: 12px; padding: 16px 20px; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0 sidebar">
                <div class="brand">
                    <span class="icon">🌾</span>
                    <h5>Mekarwangi</h5>
                    <small>ADMIN PANEL</small>
                </div>
                <nav class="nav flex-column">
                    <a href="../dashboard.php" class="nav-link"><i class="fas fa-chart-pie"></i> Dashboard</a>
                    <a href="../umkm/index.php" class="nav-link"><i class="fas fa-store"></i> UMKM</a>
                    <a href="index.php" class="nav-link active"><i class="fas fa-box"></i> Produk</a>
                    <a href="../kategori/index.php" class="nav-link"><i class="fas fa-tags"></i> Kategori</a>
                    <a href="../logout.php" class="nav-link logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </nav>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h4 class="fw-bold mb-0">Tambah Produk</h4>
                        <p class="text-muted mb-0">Tambahkan produk baru untuk UMKM</p>
                    </div>
                    <a href="index.php" class="btn-cancel">
                        <i class="fas fa-arrow-left me-2"></i> Kembali
                    </a>
                </div>
                
                <?php if ($error): ?>
                <div class="alert alert-danger alert-custom">
                    <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error; ?>
                </div>
                <?php endif; ?>
                
                <div class="form-container">
                    <form method="POST" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">UMKM <span class="text-danger">*</span></label>
                                    <select name="umkm_id" class="form-select" required>
                                        <option value="">Pilih UMKM</option>
                                        <?php foreach ($umkm_list as $u): ?>
                                        <option value="<?php echo $u['id']; ?>"><?php echo htmlspecialchars($u['nama_usaha']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Status</label>
                                    <select name="status" class="form-select">
                                        <option value="tersedia">Tersedia</option>
                                        <option value="tidak_tersedia">Tidak Tersedia</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Nama Produk <span class="text-danger">*</span></label>
                            <input type="text" name="nama_produk" class="form-control" placeholder="Contoh: Parered Original" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Deskripsi Produk</label>
                            <textarea name="deskripsi" class="form-control" rows="2" placeholder="Deskripsi produk"></textarea>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Harga (Rp)</label>
                                    <input type="number" name="harga" class="form-control" placeholder="0" step="500">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Foto Produk</label>
                                    <input type="file" name="foto" class="form-control" accept="image/*">
                                    <small class="text-muted">Format: JPG, PNG, WEBP. Maks 2MB.</small>
                                </div>
                            </div>
                        </div>
                        
                        <div class="d-flex gap-3 mt-4">
                            <button type="submit" class="btn-submit">
                                <i class="fas fa-save me-2"></i> Simpan Produk
                            </button>
                            <a href="index.php" class="btn-cancel">Batal</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>