<?php
// admin/produk/hapus.php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../login.php');
    exit;
}

require_once '../../config/database.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0) {
    // Ambil data produk untuk hapus foto
    $stmt = $pdo->prepare("SELECT * FROM produk WHERE id = :id");
    $stmt->execute(['id' => $id]);
    $produk = $stmt->fetch();
    
    // ✅ FIX: Path yang benar adalah assets/images/produk/
    if ($produk && $produk['foto'] != 'default-produk.jpg' 
        && file_exists('../../assets/images/produk/' . $produk['foto'])) {
        unlink('../../assets/images/produk/' . $produk['foto']);
    }
    
    $stmt = $pdo->prepare("DELETE FROM produk WHERE id = :id");
    $stmt->execute(['id' => $id]);
}

header('Location: index.php?success=hapus');
exit;
?>