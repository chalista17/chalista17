<?php
// admin/umkm/index.php - Manajemen UMKM

session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../login.php');
    exit;
}

require_once '../../config/database.php';

// Ambil semua UMKM
$stmt = $pdo->query("SELECT u.*, k.nama_kategori FROM umkm u 
                     LEFT JOIN kategori k ON u.kategori_id = k.id 
                     ORDER BY u.created_at DESC");
$umkm_list = $stmt->fetchAll();

// Pesan notifikasi
$success = isset($_GET['success']) ? $_GET['success'] : '';
$error = isset($_GET['error']) ? $_GET['error'] : '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen UMKM - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background: #F4F5F7; }
        .sidebar { background: #14213D; min-height: 100vh; padding: 20px 0; position: sticky; top: 0; }
        .sidebar .brand { text-align: center; padding: 0 20px 30px; border-bottom: 1px solid rgba(255,255,255,0.06); }
        .sidebar .brand .icon { font-size: 32px; display: block; }
        .sidebar .brand h5 { color: #F6D365; font-family: 'Plus Jakarta Sans', sans-serif; font-weight: 800; margin-top: 8px; }
        .sidebar .brand small { color: rgba(255,255,255,0.5); font-size: 11px; letter-spacing: 1px; }
        .sidebar .nav-link { color: rgba(255,255,255,0.6); padding: 12px 24px; border-radius: 12px; margin: 2px 12px; transition: all 0.3s; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { background: rgba(246, 211, 101, 0.12); color: #F6D365; }
        .sidebar .nav-link i { width: 24px; }
        .sidebar .nav-link.logout { color: #ef4444; margin-top: 20px; border-top: 1px solid rgba(255,255,255,0.06); border-radius: 0; padding-top: 20px; }
        .sidebar .nav-link.logout:hover { background: rgba(239, 68, 68, 0.12); }
        .main-content { padding: 30px; }
        .table-custom { background: white; border-radius: 16px; overflow: hidden; box-shadow: 0 2px 12px rgba(20,33,61,0.06); }
        .table-custom th { background: #F4F5F7; color: #14213D; font-weight: 600; font-size: 13px; border: none; padding: 12px 16px; }
        .table-custom td { padding: 12px 16px; vertical-align: middle; font-size: 14px; }
        .badge-status { padding: 4px 14px; border-radius: 50px; font-size: 11px; font-weight: 600; }
        .badge-status.aktif { background: #d4edda; color: #155724; }
        .badge-status.tidak_aktif { background: #f8d7da; color: #721c24; }
        .btn-add { background: #F6D365; color: #14213D; border-radius: 12px; padding: 10px 24px; font-weight: 600; border: none; transition: all 0.3s; }
        .btn-add:hover { background: #e8c54a; color: #14213D; transform: translateY(-2px); box-shadow: 0 8px 25px rgba(246, 211, 101, 0.3); }
        .btn-action { padding: 4px 12px; font-size: 12px; border-radius: 8px; }
        .btn-action i { margin-right: 4px; }
        .alert-custom { border-radius: 12px; padding: 16px 20px; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0 sidebar">
                <div class="brand">
                    <span class="icon">🌾</span>
                    <h5>Mekarwangi</h5>
                    <small>ADMIN PANEL</small>
                </div>
                <nav class="nav flex-column">
                    <a href="../dashboard.php" class="nav-link"><i class="fas fa-chart-pie"></i> Dashboard</a>
                    <a href="index.php" class="nav-link active"><i class="fas fa-store"></i> UMKM</a>
                    <a href="../produk/index.php" class="nav-link"><i class="fas fa-box"></i> Produk</a>
                    <a href="../kategori/index.php" class="nav-link"><i class="fas fa-tags"></i> Kategori</a>
                    <a href="../logout.php" class="nav-link logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </nav>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h4 class="fw-bold mb-0">Manajemen UMKM</h4>
                        <p class="text-muted mb-0">Kelola data UMKM Desa Mekarwangi</p>
                    </div>
                    <a href="tambah.php" class="btn-add">
                        <i class="fas fa-plus me-2"></i> Tambah UMKM
                    </a>
                </div>
                
                <!-- Notifikasi -->
                <?php if ($success): ?>
                <div class="alert alert-success alert-custom">
                    <i class="fas fa-check-circle me-2"></i> 
                    <?php 
                        switch($success) {
                            case 'tambah': echo 'UMKM berhasil ditambahkan!'; break;
                            case 'edit': echo 'UMKM berhasil diupdate!'; break;
                            case 'hapus': echo 'UMKM berhasil dihapus!'; break;
                            default: echo $success;
                        }
                    ?>
                </div>
                <?php endif; ?>
                <?php if ($error): ?>
                <div class="alert alert-danger alert-custom">
                    <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error; ?>
                </div>
                <?php endif; ?>
                
                <!-- Tabel UMKM -->
                <div class="table-custom">
                    <table class="table mb-0">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Foto</th>
                                <th>Nama UMKM</th>
                                <th>Kategori</th>
                                <th>Pemilik</th>
                                <th>WhatsApp</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($umkm_list) > 0): ?>
                            <?php $no = 1; foreach ($umkm_list as $umkm): ?>
                            <tr>
                                <td><?php echo $no++; ?></td>
                                <td>
                                    <img src="../../assets/images/<?php echo $umkm['foto'] ?? 'default-umkm.jpg'; ?>" 
                                         style="width: 50px; height: 50px; object-fit: cover; border-radius: 10px;"
                                         onerror="this.src='../../assets/images/default-umkm.jpg'">
                                </td>
                                <td><strong><?php echo htmlspecialchars($umkm['nama_usaha']); ?></strong></td>
                                <td><?php echo htmlspecialchars($umkm['nama_kategori'] ?? '-'); ?></td>
                                <td><?php echo htmlspecialchars($umkm['pemilik']); ?></td>
                                <td><?php echo htmlspecialchars($umkm['no_whatsapp'] ?? '-'); ?></td>
                                <td>
                                    <span class="badge-status <?php echo $umkm['status']; ?>">
                                        <?php echo $umkm['status'] == 'aktif' ? 'Aktif' : 'Tidak Aktif'; ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="edit.php?id=<?php echo $umkm['id']; ?>" class="btn btn-sm btn-warning btn-action">
                                        <i class="fas fa-edit"></i> Edit
                                    </a>
                                    <a href="hapus.php?id=<?php echo $umkm['id']; ?>" class="btn btn-sm btn-danger btn-action" onclick="return confirm('Yakin ingin menghapus UMKM ini? Data yang terkait (produk) juga akan dihapus.')">
                                        <i class="fas fa-trash"></i> Hapus
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php else: ?>
                            <tr>
                                <td colspan="8" class="text-center py-4 text-muted">
                                    <i class="fas fa-store fa-2x d-block mb-2" style="color: #ddd;"></i>
                                    Belum ada data UMKM. <a href="tambah.php">Tambah UMKM</a>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>