<?php
// admin/umkm/hapus.php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../login.php');
    exit;
}

require_once '../../config/database.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0) {
    // Ambil data UMKM untuk hapus foto
    $umkm = getUMKMDetail($pdo, $id);
    if ($umkm && $umkm['foto'] != 'default-umkm.jpg' && file_exists('../../assets/images/' . $umkm['foto'])) {
        unlink('../../assets/images/' . $umkm['foto']);
    }
    
    // Hapus UMKM (produk akan terhapus otomatis karena CASCADE di database)
    $stmt = $pdo->prepare("DELETE FROM umkm WHERE id = :id");
    $stmt->execute(['id' => $id]);
}

header('Location: index.php?success=hapus');
exit;
?>