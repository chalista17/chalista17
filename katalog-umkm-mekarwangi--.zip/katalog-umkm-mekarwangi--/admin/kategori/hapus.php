<?php
// admin/kategori/hapus.php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../login.php');
    exit;
}

require_once '../../config/database.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0) {
    $stmt = $pdo->prepare("DELETE FROM kategori WHERE id = :id");
    $stmt->execute(['id' => $id]);
}

header('Location: index.php?success=hapus');
exit;
?>