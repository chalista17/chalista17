<?php
// admin/kategori/edit.php - Edit Kategori

session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../login.php');
    exit;
}

require_once '../../config/database.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    header('Location: index.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM kategori WHERE id = :id");
$stmt->execute(['id' => $id]);
$kategori = $stmt->fetch();

if (!$kategori) {
    header('Location: index.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_kategori = trim($_POST['nama_kategori'] ?? '');
    $deskripsi = trim($_POST['deskripsi'] ?? '');
    $icon = trim($_POST['icon'] ?? 'fa-store');
    
    if (empty($nama_kategori)) {
        $error = 'Nama kategori wajib diisi!';
    } else {
        $stmt = $pdo->prepare("UPDATE kategori SET nama_kategori = :nama, deskripsi = :deskripsi, icon = :icon WHERE id = :id");
        $stmt->execute([
            'nama' => $nama_kategori,
            'deskripsi' => $deskripsi,
            'icon' => $icon,
            'id' => $id
        ]);
        header('Location: index.php?success=edit');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Kategori - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background: #F4F5F7; }
        .sidebar { background: #14213D; min-height: 100vh; padding: 20px 0; position: sticky; top: 0; }
        .sidebar .brand { text-align: center; padding: 0 20px 30px; border-bottom: 1px solid rgba(255,255,255,0.06); }
        .sidebar .brand .icon { font-size: 32px; display: block; }
        .sidebar .brand h5 { color: #F6D365; font-family: 'Plus Jakarta Sans', sans-serif; font-weight: 800; margin-top: 8px; }
        .sidebar .brand small { color: rgba(255,255,255,0.5); font-size: 11px; letter-spacing: 1px; }
        .sidebar .nav-link { color: rgba(255,255,255,0.6); padding: 12px 24px; border-radius: 12px; margin: 2px 12px; transition: all 0.3s; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { background: rgba(246, 211, 101, 0.12); color: #F6D365; }
        .sidebar .nav-link i { width: 24px; }
        .sidebar .nav-link.logout { color: #ef4444; margin-top: 20px; border-top: 1px solid rgba(255,255,255,0.06); border-radius: 0; padding-top: 20px; }
        .sidebar .nav-link.logout:hover { background: rgba(239, 68, 68, 0.12); }
        .main-content { padding: 30px; }
        .form-container { background: white; border-radius: 16px; padding: 30px; box-shadow: 0 2px 12px rgba(20,33,61,0.06); }
        .form-label { font-weight: 600; font-size: 14px; }
        .form-control, .form-select { border-radius: 10px; border: 2px solid #F4F5F7; padding: 10px 14px; font-size: 14px; }
        .form-control:focus, .form-select:focus { border-color: #F6D365; box-shadow: 0 0 0 4px rgba(246, 211, 101, 0.15); }
        .btn-submit { background: #14213D; color: #F6D365; border-radius: 12px; padding: 12px 32px; font-weight: 600; border: none; transition: all 0.3s; }
        .btn-submit:hover { background: #0B162C; color: #F6D365; transform: translateY(-2px); box-shadow: 0 8px 25px rgba(20, 33, 61, 0.2); }
        .btn-cancel { background: #F4F5F7; color: #5B647A; border-radius: 12px; padding: 12px 32px; font-weight: 600; border: none; transition: all 0.3s; text-decoration: none; display: inline-block; }
        .btn-cancel:hover { background: #e8e9eb; color: #14213D; }
        .alert-custom { border-radius: 12px; padding: 16px 20px; }
        .icon-list { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 8px; }
        .icon-option { padding: 6px 12px; border: 2px solid #F4F5F7; border-radius: 8px; cursor: pointer; transition: all 0.3s; font-size: 14px; }
        .icon-option:hover, .icon-option.active { border-color: #F6D365; background: rgba(246, 211, 101, 0.1); }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0 sidebar">
                <div class="brand">
                    <span class="icon">🌾</span>
                    <h5>Mekarwangi</h5>
                    <small>ADMIN PANEL</small>
                </div>
                <nav class="nav flex-column">
                    <a href="../dashboard.php" class="nav-link"><i class="fas fa-chart-pie"></i> Dashboard</a>
                    <a href="../umkm/index.php" class="nav-link"><i class="fas fa-store"></i> UMKM</a>
                    <a href="../produk/index.php" class="nav-link"><i class="fas fa-box"></i> Produk</a>
                    <a href="index.php" class="nav-link active"><i class="fas fa-tags"></i> Kategori</a>
                    <a href="../logout.php" class="nav-link logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </nav>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h4 class="fw-bold mb-0">Edit Kategori</h4>
                        <p class="text-muted mb-0">Update data kategori</p>
                    </div>
                    <a href="index.php" class="btn-cancel">
                        <i class="fas fa-arrow-left me-2"></i> Kembali
                    </a>
                </div>
                
                <?php if ($error): ?>
                <div class="alert alert-danger alert-custom">
                    <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error; ?>
                </div>
                <?php endif; ?>
                
                <div class="form-container">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Nama Kategori <span class="text-danger">*</span></label>
                            <input type="text" name="nama_kategori" class="form-control" value="<?php echo htmlspecialchars($kategori['nama_kategori']); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Deskripsi Kategori</label>
                            <textarea name="deskripsi" class="form-control" rows="2"><?php echo htmlspecialchars($kategori['deskripsi']); ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Icon Kategori</label>
                            <input type="text" name="icon" class="form-control" value="<?php echo htmlspecialchars($kategori['icon'] ?? 'fa-store'); ?>">
                            <small class="text-muted">Gunakan class Font Awesome (contoh: fa-store, fa-utensils, fa-seedling)</small>
                            <div class="icon-list">
                                <span class="icon-option <?php echo $kategori['icon'] == 'fa-store' ? 'active' : ''; ?>" data-icon="fa-store"><i class="fas fa-store"></i> fa-store</span>
                                <span class="icon-option <?php echo $kategori['icon'] == 'fa-utensils' ? 'active' : ''; ?>" data-icon="fa-utensils"><i class="fas fa-utensils"></i> fa-utensils</span>
                                <span class="icon-option <?php echo $kategori['icon'] == 'fa-seedling' ? 'active' : ''; ?>" data-icon="fa-seedling"><i class="fas fa-seedling"></i> fa-seedling</span>
                                <span class="icon-option <?php echo $kategori['icon'] == 'fa-hand-sparkles' ? 'active' : ''; ?>" data-icon="fa-hand-sparkles"><i class="fas fa-hand-sparkles"></i> fa-hand-sparkles</span>
                                <span class="icon-option <?php echo $kategori['icon'] == 'fa-handshake' ? 'active' : ''; ?>" data-icon="fa-handshake"><i class="fas fa-handshake"></i> fa-handshake</span>
                                <span class="icon-option <?php echo $kategori['icon'] == 'fa-ellipsis-h' ? 'active' : ''; ?>" data-icon="fa-ellipsis-h"><i class="fas fa-ellipsis-h"></i> fa-ellipsis-h</span>
                                <span class="icon-option <?php echo $kategori['icon'] == 'fa-pizza-slice' ? 'active' : ''; ?>" data-icon="fa-pizza-slice"><i class="fas fa-pizza-slice"></i> fa-pizza-slice</span>
                                <span class="icon-option <?php echo $kategori['icon'] == 'fa-bread-slice' ? 'active' : ''; ?>" data-icon="fa-bread-slice"><i class="fas fa-bread-slice"></i> fa-bread-slice</span>
                                <span class="icon-option <?php echo $kategori['icon'] == 'fa-fish' ? 'active' : ''; ?>" data-icon="fa-fish"><i class="fas fa-fish"></i> fa-fish</span>
                                <span class="icon-option <?php echo $kategori['icon'] == 'fa-carrot' ? 'active' : ''; ?>" data-icon="fa-carrot"><i class="fas fa-carrot"></i> fa-carrot</span>
                            </div>
                        </div>
                        
                        <div class="d-flex gap-3 mt-4">
                            <button type="submit" class="btn-submit">
                                <i class="fas fa-save me-2"></i> Update Kategori
                            </button>
                            <a href="index.php" class="btn-cancel">Batal</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        document.querySelectorAll('.icon-option').forEach(el => {
            el.addEventListener('click', function() {
                document.querySelectorAll('.icon-option').forEach(e => e.classList.remove('active'));
                this.classList.add('active');
                document.querySelector('input[name="icon"]').value = this.dataset.icon;
            });
        });
    </script>
</body>
</html>