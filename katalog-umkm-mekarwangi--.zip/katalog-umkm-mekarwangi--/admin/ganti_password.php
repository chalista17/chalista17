<?php
// admin/ganti_password.php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

require_once '../config/database.php';

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old_password = $_POST['old_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Ambil password lama dari database
    $stmt = $pdo->prepare("SELECT password FROM users WHERE username = :username");
    $stmt->execute(['username' => $_SESSION['admin_user']]);
    $user = $stmt->fetch();
    
    if (!password_verify($old_password, $user['password'])) {
        $error = 'Password lama salah!';
    } elseif (strlen($new_password) < 6) {
        $error = 'Password baru minimal 6 karakter!';
    } elseif ($new_password !== $confirm_password) {
        $error = 'Konfirmasi password tidak cocok!';
    } else {
        // Hash password baru
        $hashed = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET password = :password WHERE username = :username");
        $stmt->execute([
            'password' => $hashed,
            'username' => $_SESSION['admin_user']
        ]);
        $success = 'Password berhasil diubah!';
    }
}

$page_title = 'Ganti Password';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ganti Password - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background: #F4F5F7; }
        .sidebar { background: #14213D; min-height: 100vh; padding: 20px 0; position: sticky; top: 0; }
        .sidebar .brand { text-align: center; padding: 0 20px 30px; border-bottom: 1px solid rgba(255,255,255,0.06); }
        .sidebar .brand .icon { font-size: 32px; display: block; }
        .sidebar .brand h5 { color: #F6D365; font-family: 'Plus Jakarta Sans', sans-serif; font-weight: 800; margin-top: 8px; }
        .sidebar .brand small { color: rgba(255,255,255,0.5); font-size: 11px; letter-spacing: 1px; }
        .sidebar .nav-link { color: rgba(255,255,255,0.6); padding: 12px 24px; border-radius: 12px; margin: 2px 12px; transition: all 0.3s; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { background: rgba(246, 211, 101, 0.12); color: #F6D365; }
        .sidebar .nav-link i { width: 24px; }
        .sidebar .nav-link.logout { color: #ef4444; margin-top: 20px; border-top: 1px solid rgba(255,255,255,0.06); border-radius: 0; padding-top: 20px; }
        .sidebar .nav-link.logout:hover { background: rgba(239, 68, 68, 0.12); }
        .main-content { padding: 30px; }
        .form-container { background: white; border-radius: 16px; padding: 30px; box-shadow: 0 2px 12px rgba(20,33,61,0.06); max-width: 600px; }
        .form-control { border-radius: 10px; border: 2px solid #F4F5F7; padding: 10px 14px; font-size: 14px; }
        .form-control:focus { border-color: #F6D365; box-shadow: 0 0 0 4px rgba(246, 211, 101, 0.15); }
        .btn-submit { background: #14213D; color: #F6D365; border-radius: 12px; padding: 12px 32px; font-weight: 600; border: none; transition: all 0.3s; }
        .btn-submit:hover { background: #0B162C; color: #F6D365; transform: translateY(-2px); box-shadow: 0 8px 25px rgba(20, 33, 61, 0.2); }
        .btn-cancel { background: #F4F5F7; color: #5B647A; border-radius: 12px; padding: 12px 32px; font-weight: 600; border: none; transition: all 0.3s; text-decoration: none; display: inline-block; }
        .btn-cancel:hover { background: #e8e9eb; color: #14213D; }
        .alert-custom { border-radius: 12px; padding: 16px 20px; }
        .form-label { font-weight: 600; font-size: 14px; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0 sidebar">
                <div class="brand">
                    <span class="icon">🌾</span>
                    <h5>Mekarwangi</h5>
                    <small>ADMIN PANEL</small>
                </div>
                <nav class="nav flex-column">
                    <a href="dashboard.php" class="nav-link"><i class="fas fa-chart-pie"></i> Dashboard</a>
                    <a href="umkm/index.php" class="nav-link"><i class="fas fa-store"></i> UMKM</a>
                    <a href="produk/index.php" class="nav-link"><i class="fas fa-box"></i> Produk</a>
                    <a href="kategori/index.php" class="nav-link"><i class="fas fa-tags"></i> Kategori</a>
                    <a href="ganti_password.php" class="nav-link active"><i class="fas fa-key"></i> Ganti Password</a>
                    <a href="logout.php" class="nav-link logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </nav>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h4 class="fw-bold mb-0">Ganti Password</h4>
                        <p class="text-muted mb-0">Ubah password akun admin Anda</p>
                    </div>
                    <a href="dashboard.php" class="btn-cancel">
                        <i class="fas fa-arrow-left me-2"></i> Kembali
                    </a>
                </div>
                
                <?php if ($success): ?>
                <div class="alert alert-success alert-custom">
                    <i class="fas fa-check-circle me-2"></i> <?php echo $success; ?>
                </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                <div class="alert alert-danger alert-custom">
                    <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error; ?>
                </div>
                <?php endif; ?>
                
                <div class="form-container">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Password Lama</label>
                            <input type="password" name="old_password" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Password Baru</label>
                            <input type="password" name="new_password" class="form-control" required minlength="6">
                            <small class="text-muted">Minimal 6 karakter</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Konfirmasi Password Baru</label>
                            <input type="password" name="confirm_password" class="form-control" required>
                        </div>
                        <div class="d-flex gap-3 mt-4">
                            <button type="submit" class="btn-submit">
                                <i class="fas fa-save me-2"></i> Ubah Password
                            </button>
                            <a href="dashboard.php" class="btn-cancel">Batal</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>