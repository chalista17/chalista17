<?php
// admin/login.php
session_start();

// Jika sudah login, langsung ke dashboard
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header('Location: dashboard.php');
    exit;
}

require_once '../config/database.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    
    if (empty($username) || empty($password)) {
        $error = 'Username dan password harus diisi!';
    } else {
        // Cek di database
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
        $stmt->execute(['username' => $username]);
        $user = $stmt->fetch();
        
        // Password di database menggunakan bcrypt (hash)
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_user'] = $user['username'];
            $_SESSION['admin_id'] = $user['id'];
            $_SESSION['login_time'] = time();
            
            header('Location: dashboard.php');
            exit;
        } else {
            $error = 'Username atau password salah!';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin - Mekarwangi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #F4F5F7 0%, #FFF9E8 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
            padding: 20px;
        }
        .login-container {
            background: white;
            border-radius: 24px;
            padding: 50px 40px;
            max-width: 420px;
            width: 100%;
            box-shadow: 0 20px 60px rgba(20, 33, 61, 0.15);
        }
        .login-container .brand {
            text-align: center;
            margin-bottom: 35px;
        }
        .login-container .brand .icon {
            font-size: 56px;
            display: block;
            margin-bottom: 8px;
        }
        .login-container .brand h4 {
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-weight: 800;
            color: #14213D;
            margin: 0;
        }
        .login-container .brand small {
            color: #5B647A;
            font-size: 13px;
            font-weight: 500;
        }
        .form-control {
            border-radius: 12px;
            padding: 12px 16px;
            border: 2px solid #F4F5F7;
            font-size: 14px;
            transition: all 0.3s;
        }
        .form-control:focus {
            border-color: #F6D365;
            box-shadow: 0 0 0 4px rgba(246, 211, 101, 0.15);
        }
        .btn-login {
            background: #14213D;
            color: #F6D365;
            border-radius: 12px;
            padding: 14px;
            font-weight: 600;
            border: none;
            width: 100%;
            transition: all 0.3s;
            font-size: 16px;
        }
        .btn-login:hover {
            background: #0B162C;
            color: #F6D365;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(20, 33, 61, 0.25);
        }
        .alert-custom {
            border-radius: 12px;
            padding: 12px 16px;
            font-size: 14px;
        }
        .form-label {
            font-weight: 600;
            font-size: 14px;
            color: #14213D;
        }
        .input-group-text {
            background: #F4F5F7;
            border: 2px solid #F4F5F7;
            border-radius: 12px 0 0 12px;
        }
        .input-group .form-control {
            border-radius: 0 12px 12px 0;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="brand">
            <span class="icon">🌾</span>
            <h4>Mekarwangi</h4>
            <small>Admin Panel • Desa Mekarwangi</small>
        </div>
        
        <?php if ($error): ?>
        <div class="alert alert-danger alert-custom">
            <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error; ?>
        </div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="mb-3">
                <label class="form-label"><i class="fas fa-user me-2"></i>Username</label>
                <input type="text" name="username" class="form-control" placeholder="Masukkan username" required autofocus>
            </div>
            <div class="mb-3">
                <label class="form-label"><i class="fas fa-lock me-2"></i>Password</label>
                <input type="password" name="password" class="form-control" placeholder="Masukkan password" required>
            </div>
            <button type="submit" class="btn-login">
                <i class="fas fa-sign-in-alt me-2"></i> Login
            </button>
        </form>
        
        <div class="text-center mt-3">
            <small class="text-muted">Default: admin / admin123</small>
        </div>
    </div>
</body>
</html>