<?php
// admin/dashboard.php - Dashboard Admin

session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

require_once '../config/database.php';

// Statistik
$total_umkm = getCount($pdo, 'umkm');
$total_produk = getCount($pdo, 'produk');
$total_kategori = getCount($pdo, 'kategori');
$total_umkm_aktif = $pdo->query("SELECT COUNT(*) as total FROM umkm WHERE status = 'aktif'")->fetch()['total'];

// UMKM terbaru
$stmt = $pdo->query("SELECT u.*, k.nama_kategori FROM umkm u 
                     LEFT JOIN kategori k ON u.kategori_id = k.id 
                     ORDER BY u.created_at DESC LIMIT 5");
$umkm_terbaru = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Katalog UMKM Desa Mekarwangi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background: #F4F5F7; }
        .sidebar { background: #14213D; min-height: 100vh; padding: 20px 0; }
        .sidebar .brand { text-align: center; padding: 0 20px 30px; border-bottom: 1px solid rgba(255,255,255,0.06); }
        .sidebar .brand .icon { font-size: 32px; display: block; }
        .sidebar .brand h5 { color: #F6D365; font-family: 'Plus Jakarta Sans', sans-serif; font-weight: 800; margin-top: 8px; }
        .sidebar .brand small { color: rgba(255,255,255,0.5); font-size: 11px; letter-spacing: 1px; }
        .sidebar .nav-link { color: rgba(255,255,255,0.6); padding: 12px 24px; border-radius: 12px; margin: 2px 12px; transition: all 0.3s; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { background: rgba(246, 211, 101, 0.12); color: #F6D365; }
        .sidebar .nav-link i { width: 24px; }
        .sidebar .nav-link.logout { color: #ef4444; margin-top: 20px; border-top: 1px solid rgba(255,255,255,0.06); border-radius: 0; padding-top: 20px; }
        .sidebar .nav-link.logout:hover { background: rgba(239, 68, 68, 0.12); }
        .main-content { padding: 30px; }
        .stat-card { background: white; border-radius: 16px; padding: 24px; box-shadow: 0 2px 12px rgba(20,33,61,0.06); }
        .stat-card .number { font-family: 'Plus Jakarta Sans', sans-serif; font-size: 32px; font-weight: 800; color: #14213D; }
        .stat-card .label { color: #5B647A; font-size: 14px; }
        .stat-card .icon { font-size: 28px; color: #F6D365; }
        .table-custom { background: white; border-radius: 16px; overflow: hidden; box-shadow: 0 2px 12px rgba(20,33,61,0.06); }
        .table-custom th { background: #F4F5F7; color: #14213D; font-weight: 600; font-size: 13px; border: none; padding: 12px 16px; }
        .table-custom td { padding: 12px 16px; vertical-align: middle; font-size: 14px; }
        .badge-status { padding: 4px 14px; border-radius: 50px; font-size: 11px; font-weight: 600; }
        .badge-status.aktif { background: #d4edda; color: #155724; }
        .badge-status.tidak_aktif { background: #f8d7da; color: #721c24; }
        .btn-action { padding: 4px 12px; font-size: 12px; border-radius: 8px; }
        .btn-action i { margin-right: 4px; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0 sidebar">
                <div class="brand">
                    <span class="icon">🌾</span>
                    <h5>Mekarwangi</h5>
                    <small>ADMIN PANEL</small>
                </div>
                <nav class="nav flex-column">
                    <a href="dashboard.php" class="nav-link active"><i class="fas fa-chart-pie"></i> Dashboard</a>
                    <a href="umkm/index.php" class="nav-link"><i class="fas fa-store"></i> UMKM</a>
                    <a href="produk/index.php" class="nav-link"><i class="fas fa-box"></i> Produk</a>
                    <a href="kategori/index.php" class="nav-link"><i class="fas fa-tags"></i> Kategori</a>
                    <a href="logout.php" class="nav-link logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </nav>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="fw-bold">Dashboard</h4>
                    <span class="text-muted">Welcome, <?php echo htmlspecialchars($_SESSION['admin_user']); ?></span>
                </div>
                
                <!-- Statistik -->
                <div class="row g-4 mb-4">
                    <div class="col-md-3">
                        <div class="stat-card">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <div class="number"><?php echo $total_umkm; ?></div>
                                    <div class="label">Total UMKM</div>
                                </div>
                                <div class="icon"><i class="fas fa-store"></i></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-card">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <div class="number"><?php echo $total_produk; ?></div>
                                    <div class="label">Total Produk</div>
                                </div>
                                <div class="icon"><i class="fas fa-box"></i></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-card">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <div class="number"><?php echo $total_kategori; ?></div>
                                    <div class="label">Total Kategori</div>
                                </div>
                                <div class="icon"><i class="fas fa-tags"></i></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-card">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <div class="number"><?php echo $total_umkm_aktif; ?></div>
                                    <div class="label">UMKM Aktif</div>
                                </div>
                                <div class="icon"><i class="fas fa-check-circle"></i></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- UMKM Terbaru -->
                <h5 class="fw-bold mb-3">UMKM Terbaru</h5>
                <div class="table-custom">
                    <table class="table mb-0">
                        <thead>
                            <tr>
                                <th>Foto</th>
                                <th>Nama UMKM</th>
                                <th>Kategori</th>
                                <th>Pemilik</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($umkm_terbaru as $umkm): ?>
                            <tr>
                                <td>
                                    <img src="../assets/images/<?php echo $umkm['foto'] ?? 'default-umkm.jpg'; ?>" 
                                         style="width: 40px; height: 40px; object-fit: cover; border-radius: 8px;"
                                         onerror="this.src='../assets/images/default-umkm.jpg'">
                                </td>
                                <td><strong><?php echo htmlspecialchars($umkm['nama_usaha']); ?></strong></td>
                                <td><?php echo htmlspecialchars($umkm['nama_kategori'] ?? '-'); ?></td>
                                <td><?php echo htmlspecialchars($umkm['pemilik']); ?></td>
                                <td>
                                    <span class="badge-status <?php echo $umkm['status']; ?>">
                                        <?php echo $umkm['status'] == 'aktif' ? 'Aktif' : 'Tidak Aktif'; ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="umkm/edit.php?id=<?php echo $umkm['id']; ?>" class="btn btn-sm btn-warning btn-action">
                                        <i class="fas fa-edit"></i> Edit
                                    </a>
                                    <a href="umkm/hapus.php?id=<?php echo $umkm['id']; ?>" class="btn btn-sm btn-danger btn-action" onclick="return confirm('Yakin ingin menghapus?')">
                                        <i class="fas fa-trash"></i> Hapus
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>