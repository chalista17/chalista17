<?php
// detail_umkm.php - Halaman Detail UMKM (PUBLIC)

require_once 'config/database.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    header('Location: umkm.php');
    exit;
}

$umkm = getUMKMDetail($pdo, $id);

if (!$umkm) {
    header('Location: umkm.php');
    exit;
}

$page_title = $umkm['nama_usaha'];
$produk_list = getProdukUMKM($pdo, $id);

include 'includes/header.php';
?>

<!-- Detail Header -->
<section class="detail-header">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <span class="badge-kategori"><?php echo htmlspecialchars($umkm['nama_kategori'] ?? 'UMKM'); ?></span>
                <h1><?php echo htmlspecialchars($umkm['nama_usaha']); ?></h1>
                <p style="color: var(--text-soft); font-size: 16px;">
                    <i class="fas fa-user"></i> Oleh: <?php echo htmlspecialchars($umkm['pemilik']); ?>
                </p>
            </div>
            <div class="col-lg-4 text-lg-end">
                <?php if (!empty($umkm['no_whatsapp'])): ?>
                <a href="https://wa.me/<?php echo $umkm['no_whatsapp']; ?>" 
                   class="btn-primary-custom" 
                   style="background: #25D366; color: white;"
                   target="_blank">
                    <i class="fab fa-whatsapp"></i> WhatsApp
                </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<!-- Detail Content -->
<section class="py-5">
    <div class="container">
        <div class="row g-4">
            <!-- Foto UMKM -->
            <div class="col-lg-6">
                <img src="assets/images/<?php echo $umkm['foto'] ?? 'default-umkm.jpg'; ?>" 
                     class="detail-foto" 
                     alt="<?php echo htmlspecialchars($umkm['nama_usaha']); ?>"
                     onerror="this.src='assets/images/default-umkm.jpg'">
            </div>
            
            <!-- Informasi -->
            <div class="col-lg-6">
                <div class="info-umkm">
                    <h4>Tentang Usaha</h4>
                    <p style="color: var(--text-soft); line-height: 1.8;">
                        <?php echo nl2br(htmlspecialchars($umkm['deskripsi'] ?? 'Deskripsi belum tersedia.')); ?>
                    </p>
                    <hr>
                    <div class="info-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <div>
                            <strong>Alamat</strong><br>
                            <?php echo htmlspecialchars($umkm['alamat'] ?? 'Alamat belum tersedia.'); ?>
                        </div>
                    </div>
                    <?php if (!empty($umkm['no_whatsapp'])): ?>
                    <div class="info-item">
                        <i class="fab fa-whatsapp"></i>
                        <div>
                            <strong>WhatsApp</strong><br>
                            <a href="https://wa.me/<?php echo $umkm['no_whatsapp']; ?>" target="_blank" style="color: var(--butter-yellow);">
                                <?php echo htmlspecialchars($umkm['no_whatsapp']); ?>
                            </a>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($umkm['instagram'])): ?>
                    <div class="info-item">
                        <i class="fab fa-instagram"></i>
                        <div>
                            <strong>Instagram</strong><br>
                            <a href="https://instagram.com/<?php echo ltrim($umkm['instagram'], '@'); ?>" target="_blank" style="color: var(--butter-yellow);">
                                <?php echo htmlspecialchars($umkm['instagram']); ?>
                            </a>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($umkm['google_maps'])): ?>
                    <div class="info-item">
                        <i class="fas fa-directions"></i>
                        <div>
                            <strong>Google Maps</strong><br>
                            <a href="<?php echo htmlspecialchars($umkm['google_maps']); ?>" target="_blank" style="color: var(--butter-yellow);">
                                Buka di Google Maps <i class="fas fa-external-link-alt"></i>
                            </a>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($umkm['no_whatsapp'])): ?>
                    <div class="mt-3">
                        <a href="https://wa.me/<?php echo $umkm['no_whatsapp']; ?>?text=Halo%20saya%20tertarik%20dengan%20produk%20<?php echo urlencode($umkm['nama_usaha']); ?>" 
                           class="btn-primary-custom" 
                           style="background: #25D366; color: white; width: 100%; justify-content: center;"
                           target="_blank">
                            <i class="fab fa-whatsapp"></i> Chat Langsung via WhatsApp
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Produk yang Ditawarkan -->
        <div class="mt-5">
            <h3 class="mb-4">Produk yang Ditawarkan</h3>
            <div class="row g-3">
                <?php if (count($produk_list) > 0): ?>
                    <?php foreach ($produk_list as $produk): ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="produk-card-simple">
                            <div class="produk-item">
                                <?php 
                                $foto_produk = 'assets/images/produk/' . ($produk['foto'] ?? '');
                                if (!empty($produk['foto']) && $produk['foto'] != 'default-produk.jpg' && file_exists($foto_produk)):
                                ?>
                                    <img src="<?php echo $foto_produk; ?>" 
                                         alt="<?php echo htmlspecialchars($produk['nama_produk']); ?>"
                                         style="width: 70px; height: 70px; min-width: 70px; object-fit: cover; border-radius: 10px;"
                                         onerror="this.style.display='none'">
                                <?php else: ?>
                                    <div class="produk-icon"><i class="fas fa-box"></i></div>
                                <?php endif; ?>
                                <div class="produk-info">
                                    <h6 class="produk-name"><?php echo htmlspecialchars($produk['nama_produk']); ?></h6>
                                    <p class="produk-desc"><?php echo htmlspecialchars($produk['deskripsi'] ?? 'Deskripsi belum tersedia'); ?></p>
                                    <?php if ($produk['harga'] && $produk['harga'] > 0): ?>
                                    <div class="produk-price">Rp <?php echo number_format($produk['harga'] ?? 0, 0, ',', '.'); ?></div>
                                    <?php endif; ?>
                                    <span class="badge-status <?php echo $produk['status'] == 'tersedia' ? 'available' : 'unavailable'; ?>">
                                        <?php echo $produk['status'] == 'tersedia' ? '✔ Tersedia' : '✗ Tidak Tersedia'; ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                <div class="col-12">
                    <div class="alert alert-info text-center">
                        <i class="fas fa-info-circle me-2"></i>
                        Belum ada produk yang ditawarkan oleh UMKM ini.
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Tombol Aksi -->
        <div class="mt-5 text-center">
            <div class="d-flex gap-3 justify-content-center flex-wrap">
                <?php if (!empty($umkm['no_whatsapp'])): ?>
                <a href="https://wa.me/<?php echo $umkm['no_whatsapp']; ?>?text=Halo%20saya%20tertarik%20dengan%20produk%20<?php echo urlencode($umkm['nama_usaha']); ?>" 
                   class="btn-primary-custom" 
                   style="background: #25D366; color: white;"
                   target="_blank">
                    <i class="fab fa-whatsapp"></i> Hubungi via WhatsApp
                </a>
                <?php endif; ?>
                <?php if (!empty($umkm['google_maps'])): ?>
                <a href="<?php echo htmlspecialchars($umkm['google_maps']); ?>" 
                   class="btn-outline-custom" 
                   target="_blank">
                    <i class="fas fa-map-marker-alt"></i> Lihat Lokasi
                </a>
                <?php endif; ?>
                <button class="btn-outline-custom" onclick="shareUMKM()">
                    <i class="fas fa-share-alt"></i> Bagikan
                </button>
            </div>
        </div>
    </div>
</section>

<script>
function shareUMKM() {
    if (navigator.share) {
        navigator.share({
            title: '<?php echo htmlspecialchars($umkm['nama_usaha']); ?> - Katalog UMKM Desa Mekarwangi',
            text: 'Kenali <?php echo htmlspecialchars($umkm['nama_usaha']); ?>, UMKM unggulan Desa Mekarwangi!',
            url: window.location.href
        }).catch(() => {});
    } else {
        const url = window.location.href;
        if (navigator.clipboard) {
            navigator.clipboard.writeText(url).then(() => alert('Link berhasil disalin!'));
        } else {
            prompt('Salin link ini:', url);
        }
    }
}
</script>

<?php include 'includes/footer.php'; ?>