// assets/js/script.js
// JavaScript untuk Katalog UMKM Desa Mekarwangi

document.addEventListener('DOMContentLoaded', function() {
    
    // ===== SEMUA EFEK REVEAL DINONAKTIFKAN =====
    // Card sudah tampil dengan opacity 1 dari CSS
    // Tidak ada lagi efek berkedip
    
    // ===== SMOOTH SCROLL =====
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            if (href === '#') return;
            e.preventDefault();
            const target = document.querySelector(href);
            if (target) {
                target.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
    
    // ===== NAVBAR SCROLL EFFECT =====
    const navbar = document.querySelector('.navbar');
    if (navbar) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                navbar.style.boxShadow = '0 4px 30px rgba(20, 33, 61, 0.12)';
            } else {
                navbar.style.boxShadow = '0 1px 20px rgba(20, 33, 61, 0.06)';
            }
        });
    }
    
    // ===== SEARCH AUTO-SUBMIT =====
    const searchInput = document.querySelector('input[name="search"]');
    if (searchInput) {
        searchInput.addEventListener('keyup', function(e) {
            if (e.key === 'Enter') {
                this.closest('form').submit();
            }
        });
    }
    
    // ===== WHATSAPP BUTTON =====
    document.querySelectorAll('.btn-wa').forEach(btn => {
        btn.addEventListener('click', function(e) {
            const number = this.dataset.phone;
            if (number) {
                window.open('https://wa.me/' + number, '_blank');
            }
        });
    });
    
    // ===== SHARE FUNCTION =====
    window.shareUMKM = function(url, title) {
        if (navigator.share) {
            navigator.share({
                title: title || 'UMKM Desa Mekarwangi',
                url: url || window.location.href
            }).catch(() => {});
        } else {
            const link = url || window.location.href;
            if (navigator.clipboard) {
                navigator.clipboard.writeText(link).then(() => {
                    alert('Link berhasil disalin!');
                }).catch(() => {
                    prompt('Salin link ini:', link);
                });
            } else {
                prompt('Salin link ini:', link);
            }
        }
    };
    
    // ===== CONFIRM DELETE =====
    document.querySelectorAll('.delete-confirm').forEach(el => {
        el.addEventListener('click', function(e) {
            if (!confirm('Yakin ingin menghapus data ini?')) {
                e.preventDefault();
            }
        });
    });
    
    // ===== PRICE FORMATTER =====
    document.querySelectorAll('.format-price').forEach(el => {
        const price = parseFloat(el.textContent);
        if (!isNaN(price)) {
            el.textContent = 'Rp ' + price.toLocaleString('id-ID');
        }
    });
    
    console.log('🌾 Katalog UMKM Desa Mekarwangi loaded!');
});