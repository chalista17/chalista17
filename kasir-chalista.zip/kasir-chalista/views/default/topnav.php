<?php
// topnav.php - Top Navigation Bar
require_once __DIR__ . '/../../lib/functions.php';
?>

<div class="d-flex align-items-center ms-auto">
    <div class="dropdown">
        <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="userDropdown" 
                data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fas fa-user-circle me-1"></i>
            <?php echo isset($_SESSION['username']) ? $_SESSION['username'] : 'Guest'; ?>
        </button>
        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
            <li>
                <a class="dropdown-item" href="#">
                    <i class="fas fa-user me-2"></i>Profil
                </a>
            </li>
            <li>
                <a class="dropdown-item" href="#">
                    <i class="fas fa-cog me-2"></i>Pengaturan
                </a>
            </li>
            <li><hr class="dropdown-divider"></li>
            <li>
                <a class="dropdown-item text-danger" href="logout.php">
                    <i class="fas fa-sign-out-alt me-2"></i>Logout
                </a>
            </li>
        </ul>
    </div>
</div>

<style>
.navbar .btn-outline-secondary {
    border-color: #dee2e6;
    color: #6c757d;
}

.navbar .btn-outline-secondary:hover {
    background-color: #6f42c1;
    border-color: #6f42c1;
    color: white;
}
</style>