<?php
// footer.php - Footer content
?>
<footer class="mt-5 pt-3 border-top">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <p class="text-muted mb-0">
                    <i class="fas fa-copyright me-1"></i>
                    <?php echo date('Y'); ?> Kasir Chalista Hijab
                </p>
            </div>
            <div class="col-md-6 text-end">
                <p class="text-muted mb-0">
                    <i class="fas fa-code me-1"></i>
                    Version 1.0.0
                </p>
            </div>
        </div>
    </div>
</footer>