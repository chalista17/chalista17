<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' - ' : ''; ?>Kasir Chalista Hijab</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        /* Global Styles */
        :root {
            --primary-color: #6f42c1;
            --secondary-color: #5a32a3;
            --success-color: #28a745;
            --danger-color: #dc3545;
            --warning-color: #ffc107;
            --info-color: #17a2b8;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            min-height: 100vh;
            overflow-x: hidden;
            padding-top: 0;
            margin: 0;
        }

        /* Layout */
        .app-container {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 250px;
            background: linear-gradient(180deg, #6f42c1 0%, #5a32a3 100%);
            color: white;
            position: fixed;
            left: 0;
            top: 0;
            height: 100vh;
            z-index: 1000;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            display: flex;
            flex-direction: column;
        }

        /* PERBAIKAN UTAMA: Main Content dengan padding atas */
        .main-content {
            flex: 1;
            margin-left: 250px;
            min-height: 100vh;
            background-color: #f8f9fa;
            transition: margin-left 0.3s ease;
            padding-top: 70px; /* PERBESAR padding atas untuk memberi jarak dari navbar */
        }

        /* Navigation */
        .navbar {
            background-color: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            height: 60px;
            position: fixed; /* Ubah dari sticky ke fixed */
            top: 0;
            right: 0;
            left: 250px; /* Sesuaikan dengan sidebar */
            z-index: 999;
            padding: 0 1.5rem;
            transition: all 0.3s ease;
        }

        /* Cards */
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            margin-bottom: 1.5rem;
        }

        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0,0,0,0.1);
        }

        .stat-card {
            border-radius: 12px;
            overflow: hidden;
            border: none !important;
        }

        .stat-card .card-body {
            padding: 1.5rem;
        }

        /* Buttons */
        .btn {
            border-radius: 8px;
            font-weight: 500;
            padding: 0.5rem 1.5rem;
            transition: all 0.2s ease;
        }

        .btn-lg {
            padding: 0.75rem 2rem;
        }

        .btn-primary {
            background: linear-gradient(135deg, #6f42c1, #5a32a3);
            border: none;
        }

        .btn-primary:hover {
            background: linear-gradient(135deg, #5a32a3, #4a2b8c);
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(111, 66, 193, 0.3);
        }

        .btn-success {
            background: linear-gradient(135deg, #28a745, #1e7e34);
            border: none;
        }

        .btn-success:hover {
            background: linear-gradient(135deg, #1e7e34, #155724);
        }

        /* Badges */
        .badge {
            padding: 0.4em 0.8em;
            border-radius: 20px;
            font-weight: 500;
        }

        .badge-success {
            background-color: rgba(40, 167, 69, 0.1);
            color: #28a745;
        }

        .badge-warning {
            background-color: rgba(255, 193, 7, 0.1);
            color: #856404;
        }

        .badge-danger {
            background-color: rgba(220, 53, 69, 0.1);
            color: #dc3545;
        }

        /* Tables */
        .table {
            --bs-table-bg: transparent;
            --bs-table-striped-bg: rgba(0, 0, 0, 0.02);
        }

        .table th {
            background-color: #f8f9fa;
            color: #495057;
            font-weight: 600;
            border-bottom: 2px solid #dee2e6;
            padding: 0.75rem 1rem;
        }

        .table td {
            padding: 1rem;
            vertical-align: middle;
            border-color: #f1f3f4;
        }

        /* Forms */
        .form-control, .form-select {
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 0.5rem 1rem;
            transition: all 0.2s ease;
        }

        .form-control:focus, .form-select:focus {
            border-color: #6f42c1;
            box-shadow: 0 0 0 0.25rem rgba(111, 66, 193, 0.25);
        }

        /* Page Header - PERBAIKAN: Tambahkan margin atas */
        .page-header {
            margin-bottom: 2rem;
            padding: 0 1.5rem;
            margin-top: 20px; /* Tambahkan margin atas */
        }

        .page-title {
            color: #6f42c1;
            font-weight: 600;
            margin-bottom: 0.5rem;
            font-size: 1.75rem;
        }

        /* Breadcrumb */
        .breadcrumb {
            background-color: transparent;
            padding: 0.5rem 0;
            margin-bottom: 1.5rem;
        }

        .breadcrumb-item a {
            color: #6c757d;
            text-decoration: none;
        }

        .breadcrumb-item.active {
            color: #6f42c1;
            font-weight: 500;
        }

        /* Alerts - PERBAIKAN: Tambahkan margin atas */
        .alert {
            border: none;
            border-radius: 8px;
            padding: 1rem 1.5rem;
            margin: 20px 1.5rem 1.5rem 1.5rem; /* Tambahkan margin atas */
        }

        /* Progress bars */
        .progress {
            height: 8px;
            border-radius: 4px;
            background-color: #f1f3f4;
        }

        .progress-bar {
            border-radius: 4px;
        }

        /* Sidebar Specific */
        .sidebar-header {
            padding: 1.5rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center;
        }

        .sidebar-menu {
            padding: 1rem 0;
            flex: 1;
            overflow-y: auto;
        }

        .sidebar-menu .nav {
            padding: 0 0.5rem;
        }

        .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 0.75rem 1rem;
            margin: 0.25rem 0;
            border-radius: 8px;
            transition: all 0.2s ease;
            border-left: 3px solid transparent;
            display: flex;
            align-items: center;
        }

        .nav-link:hover {
            color: white;
            background: rgba(255, 255, 255, 0.1);
            border-left-color: rgba(255, 255, 255, 0.3);
        }

        .nav-link.active {
            color: white;
            background: rgba(255, 255, 255, 0.15);
            border-left-color: white;
            font-weight: 500;
        }

        .nav-link i {
            width: 20px;
            text-align: center;
            margin-right: 10px;
            font-size: 1.1rem;
        }

        /* Quick Action Buttons */
        .quick-action-btn {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 1.5rem;
            border-radius: 10px;
            transition: all 0.3s ease;
            text-decoration: none;
            color: inherit;
        }

        .quick-action-btn:hover {
            transform: translateY(-5px);
        }

        /* Status Badges */
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.875rem;
            font-weight: 500;
        }

        /* Chart Container */
        .chart-container {
            position: relative;
            height: 250px;
            width: 100%;
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .sidebar {
                margin-left: -250px;
                width: 250px;
            }
            
            .sidebar.show {
                margin-left: 0;
            }
            
            .main-content {
                margin-left: 0;
                padding-top: 60px; /* Sesuaikan untuk mobile */
            }
            
            .navbar {
                left: 0;
                padding: 0 1rem;
            }
            
            .stat-card {
                margin-bottom: 1rem;
            }
            
            .page-header {
                padding: 0 1rem;
                margin-top: 15px; /* Sesuaikan untuk mobile */
            }
            
            .alert {
                margin: 15px 1rem 1rem 1rem; /* Sesuaikan untuk mobile */
            }
        }

        /* Animations */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .fade-in {
            animation: fadeIn 0.3s ease-out;
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 6px;
        }

        ::-webkit-scrollbar-track {
            background: rgba(255, 255, 255, 0.1);
        }

        ::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.3);
            border-radius: 3px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: rgba(255, 255, 255, 0.5);
        }

        /* Content Area - PERBAIKAN: Tambahkan padding atas */
        .content-area {
            padding: 15px 1.5rem 0; /* Tambahkan padding atas */
        }

        @media (max-width: 768px) {
            .content-area {
                padding: 10px 1rem 0; /* Sesuaikan untuk mobile */
            }
        }

        /* User Dropdown */
        .user-dropdown-btn {
            border: 1px solid #dee2e6;
            background: white;
            color: #495057;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .user-dropdown-btn:hover {
            background: #f8f9fa;
            border-color: #6f42c1;
        }

        /* Footer */
        .main-footer {
            background: white;
            border-top: 1px solid #dee2e6;
            padding: 1rem 1.5rem;
            margin-top: auto;
        }

        /* Spacing Utilities */
        .mt-6 {
            margin-top: 4rem !important;
        }
        
        .pt-6 {
            padding-top: 4rem !important;
        }
        
        .spacer-top {
            margin-top: 30px;
        }
        
        .content-spacer {
            padding-top: 20px;
        }
    </style>
</head>
<body>
    <?php
    // Dapatkan current page untuk active menu
    $current_page = basename($_SERVER['PHP_SELF']);
    $base_path = isset($base_url) ? $base_url : '../';
    ?>
    
    <div class="app-container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="d-flex align-items-center justify-content-center mb-3">
                    <div class="bg-white bg-opacity-25 rounded-circle p-3 me-3">
                        <i class="fas fa-cash-register fa-lg"></i>
                    </div>
                    <div>
                        <h4 class="mb-0 fw-bold">Chalista Hijab</h4>
                        <p class="mb-0 small opacity-75">Sistem Kasir</p>
                    </div>
                </div>
            </div>
            
            <!-- Sidebar Menu -->
            <div class="sidebar-menu">
                <ul class="nav flex-column">
                    <!-- Dashboard -->
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($current_page == 'index.php') ? 'active' : ''; ?>" 
                           href="<?php echo $base_path; ?>admin/index.php">
                            <i class="fas fa-home"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    
                    <!-- Barang -->
                    <li class="nav-item">
                        <a class="nav-link <?php echo (strpos($current_page, 'barang') !== false) ? 'active' : ''; ?>" 
                           href="<?php echo $base_path; ?>barang/index.php">
                            <i class="fas fa-box"></i>
                            <span>Barang</span>
                        </a>
                    </li>
                    
                    <!-- Penjualan -->
                    <li class="nav-item">
                        <a class="nav-link <?php echo (strpos($current_page, 'penjualan') !== false && strpos($current_page, 'detail') === false) ? 'active' : ''; ?>" 
                           href="<?php echo $base_path; ?>penjualan/index.php">
                            <i class="fas fa-shopping-cart"></i>
                            <span>Penjualan</span>
                        </a>
                    </li>
                    
                    <!-- Detail Penjualan -->
                    <li class="nav-item">
                        <a class="nav-link <?php echo (strpos($current_page, 'detail') !== false || strpos($current_page, 'penjualan_detail') !== false) ? 'active' : ''; ?>" 
                           href="<?php echo $base_path; ?>penjualan_detail/index.php">
                            <i class="fas fa-list"></i>
                            <span>Detail Penjualan</span>
                        </a>
                    </li>
                    
                    <!-- Pengguna -->
                    <li class="nav-item">
                        <a class="nav-link <?php echo (strpos($current_page, 'users') !== false || strpos($current_page, 'user') !== false) ? 'active' : ''; ?>" 
                           href="<?php echo $base_path; ?>users/index.php">
                            <i class="fas fa-users"></i>
                            <span>Pengguna</span>
                        </a>
                    </li>
                    
                    <!-- Laporan -->
                    <li class="nav-item">
                        <a class="nav-link <?php echo (strpos($current_page, 'laporan') !== false || strpos($current_page, 'report') !== false) ? 'active' : ''; ?>" 
                           href="<?php echo $base_path; ?>laporan/index.php">
                            <i class="fas fa-chart-bar"></i>
                            <span>Laporan</span>
                        </a>
                    </li>
                    
                    <!-- Separator -->
                    <li class="nav-item mt-3">
                        <hr class="dropdown-divider opacity-25 mx-3">
                    </li>
                    
                    <!-- Settings -->
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo $base_path; ?>settings/index.php">
                            <i class="fas fa-cog"></i>
                            <span>Pengaturan</span>
                        </a>
                    </li>
                    
                    <!-- Logout -->
                    <li class="nav-item">
                        <a class="nav-link text-danger" href="<?php echo $base_path; ?>logout.php">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>Logout</span>
                        </a>
                    </li>
                </ul>
            </div>
            
            <!-- User Info -->
            <div class="sidebar-footer p-3 border-top border-white border-opacity-10">
                <div class="d-flex align-items-center">
                    <div class="flex-shrink-0">
                        <div class="bg-white bg-opacity-25 rounded-circle p-2">
                            <i class="fas fa-user-circle"></i>
                        </div>
                    </div>
                    <div class="flex-grow-1 ms-3">
                        <small class="d-block fw-medium opacity-90">
                            <?php echo isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'Admin'; ?>
                        </small>
                        <span class="badge bg-info bg-opacity-25 text-info border border-info border-opacity-25">
                            Administrator
                        </span>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Navigation - FIXED NAVBAR -->
            <nav class="navbar navbar-expand-lg navbar-light">
                <div class="container-fluid px-0">
                    <button class="btn btn-outline-secondary d-md-none" type="button" id="sidebarToggle">
                        <i class="fas fa-bars"></i>
                        <span class="visually-hidden">Toggle Menu</span>
                    </button>
                    
                    <!-- Page Title untuk Mobile -->
                    <div class="navbar-title d-md-none ms-3">
                        <h6 class="mb-0 text-truncate" style="max-width: 200px;">
                            <?php echo isset($pageTitle) ? $pageTitle : 'Dashboard'; ?>
                        </h6>
                    </div>
                    
                    <!-- Right Side: User Menu & Notifications -->
                    <div class="d-flex align-items-center ms-auto">
                        <!-- Notifications (Optional) -->
                        <div class="dropdown me-3 d-none d-md-block">
                            <button class="btn btn-light btn-sm position-relative" type="button" 
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-bell"></i>
                                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                    3
                                </span>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><h6 class="dropdown-header">Notifikasi</h6></li>
                                <li><a class="dropdown-item" href="#">Pesanan baru #1234</a></li>
                                <li><a class="dropdown-item" href="#">Stok barang hampir habis</a></li>
                                <li><a class="dropdown-item" href="#">Pembayaran diterima</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="#">Lihat semua notifikasi</a></li>
                            </ul>
                        </div>
                        
                        <!-- User Menu -->
                        <div class="dropdown">
                            <button class="user-dropdown-btn" type="button" 
                                    id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                <div class="d-flex align-items-center">
                                    <div class="flex-shrink-0">
                                        <i class="fas fa-user-circle fs-5 text-primary"></i>
                                    </div>
                                    <div class="flex-grow-1 ms-2 d-none d-md-block">
                                        <div class="fw-medium">
                                            <?php echo isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'Admin'; ?>
                                        </div>
                                        <div class="small text-muted">Administrator</div>
                                    </div>
                                    <i class="fas fa-chevron-down ms-2 text-muted"></i>
                                </div>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end shadow-sm" aria-labelledby="userDropdown">
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <i class="fas fa-user me-2"></i>Profil Saya
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <i class="fas fa-cog me-2"></i>Pengaturan
                                    </a>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <a class="dropdown-item text-danger" href="<?php echo $base_path; ?>logout.php">
                                        <i class="fas fa-sign-out-alt me-2"></i>Logout
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>
            
            <!-- Content Area dengan spacing yang baik -->
            <div class="content-area content-spacer">
                <!-- Page Header (Desktop) -->
                <div class="page-header d-none d-md-block">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <h1 class="page-title">
                                <?php echo isset($pageTitle) ? $pageTitle : 'Dashboard'; ?>
                            </h1>
                            <?php if(isset($breadcrumbs)): ?>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb mb-0">
                                    <?php foreach($breadcrumbs as $index => $crumb): ?>
                                    <li class="breadcrumb-item <?php echo ($index == count($breadcrumbs) - 1) ? 'active' : ''; ?>">
                                        <?php if($index < count($breadcrumbs) - 1): ?>
                                        <a href="<?php echo $crumb['url']; ?>" class="text-decoration-none">
                                            <?php if(isset($crumb['icon'])): ?>
                                            <i class="<?php echo $crumb['icon']; ?> me-1"></i>
                                            <?php endif; ?>
                                            <?php echo $crumb['name']; ?>
                                        </a>
                                        <?php else: ?>
                                        <?php if(isset($crumb['icon'])): ?>
                                        <i class="<?php echo $crumb['icon']; ?> me-1"></i>
                                        <?php endif; ?>
                                        <?php echo $crumb['name']; ?>
                                        <?php endif; ?>
                                    </li>
                                    <?php endforeach; ?>
                                </ol>
                            </nav>
                            <?php endif; ?>
                        </div>
                        
                        <?php if(isset($actionButtons)): ?>
                        <div class="d-flex gap-2">
                            <?php foreach($actionButtons as $button): ?>
                            <a href="<?php echo $button['url']; ?>" class="btn <?php echo $button['class']; ?>">
                                <i class="<?php echo $button['icon']; ?> me-2"></i>
                                <?php echo $button['text']; ?>
                            </a>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Main Content -->
                <?php if(isset($content)): ?>
                    <div class="fade-in">
                        <?php echo $content; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-info-circle fa-4x text-muted mb-4"></i>
                        <h5 class="text-muted mb-3">Tidak ada konten untuk ditampilkan</h5>
                        <p class="text-muted">Silakan pilih menu yang tersedia di sidebar.</p>
                    </div>
                <?php endif; ?>
                
                <!-- Footer -->
                <footer class="main-footer mt-5">
                    <div class="row">
                        <div class="col-md-6">
                            <p class="text-muted mb-0">
                                <i class="fas fa-copyright me-1"></i>
                                <?php echo date('Y'); ?> Kasir Chalista Hijab
                            </p>
                        </div>
                        <div class="col-md-6 text-md-end">
                            <p class="text-muted mb-0">
                                <i class="fas fa-code me-1"></i>
                                Version 1.0.0
                            </p>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Responsive sidebar toggle
        document.addEventListener('DOMContentLoaded', function() {
            const sidebarToggle = document.getElementById('sidebarToggle');
            const sidebar = document.getElementById('sidebar');
            const navbar = document.querySelector('.navbar');
            
            if (sidebarToggle && sidebar) {
                sidebarToggle.addEventListener('click', function() {
                    sidebar.classList.toggle('show');
                    
                    // Adjust navbar position when sidebar is toggled on mobile
                    if (window.innerWidth <= 768) {
                        if (sidebar.classList.contains('show')) {
                            navbar.style.left = '250px';
                        } else {
                            navbar.style.left = '0';
                        }
                    }
                });
                
                // Close sidebar when clicking outside on mobile
                document.addEventListener('click', function(event) {
                    if (window.innerWidth <= 768) {
                        if (!sidebar.contains(event.target) && !sidebarToggle.contains(event.target)) {
                            sidebar.classList.remove('show');
                            navbar.style.left = '0';
                        }
                    }
                });
            }
            
            // Adjust navbar position on window resize
            window.addEventListener('resize', function() {
                const sidebar = document.getElementById('sidebar');
                const navbar = document.querySelector('.navbar');
                
                if (window.innerWidth > 768) {
                    sidebar.classList.remove('show');
                    navbar.style.left = '250px';
                } else {
                    if (sidebar.classList.contains('show')) {
                        navbar.style.left = '250px';
                    } else {
                        navbar.style.left = '0';
                    }
                }
            });
            
            // Auto-hide alerts after 5 seconds
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                setTimeout(() => {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                }, 5000);
            });
            
            // Initialize tooltips
            const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
            
            // Add active class to current menu item
            const currentPath = window.location.pathname;
            const menuItems = document.querySelectorAll('.sidebar .nav-link');
            
            menuItems.forEach(item => {
                const href = item.getAttribute('href');
                if (href && currentPath.includes(href.replace('../', '').replace('./', ''))) {
                    item.classList.add('active');
                }
            });
        });
    </script>
</body>
</html>