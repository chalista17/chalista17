<style>
/* Tambahkan ini di akhir file sidebar.php */
.sidebar {
    width: 250px;
}

.sidebar-header {
    padding: 1.5rem;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.sidebar-menu {
    padding: 1rem 0;
}

.nav-link {
    color: rgba(255, 255, 255, 0.8);
    padding: 0.75rem 1.5rem;
    margin: 0.25rem 0.5rem;
    border-radius: 8px;
    transition: all 0.2s ease;
    border-left: 3px solid transparent;
}

.nav-link:hover {
    color: white;
    background: rgba(255, 255, 255, 0.1);
    border-left-color: rgba(255, 255, 255, 0.3);
}

.nav-link.active {
    color: white;
    background: rgba(255, 255, 255, 0.15);
    border-left-color: white;
    font-weight: 500;
}

.nav-link i {
    width: 20px;
    text-align: center;
    margin-right: 10px;
}
</style>