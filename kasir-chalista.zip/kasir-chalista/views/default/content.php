<?php
// content.php - Main content area
?>

<!-- Page Header -->
<div class="page-header mb-4">
    <div class="d-flex justify-content-between align-items-start">
        <div>
            <h1 class="page-title mb-2">
                <?php echo isset($pageTitle) ? $pageTitle : 'Dashboard'; ?>
            </h1>
            <?php if(isset($breadcrumbs)): ?>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <?php foreach($breadcrumbs as $index => $crumb): ?>
                    <li class="breadcrumb-item <?php echo ($index == count($breadcrumbs) - 1) ? 'active' : ''; ?>">
                        <?php if($index < count($breadcrumbs) - 1): ?>
                        <a href="<?php echo $crumb['url']; ?>" class="text-decoration-none">
                            <?php if(isset($crumb['icon'])): ?>
                            <i class="<?php echo $crumb['icon']; ?> me-1"></i>
                            <?php endif; ?>
                            <?php echo $crumb['name']; ?>
                        </a>
                        <?php else: ?>
                        <?php if(isset($crumb['icon'])): ?>
                        <i class="<?php echo $crumb['icon']; ?> me-1"></i>
                        <?php endif; ?>
                        <?php echo $crumb['name']; ?>
                        <?php endif; ?>
                    </li>
                    <?php endforeach; ?>
                </ol>
            </nav>
            <?php endif; ?>
        </div>
        
        <?php if(isset($actionButtons)): ?>
        <div class="d-flex gap-2">
            <?php foreach($actionButtons as $button): ?>
            <a href="<?php echo $button['url']; ?>" class="btn <?php echo $button['class']; ?>">
                <i class="<?php echo $button['icon']; ?> me-2"></i>
                <?php echo $button['text']; ?>
            </a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Flash Messages -->
<?php if(isset($_SESSION['flash_message'])): 
    $flash = $_SESSION['flash_message'];
    unset($_SESSION['flash_message']);
?>
<div class="alert <?php echo $flash['class']; ?> alert-dismissible fade show mb-4" role="alert">
    <div class="d-flex align-items-center">
        <i class="fas fa-info-circle me-3 fs-5"></i>
        <div class="flex-grow-1">
            <?php echo $flash['message']; ?>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
</div>
<?php endif; ?>

<!-- Main Content -->
<?php if(isset($content)): ?>
    <?php echo $content; ?>
<?php else: ?>
    <div class="text-center py-5">
        <i class="fas fa-info-circle fa-4x text-muted mb-4"></i>
        <h5 class="text-muted mb-3">Tidak ada konten untuk ditampilkan</h5>
        <p class="text-muted">Silakan pilih menu yang tersedia di sidebar.</p>
    </div>
<?php endif; ?>