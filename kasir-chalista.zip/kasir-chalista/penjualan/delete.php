<?php
require_once '../lib/auth.php';
require_once '../lib/functions.php';

$auth = new Auth();
$auth->checkAuth();

$db = Database::getInstance()->getConnection();

$id = $_GET['id'] ?? 0;

// Start transaction
$db->begin_transaction();

try {
    // Get penjualan details to restore stock
    $detailSql = "SELECT pd.id_barang, pd.qty 
                  FROM penjualan_detail pd 
                  WHERE pd.id_penjualan = ?";
    $detailStmt = $db->prepare($detailSql);
    $detailStmt->bind_param("i", $id);
    $detailStmt->execute();
    $details = $detailStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
    // Restore stock
    foreach ($details as $detail) {
        $restoreSql = "UPDATE barang SET stok = stok + ? WHERE id_barang = ?";
        $restoreStmt = $db->prepare($restoreSql);
        $restoreStmt->bind_param("ii", $detail['qty'], $detail['id_barang']);
        $restoreStmt->execute();
    }
    
    // Delete penjualan_detail first (foreign key constraint)
    $deleteDetailSql = "DELETE FROM penjualan_detail WHERE id_penjualan = ?";
    $deleteDetailStmt = $db->prepare($deleteDetailSql);
    $deleteDetailStmt->bind_param("i", $id);
    $deleteDetailStmt->execute();
    
    // Delete penjualan
    $deletePenjualanSql = "DELETE FROM penjualan WHERE id_penjualan = ?";
    $deletePenjualanStmt = $db->prepare($deletePenjualanSql);
    $deletePenjualanStmt->bind_param("i", $id);
    
    if ($deletePenjualanStmt->execute()) {
        $db->commit();
        flash('flash_message', 'Transaksi berhasil dihapus!', 'alert alert-success');
    } else {
        throw new Exception("Gagal menghapus transaksi");
    }
    
} catch (Exception $e) {
    $db->rollback();
    flash('flash_message', 'Gagal menghapus transaksi: ' . $e->getMessage(), 'alert alert-danger');
}

redirect('index.php');
?>