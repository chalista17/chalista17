<?php
require_once '../lib/auth.php';
require_once '../lib/functions.php';

$auth = new Auth();
$auth->checkAuth();

$db = Database::getInstance()->getConnection();

$error = '';
$success = '';

// Get barang list
$barangStmt = $db->prepare("SELECT * FROM barang WHERE stok > 0 ORDER BY nama_barang");
$barangStmt->execute();
$barangList = $barangStmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cart_items = json_decode($_POST['cart_items'], true) ?? [];
    $metode_pembayaran = $_POST['metode_pembayaran'] ?? 'CASH';
    $bayar = $_POST['bayar'] ?? 0;
    $status_bayar = $_POST['status_bayar'] ?? 'LUNAS';
    
    if (empty($cart_items)) {
        $error = 'Keranjang belanja kosong!';
    } else {
        // Calculate total
        $total = 0;
        foreach ($cart_items as $item) {
            $total += $item['subtotal'];
        }
        
        $kembalian = $bayar - $total;
        
        if ($status_bayar == 'LUNAS' && $kembalian < 0) {
            $error = 'Pembayaran kurang dari total!';
        } else {
            // Start transaction
            $db->begin_transaction();
            
            try {
                // Insert penjualan
                $penjualanSql = "INSERT INTO penjualan (tanggal, total, bayar, kembalian, metode_pembayaran, status_bayar) 
                                VALUES (NOW(), ?, ?, ?, ?, ?)";
                $penjualanStmt = $db->prepare($penjualanSql);
                $penjualanStmt->bind_param("iiiss", $total, $bayar, $kembalian, $metode_pembayaran, $status_bayar);
                
                if (!$penjualanStmt->execute()) {
                    throw new Exception("Gagal menyimpan transaksi: " . $penjualanStmt->error);
                }
                
                $penjualan_id = $db->insert_id;
                
                // Prepare detail statement
                $detailSql = "INSERT INTO penjualan_detail (id_penjualan, id_barang, qty, harga, subtotal) 
                             VALUES (?, ?, ?, ?, ?)";
                $detailStmt = $db->prepare($detailSql);
                
                // Insert penjualan_detail and update stock
                foreach ($cart_items as $item) {
                    // Insert detail
                    $detailStmt->bind_param("iiiii", $penjualan_id, $item['id_barang'], $item['qty'], $item['harga'], $item['subtotal']);
                    
                    if (!$detailStmt->execute()) {
                        throw new Exception("Gagal menyimpan detail: " . $detailStmt->error);
                    }
                    
                    // Update stock
                    $updateStockSql = "UPDATE barang SET stok = stok - ? WHERE id_barang = ?";
                    $updateStockStmt = $db->prepare($updateStockSql);
                    $updateStockStmt->bind_param("ii", $item['qty'], $item['id_barang']);
                    
                    if (!$updateStockStmt->execute()) {
                        throw new Exception("Gagal update stok: " . $updateStockStmt->error);
                    }
                    
                    // Check if stock becomes negative
                    $checkStockSql = "SELECT stok FROM barang WHERE id_barang = ?";
                    $checkStockStmt = $db->prepare($checkStockSql);
                    $checkStockStmt->bind_param("i", $item['id_barang']);
                    $checkStockStmt->execute();
                    $stockResult = $checkStockStmt->get_result()->fetch_assoc();
                    
                    if ($stockResult['stok'] < 0) {
                        throw new Exception("Stok barang tidak mencukupi!");
                    }
                }
                
                $db->commit();
                
                // Set success message
                $_SESSION['flash_message'] = [
                    'message' => 'Transaksi berhasil disimpan! ID: #' . $penjualan_id,
                    'type' => 'success'
                ];
                
                // Redirect to index
                header("Location: index.php");
                exit();
                
            } catch (Exception $e) {
                $db->rollback();
                $error = $e->getMessage();
            }
        }
    }
}

$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => '../admin/index.php', 'icon' => 'fas fa-home'],
    ['name' => 'Penjualan', 'url' => 'index.php', 'icon' => 'fas fa-shopping-cart'],
    ['name' => 'Transaksi Baru', 'url' => 'add.php', 'active' => true]
];

$pageTitle = 'Transaksi Baru';

$actionButtons = [
    [
        'url' => 'index.php',
        'class' => 'btn btn-outline-secondary',
        'icon' => 'fas fa-arrow-left',
        'text' => 'Kembali ke Daftar'
    ]
];

ob_start();
?>

<!-- Error Alert -->
<?php if ($error): ?>
<div class="alert alert-danger alert-dismissible fade show mb-4" role="alert">
    <i class="fas fa-exclamation-triangle me-2"></i>
    <?php echo htmlspecialchars($error); ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<div class="row">
    <!-- Left Column: Product Selection -->
    <div class="col-md-8">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white border-0 py-3">
                <h5 class="mb-1"><i class="fas fa-boxes text-primary me-2"></i>Pilih Barang</h5>
                <p class="text-muted mb-0 small">Tambahkan barang dari stok yang tersedia</p>
            </div>
            <div class="card-body">
                <!-- Product Selection Form -->
                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <select id="barang_select" class="form-select">
                            <option value="">-- Pilih Barang --</option>
                            <?php foreach ($barangList as $barang): ?>
                            <option value="<?php echo $barang['id_barang']; ?>"
                                    data-nama="<?php echo htmlspecialchars($barang['nama_barang']); ?>"
                                    data-harga="<?php echo $barang['harga']; ?>"
                                    data-stok="<?php echo $barang['stok']; ?>">
                                <?php echo htmlspecialchars($barang['nama_barang']); ?>
                                - Rp <?php echo number_format($barang['harga'], 0, ',', '.'); ?>
                                (Stok: <?php echo $barang['stok']; ?>)
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <div class="input-group">
                            <span class="input-group-text">Qty</span>
                            <input type="number" id="qty_input" class="form-control" 
                                   min="1" value="1" placeholder="Jumlah">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <button type="button" id="add_to_cart" class="btn btn-success w-100">
                            <i class="fas fa-cart-plus me-2"></i>Tambah
                        </button>
                    </div>
                </div>
                
                <!-- Cart Table -->
                <div class="table-responsive">
                    <table class="table table-hover" id="cart_table">
                        <thead class="table-light">
                            <tr>
                                <th>Nama Barang</th>
                                <th class="text-end">Harga</th>
                                <th class="text-center">Qty</th>
                                <th class="text-end">Subtotal</th>
                                <th class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="cart_body">
                            <!-- Cart items will be inserted here by JavaScript -->
                        </tbody>
                        <tfoot id="cart_footer">
                            <!-- Cart summary will be inserted here -->
                        </tfoot>
                    </table>
                </div>
                
                <!-- Empty Cart Message -->
                <div id="empty_cart_message" class="text-center py-5" style="display: none;">
                    <i class="fas fa-shopping-cart fa-3x text-muted mb-3"></i>
                    <h5 class="text-muted">Keranjang Kosong</h5>
                    <p class="text-muted">Tambahkan barang dari daftar di atas</p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Right Column: Payment Information -->
    <div class="col-md-4">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white border-0 py-3">
                <h5 class="mb-1"><i class="fas fa-credit-card text-success me-2"></i>Pembayaran</h5>
                <p class="text-muted mb-0 small">Lengkapi informasi pembayaran</p>
            </div>
            <div class="card-body">
                <form method="POST" action="" id="payment_form">
                    <!-- Hidden input for cart items -->
                    <input type="hidden" name="cart_items" id="cart_items_input" value="[]">
                    
                    <!-- Total Amount -->
                    <div class="mb-3">
                        <label class="form-label">Total Pembelian</label>
                        <div class="input-group">
                            <span class="input-group-text">Rp</span>
                            <input type="text" class="form-control fw-bold text-end" 
                                   id="total_display" value="0" readonly>
                            <input type="hidden" name="total" id="total_input" value="0">
                        </div>
                    </div>
                    
                    <!-- Payment Method -->
                    <div class="mb-3">
                        <label for="metode_pembayaran" class="form-label">Metode Pembayaran</label>
                        <select class="form-select" id="metode_pembayaran" name="metode_pembayaran">
                            <option value="CASH">TUNAI</option>
                            <option value="TRANSFER">TRANSFER</option>
                            <option value="DEBIT">KARTU DEBIT</option>
                            <option value="CREDIT">KARTU KREDIT</option>
                            <option value="QRIS">QRIS</option>
                        </select>
                    </div>
                    
                    <!-- Payment Status -->
                    <div class="mb-3">
                        <label for="status_bayar" class="form-label">Status Pembayaran</label>
                        <select class="form-select" id="status_bayar" name="status_bayar">
                            <option value="LUNAS">LUNAS</option>
                            <option value="BELUM LUNAS">BELUM LUNAS</option>
                        </select>
                        <div class="form-text">Pilih BELUM LUNAS untuk pembayaran cicilan</div>
                    </div>
                    
                    <!-- Amount Paid -->
                    <div class="mb-3">
                        <label for="bayar" class="form-label">Jumlah Bayar</label>
                        <div class="input-group">
                            <span class="input-group-text">Rp</span>
                            <input type="number" class="form-control" id="bayar" 
                                   name="bayar" min="0" value="0" required>
                        </div>
                    </div>
                    
                    <!-- Change -->
                    <div class="mb-4">
                        <label class="form-label">Kembalian</label>
                        <div class="input-group">
                            <span class="input-group-text">Rp</span>
                            <input type="text" class="form-control fw-bold text-end" 
                                   id="kembalian_display" value="0" readonly>
                        </div>
                        <div id="payment_status" class="small mt-1"></div>
                    </div>
                    
                    <!-- Submit Buttons -->
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-success btn-lg" id="submit_btn" disabled>
                            <i class="fas fa-check-circle me-2"></i>Simpan Transaksi
                        </button>
                        <button type="button" class="btn btn-outline-secondary" id="clear_cart_btn">
                            <i class="fas fa-trash me-2"></i>Kosongkan Keranjang
                        </button>
                        <a href="index.php" class="btn btn-outline-danger">
                            <i class="fas fa-times me-2"></i>Batal
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// Cart array to hold items
let cart = [];

// Format number to Indonesian Rupiah
function formatRupiah(amount) {
    return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0
    }).format(amount);
}

// Update cart display
function updateCart() {
    const cartBody = document.getElementById('cart_body');
    const cartFooter = document.getElementById('cart_footer');
    const cartItemsInput = document.getElementById('cart_items_input');
    const totalInput = document.getElementById('total_input');
    const totalDisplay = document.getElementById('total_display');
    const emptyCartMessage = document.getElementById('empty_cart_message');
    const submitBtn = document.getElementById('submit_btn');
    
    // Clear table body
    cartBody.innerHTML = '';
    
    // Calculate total
    let total = 0;
    
    // Add items to table
    cart.forEach((item, index) => {
        const subtotal = item.harga * item.qty;
        total += subtotal;
        
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${item.nama}</td>
            <td class="text-end">${formatRupiah(item.harga)}</td>
            <td class="text-center">${item.qty}</td>
            <td class="text-end fw-bold">${formatRupiah(subtotal)}</td>
            <td class="text-center">
                <button type="button" class="btn btn-sm btn-danger" onclick="removeFromCart(${index})">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        cartBody.appendChild(row);
    });
    
    // Update totals
    totalInput.value = total;
    totalDisplay.value = formatRupiah(total);
    
    // Update cart items for form submission
    cartItemsInput.value = JSON.stringify(cart.map(item => ({
        id_barang: item.id_barang,
        nama: item.nama,
        harga: item.harga,
        qty: item.qty,
        subtotal: item.harga * item.qty
    })));
    
    // Update cart footer
    if (cart.length > 0) {
        cartFooter.innerHTML = `
            <tr class="table-active">
                <td colspan="3" class="text-end fw-bold">TOTAL:</td>
                <td colspan="2" class="text-end fw-bold fs-5">${formatRupiah(total)}</td>
            </tr>
        `;
        emptyCartMessage.style.display = 'none';
        cart_table.style.display = 'table';
        submitBtn.disabled = false;
    } else {
        cartFooter.innerHTML = '';
        emptyCartMessage.style.display = 'block';
        cart_table.style.display = 'none';
        submitBtn.disabled = true;
    }
    
    // Update payment calculation
    calculatePayment();
}

// Add item to cart
function addToCart() {
    const select = document.getElementById('barang_select');
    const selectedOption = select.options[select.selectedIndex];
    const qtyInput = document.getElementById('qty_input');
    
    // Validate selection
    if (!selectedOption.value) {
        alert('Pilih barang terlebih dahulu!');
        return;
    }
    
    // Get item data
    const id_barang = selectedOption.value;
    const nama = selectedOption.getAttribute('data-nama');
    const harga = parseInt(selectedOption.getAttribute('data-harga'));
    const stok = parseInt(selectedOption.getAttribute('data-stok'));
    const qty = parseInt(qtyInput.value) || 1;
    
    // Validate quantity
    if (qty < 1) {
        alert('Jumlah minimal 1!');
        return;
    }
    
    if (qty > stok) {
        alert(`Stok tidak mencukupi! Stok tersedia: ${stok}`);
        return;
    }
    
    // Check if item already in cart
    const existingIndex = cart.findIndex(item => item.id_barang === id_barang);
    
    if (existingIndex > -1) {
        // Update existing item quantity
        const newQty = cart[existingIndex].qty + qty;
        if (newQty > stok) {
            alert(`Stok tidak mencukupi! Stok tersedia: ${stok}`);
            return;
        }
        cart[existingIndex].qty = newQty;
    } else {
        // Add new item
        cart.push({
            id_barang: id_barang,
            nama: nama,
            harga: harga,
            qty: qty
        });
    }
    
    // Update cart display
    updateCart();
    
    // Reset form
    qtyInput.value = 1;
    select.value = '';
}

// Remove item from cart
function removeFromCart(index) {
    if (confirm('Hapus barang dari keranjang?')) {
        cart.splice(index, 1);
        updateCart();
    }
}

// Clear entire cart
function clearCart() {
    if (cart.length === 0) return;
    
    if (confirm('Kosongkan seluruh keranjang belanja?')) {
        cart = [];
        updateCart();
    }
}

// Calculate payment and change
function calculatePayment() {
    const total = parseFloat(document.getElementById('total_input').value) || 0;
    const bayar = parseFloat(document.getElementById('bayar').value) || 0;
    const statusBayar = document.getElementById('status_bayar').value;
    const kembalianDisplay = document.getElementById('kembalian_display');
    const paymentStatus = document.getElementById('payment_status');
    const submitBtn = document.getElementById('submit_btn');
    
    let kembalian = bayar - total;
    let statusText = '';
    let statusClass = '';
    
    if (statusBayar === 'BELUM LUNAS') {
        kembalianDisplay.value = formatRupiah(0);
        statusText = 'Status: BELUM LUNAS - Pembayaran akan dilakukan kemudian';
        statusClass = 'text-warning';
        submitBtn.disabled = false;
    } else if (kembalian < 0) {
        kembalianDisplay.value = formatRupiah(kembalian);
        statusText = 'Pembayaran kurang!';
        statusClass = 'text-danger';
        submitBtn.disabled = true;
    } else {
        kembalianDisplay.value = formatRupiah(kembalian);
        statusText = kembalian === 0 ? 'Pembayaran pas!' : 'Kembalian: ' + formatRupiah(kembalian);
        statusClass = kembalian === 0 ? 'text-success' : 'text-info';
        submitBtn.disabled = false;
    }
    
    paymentStatus.innerHTML = `<span class="${statusClass}">${statusText}</span>`;
}

// Form validation before submit
function validateForm() {
    const cart = JSON.parse(document.getElementById('cart_items_input').value);
    const bayar = parseFloat(document.getElementById('bayar').value) || 0;
    const statusBayar = document.getElementById('status_bayar').value;
    const total = parseFloat(document.getElementById('total_input').value) || 0;
    
    if (cart.length === 0) {
        alert('Keranjang belanja kosong!');
        return false;
    }
    
    if (statusBayar === 'LUNAS' && bayar < total) {
        alert('Jumlah bayar kurang dari total!');
        return false;
    }
    
    return confirm('Simpan transaksi ini?');
}

// Event Listeners
document.addEventListener('DOMContentLoaded', function() {
    // Add to cart button
    document.getElementById('add_to_cart').addEventListener('click', addToCart);
    
    // Clear cart button
    document.getElementById('clear_cart_btn').addEventListener('click', clearCart);
    
    // Payment calculation triggers
    document.getElementById('bayar').addEventListener('input', calculatePayment);
    document.getElementById('status_bayar').addEventListener('change', calculatePayment);
    
    // Form submission validation
    document.getElementById('payment_form').addEventListener('submit', function(e) {
        if (!validateForm()) {
            e.preventDefault();
        }
    });
    
    // Quick quantity buttons
    document.getElementById('qty_input').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            addToCart();
        }
    });
    
    // Auto-select on product selection
    document.getElementById('barang_select').addEventListener('change', function() {
        const selectedOption = this.options[this.selectedIndex];
        const stok = selectedOption.getAttribute('data-stok');
        const qtyInput = document.getElementById('qty_input');
        
        if (stok) {
            qtyInput.max = stok;
            qtyInput.value = 1;
        }
    });
    
    // Initialize
    updateCart();
});

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl+Enter to submit form
    if (e.ctrlKey && e.key === 'Enter') {
        if (!document.getElementById('submit_btn').disabled) {
            document.getElementById('submit_btn').click();
        }
    }
    
    // F2 to focus on product select
    if (e.key === 'F2') {
        e.preventDefault();
        document.getElementById('barang_select').focus();
    }
});
</script>

<?php
$content = ob_get_clean();

// Include layout
include '../views/default/header.php';

?>