<?php
require_once '../lib/auth.php';
require_once '../lib/functions.php';

$auth = new Auth();
$auth->checkAuth();

$db = Database::getInstance()->getConnection();

$id = $_GET['id'] ?? 0;

// Get penjualan data
$penjualanStmt = $db->prepare("SELECT * FROM penjualan WHERE id_penjualan = ?");
$penjualanStmt->bind_param("i", $id);
$penjualanStmt->execute();
$penjualan = $penjualanStmt->get_result()->fetch_assoc();

if (!$penjualan) {
    flash('flash_message', 'Transaksi tidak ditemukan!', 'alert alert-danger');
    redirect('index.php');
}

// Get penjualan details
$detailSql = "SELECT pd.*, b.nama_barang 
              FROM penjualan_detail pd 
              JOIN barang b ON pd.id_barang = b.id_barang 
              WHERE pd.id_penjualan = ?";
$detailStmt = $db->prepare($detailSql);
$detailStmt->bind_param("i", $id);
$detailStmt->execute();
$details = $detailStmt->get_result()->fetch_all(MYSQLI_ASSOC);

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $metode_pembayaran = $_POST['metode_pembayaran'] ?? 'CASH';
    $bayar = $_POST['bayar'] ?? 0;
    $status_bayar = $_POST['status_bayar'] ?? 'LUNAS';
    
    // Calculate total from existing details
    $total = $penjualan['total'];
    $kembalian = $bayar - $total;
    
    if ($status_bayar == 'LUNAS' && $kembalian < 0) {
        $error = 'Pembayaran kurang dari total!';
    } else {
        $updateSql = "UPDATE penjualan SET 
                      metode_pembayaran = ?, 
                      bayar = ?, 
                      kembalian = ?,
                      status_bayar = ?
                      WHERE id_penjualan = ?";
        $updateStmt = $db->prepare($updateSql);
        $updateStmt->bind_param("siisi", $metode_pembayaran, $bayar, $kembalian, $status_bayar, $id);
        
        if ($updateStmt->execute()) {
            flash('flash_message', 'Transaksi berhasil diperbarui!', 'alert alert-success');
            redirect('index.php');
        } else {
            $error = 'Gagal memperbarui transaksi!';
        }
    }
}

$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => '../admin/index.php', 'active' => false],
    ['name' => 'Penjualan', 'url' => 'index.php', 'active' => false],
    ['name' => 'Edit Transaksi', 'url' => 'edit.php', 'active' => true]
];

$pageTitle = 'Edit Transaksi #' . $id;

ob_start();
?>

<div class="row">
    <div class="col-md-8">
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Detail Barang</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-secondary">
                            <tr>
                                <th>#</th>
                                <th>Nama Barang</th>
                                <th>Harga</th>
                                <th>Qty</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($details as $index => $detail): ?>
                            <tr>
                                <td><?php echo $index + 1; ?></td>
                                <td><?php echo htmlspecialchars($detail['nama_barang']); ?></td>
                                <td><?php echo formatRupiah($detail['harga']); ?></td>
                                <td><?php echo $detail['qty']; ?></td>
                                <td><?php echo formatRupiah($detail['subtotal']); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot class="table-active">
                            <tr>
                                <td colspan="4" class="text-end"><strong>Total:</strong></td>
                                <td><strong><?php echo formatRupiah($penjualan['total']); ?></strong></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card">
            <div class="card-header bg-warning text-white">
                <h5 class="mb-0">Edit Pembayaran</h5>
            </div>
            <div class="card-body">
                <?php if($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <form method="POST" action="">
                    <div class="mb-3">
                        <label class="form-label">Total Transaksi</label>
                        <input type="text" class="form-control" 
                               value="<?php echo formatRupiah($penjualan['total']); ?>" readonly>
                    </div>
                    
                    <div class="mb-3">
                        <label for="metode_pembayaran" class="form-label">Metode Pembayaran</label>
                        <select class="form-select" id="metode_pembayaran" name="metode_pembayaran">
                            <option value="CASH" <?php echo $penjualan['metode_pembayaran'] == 'CASH' ? 'selected' : ''; ?>>CASH</option>
                            <option value="TRANSFER" <?php echo $penjualan['metode_pembayaran'] == 'TRANSFER' ? 'selected' : ''; ?>>TRANSFER</option>
                            <option value="QRIS" <?php echo $penjualan['metode_pembayaran'] == 'QRIS' ? 'selected' : ''; ?>>QRIS</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="status_bayar" class="form-label">Status Bayar</label>
                        <select class="form-select" id="status_bayar" name="status_bayar">
                            <option value="LUNAS" <?php echo $penjualan['status_bayar'] == 'LUNAS' ? 'selected' : ''; ?>>LUNAS</option>
                            <option value="BELUM LUNAS" <?php echo $penjualan['status_bayar'] == 'BELUM LUNAS' ? 'selected' : ''; ?>>BELUM LUNAS</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="bayar" class="form-label">Bayar</label>
                        <input type="number" class="form-control" id="bayar" name="bayar" 
                               value="<?php echo $penjualan['bayar']; ?>" min="0" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="kembalian" class="form-label">Kembalian</label>
                        <input type="text" class="form-control" id="kembalian" 
                               value="<?php echo formatRupiah($penjualan['kembalian']); ?>" readonly>
                    </div>
                    
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <a href="index.php" class="btn btn-secondary me-md-2">
                            <i class="fas fa-arrow-left"></i> Kembali
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Simpan Perubahan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function calculateKembalian() {
    const total = <?php echo $penjualan['total']; ?>;
    const bayar = parseFloat(document.getElementById('bayar').value) || 0;
    const statusBayar = document.getElementById('status_bayar').value;
    
    let kembalian = bayar - total;
    const kembalianInput = document.getElementById('kembalian');
    
    if (statusBayar === 'BELUM LUNAS') {
        kembalianInput.value = 'Rp 0';
    } else {
        if (kembalian < 0) {
            kembalianInput.value = 'Kurang: Rp ' + Math.abs(kembalian).toLocaleString('id-ID');
            kembalianInput.classList.add('text-danger');
        } else {
            kembalianInput.value = 'Rp ' + kembalian.toLocaleString('id-ID');
            kembalianInput.classList.remove('text-danger');
        }
    }
}

document.getElementById('bayar').addEventListener('input', calculateKembalian);
document.getElementById('status_bayar').addEventListener('change', calculateKembalian);

// Initialize calculation
calculateKembalian();
</script>

<?php
$content = ob_get_clean();

include '../views/default/header.php';
?>