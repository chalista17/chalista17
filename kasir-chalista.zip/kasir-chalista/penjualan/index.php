<?php
require_once '../lib/auth.php';
require_once '../lib/functions.php';

$auth = new Auth();
$auth->checkAuth();

$db = Database::getInstance()->getConnection();

// Handle search and filter
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-d');
$status = $_GET['status'] ?? '';
$search = $_GET['search'] ?? '';

// Build WHERE clause
$where = " WHERE tanggal BETWEEN ? AND ?";
$params = [$start_date . ' 00:00:00', $end_date . ' 23:59:59'];
$types = "ss";

if (!empty($status)) {
    $where .= " AND status_bayar = ?";
    $params[] = $status;
    $types .= "s";
}

if (!empty($search)) {
    $where .= " AND (id_penjualan = ? OR metode_pembayaran LIKE ?)";
    $params[] = is_numeric($search) ? $search : 0;
    $params[] = "%$search%";
    $types .= "is";
}

// Get total records
$countSql = "SELECT COUNT(*) as total FROM penjualan $where";
$countStmt = $db->prepare($countSql);
$countStmt->bind_param($types, ...$params);
$countStmt->execute();
$totalResult = $countStmt->get_result();
$totalRecords = $totalResult->fetch_assoc()['total'];

// Pagination
$limit = 10;
$page = $_GET['page'] ?? 1;
$offset = ($page - 1) * $limit;
$totalPages = ceil($totalRecords / $limit);

// Get penjualan data
$sql = "SELECT * FROM penjualan $where ORDER BY tanggal DESC LIMIT ? OFFSET ?";
$params[] = $limit;
$params[] = $offset;
$types .= "ii";

$stmt = $db->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();
$penjualan = $result->fetch_all(MYSQLI_ASSOC);

// Calculate totals
$sumSql = "SELECT 
            SUM(total) as total_penjualan,
            COUNT(*) as total_transaksi,
            SUM(CASE WHEN status_bayar = 'LUNAS' THEN total ELSE 0 END) as total_lunas,
            SUM(CASE WHEN status_bayar = 'BELUM LUNAS' THEN total ELSE 0 END) as total_belum_lunas
          FROM penjualan $where";
$sumStmt = $db->prepare($sumSql);
$sumStmt->bind_param(substr($types, 0, -2), ...array_slice($params, 0, count($params)-2));
$sumStmt->execute();
$totals = $sumStmt->get_result()->fetch_assoc();

// Get today's sales for comparison
$todaySql = "SELECT SUM(total) as today_sales FROM penjualan WHERE DATE(tanggal) = CURDATE()";
$todayResult = $db->query($todaySql);
$todaySales = $todayResult->fetch_assoc()['today_sales'] ?? 0;

// Get average transaction value
$avgSql = "SELECT AVG(total) as avg_transaction FROM penjualan WHERE DATE(tanggal) = CURDATE()";
$avgResult = $db->query($avgSql);
$avgTransaction = $avgResult->fetch_assoc()['avg_transaction'] ?? 0;

$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => '../admin/index.php', 'icon' => 'fas fa-home'],
    ['name' => 'Penjualan', 'url' => 'index.php', 'active' => true]
];

$pageTitle = 'Manajemen Penjualan';

$actionButtons = [
    [
        'url' => 'add.php',
        'class' => 'btn btn-success',
        'icon' => 'fas fa-plus',
        'text' => 'Transaksi Baru'
    ]
];

ob_start();
?>

<!-- Statistic Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-lg-6 mb-4">
        <div class="card stat-card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <h6 class="card-subtitle mb-2 text-muted">Total Penjualan</h6>
                        <h2 class="card-title mb-0 text-primary"><?php echo formatRupiah($totals['total_penjualan'] ?? 0); ?></h2>
                        <small class="text-muted">periode terpilih</small>
                    </div>
                    <div class="bg-primary bg-opacity-10 rounded-circle p-3">
                        <i class="fas fa-money-bill-wave fa-2x text-primary"></i>
                    </div>
                </div>
                <div class="mt-3">
                    <small class="text-muted">
                        <?php echo $start_date; ?> - <?php echo $end_date; ?>
                    </small>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-lg-6 mb-4">
        <div class="card stat-card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <h6 class="card-subtitle mb-2 text-muted">Total Transaksi</h6>
                        <h2 class="card-title mb-0 text-success"><?php echo $totals['total_transaksi'] ?? 0; ?></h2>
                        <small class="text-muted">transaksi ditemukan</small>
                    </div>
                    <div class="bg-success bg-opacity-10 rounded-circle p-3">
                        <i class="fas fa-shopping-cart fa-2x text-success"></i>
                    </div>
                </div>
                <div class="mt-3">
                    <div class="progress" style="height: 6px;">
                        <div class="progress-bar bg-success" role="progressbar" 
                             style="width: <?php echo min(100, ($totalRecords/50)*100); ?>%"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-lg-6 mb-4">
        <div class="card stat-card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <h6 class="card-subtitle mb-2 text-muted">Sudah Lunas</h6>
                        <h2 class="card-title mb-0 text-info"><?php echo formatRupiah($totals['total_lunas'] ?? 0); ?></h2>
                        <small class="text-muted">transaksi lunas</small>
                    </div>
                    <div class="bg-info bg-opacity-10 rounded-circle p-3">
                        <i class="fas fa-check-circle fa-2x text-info"></i>
                    </div>
                </div>
                <div class="mt-3">
                    <div class="d-flex justify-content-between small">
                        <span class="text-muted">Hari ini:</span>
                        <span class="fw-bold"><?php echo formatRupiah($todaySales); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-lg-6 mb-4">
        <div class="card stat-card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <h6 class="card-subtitle mb-2 text-muted">Belum Lunas</h6>
                        <h2 class="card-title mb-0 text-warning"><?php echo formatRupiah($totals['total_belum_lunas'] ?? 0); ?></h2>
                        <small class="text-muted">perlu ditagih</small>
                    </div>
                    <div class="bg-warning bg-opacity-10 rounded-circle p-3">
                        <i class="fas fa-clock fa-2x text-warning"></i>
                    </div>
                </div>
                <div class="mt-3">
                    <a href="?status=BELUM+LUNAS" class="btn btn-outline-warning btn-sm w-100">
                        <i class="fas fa-eye me-1"></i>Lihat Semua
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Filter Card -->
<div class="card border-0 shadow-sm mb-4">
    <div class="card-header bg-white border-0 py-3">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h5 class="mb-1"><i class="fas fa-filter text-primary me-2"></i>Filter Penjualan</h5>
                <p class="text-muted mb-0 small">Saring data penjualan sesuai kebutuhan</p>
            </div>
            <div class="dropdown">
                <button class="btn btn-outline-secondary btn-sm dropdown-toggle" type="button" 
                        data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fas fa-calendar-alt me-1"></i>Preset Periode
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="?start_date=<?php echo date('Y-m-01'); ?>&end_date=<?php echo date('Y-m-d'); ?>">Bulan Ini</a></li>
                    <li><a class="dropdown-item" href="?start_date=<?php echo date('Y-m-d'); ?>&end_date=<?php echo date('Y-m-d'); ?>">Hari Ini</a></li>
                    <li><a class="dropdown-item" href="?start_date=<?php echo date('Y-m-d', strtotime('-7 days')); ?>&end_date=<?php echo date('Y-m-d'); ?>">7 Hari Terakhir</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="index.php">Reset Semua</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="card-body">
        <form method="GET" action="" class="row g-3 align-items-end">
            <div class="col-md-3">
                <label for="start_date" class="form-label small">Tanggal Mulai</label>
                <input type="date" class="form-control" id="start_date" name="start_date" 
                       value="<?php echo $start_date; ?>">
            </div>
            <div class="col-md-3">
                <label for="end_date" class="form-label small">Tanggal Akhir</label>
                <input type="date" class="form-control" id="end_date" name="end_date" 
                       value="<?php echo $end_date; ?>">
            </div>
            <div class="col-md-2">
                <label for="status" class="form-label small">Status Bayar</label>
                <select class="form-select" id="status" name="status">
                    <option value="">Semua Status</option>
                    <option value="LUNAS" <?php echo $status == 'LUNAS' ? 'selected' : ''; ?>>LUNAS</option>
                    <option value="BELUM LUNAS" <?php echo $status == 'BELUM LUNAS' ? 'selected' : ''; ?>>BELUM LUNAS</option>
                </select>
            </div>
            <div class="col-md-2">
                <label for="search" class="form-label small">Cari ID/Metode</label>
                <input type="text" class="form-control" id="search" name="search" 
                       value="<?php echo htmlspecialchars($search); ?>" 
                       placeholder="No. Transaksi / Metode">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="fas fa-search me-2"></i>Terapkan
                </button>
            </div>
        </form>
        
        <!-- Quick Actions -->
        <div class="row mt-4">
            <div class="col-md-8">
                <div class="d-flex flex-wrap gap-2">
                    <a href="add.php" class="btn btn-success">
                        <i class="fas fa-plus me-2"></i>Transaksi Baru
                    </a>
                    <a href="?status=BELUM+LUNAS" class="btn btn-outline-warning">
                        <i class="fas fa-clock me-2"></i>Belum Lunas
                    </a>
                    <a href="?start_date=<?php echo date('Y-m-d'); ?>&end_date=<?php echo date('Y-m-d'); ?>" 
                       class="btn btn-outline-info">
                        <i class="fas fa-calendar-day me-2"></i>Hari Ini
                    </a>
                    <?php if(!empty($search) || !empty($status) || $start_date != date('Y-m-01') || $end_date != date('Y-m-d')): ?>
                    <a href="index.php" class="btn btn-outline-secondary">
                        <i class="fas fa-redo me-2"></i>Reset Filter
                    </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-4 text-end">
                <div class="d-flex justify-content-end align-items-center h-100">
                    <span class="badge bg-primary me-2">
                        <?php echo $totalRecords; ?> transaksi
                    </span>
                    <small class="text-muted">
                        Halaman <?php echo $page; ?> dari <?php echo $totalPages; ?>
                    </small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Penjualan Table Card -->
<div class="card border-0 shadow-sm">
    <div class="card-header bg-white border-0 py-3">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h5 class="mb-1"><i class="fas fa-shopping-cart text-primary me-2"></i>Daftar Penjualan</h5>
                <p class="text-muted mb-0 small">Riwayat transaksi penjualan</p>
            </div>
            <div class="d-flex align-items-center">
                <span class="badge bg-primary me-3">
                    <?php echo $totalRecords; ?> transaksi
                </span>
                <div class="dropdown">
                    <button class="btn btn-outline-secondary btn-sm" type="button" 
                            data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-cog"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><h6 class="dropdown-header">Aksi</h6></li>
                        <li><a class="dropdown-item" href="add.php"><i class="fas fa-plus me-2"></i>Tambah Transaksi</a></li>
                        <li><a class="dropdown-item" href="#"><i class="fas fa-print me-2"></i>Cetak Laporan</a></li>
                        <li><a class="dropdown-item" href="#"><i class="fas fa-download me-2"></i>Export Excel</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="index.php"><i class="fas fa-refresh me-2"></i>Refresh</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th width="80" class="text-center">#</th>
                        <th width="120" class="text-center">Tanggal</th>
                        <th width="150" class="text-center">ID Transaksi</th>
                        <th width="150" class="text-end">Total</th>
                        <th width="150" class="text-end">Bayar</th>
                        <th width="150" class="text-end">Kembalian</th>
                        <th width="120" class="text-center">Metode</th>
                        <th width="120" class="text-center">Status</th>
                        <th width="200" class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($penjualan)): ?>
                    <tr>
                        <td colspan="9" class="text-center py-5">
                            <div class="py-4">
                                <i class="fas fa-shopping-cart fa-4x text-muted mb-4"></i>
                                <h5 class="text-muted">Tidak Ada Data Penjualan</h5>
                                <p class="text-muted small mb-4">Tidak ditemukan transaksi dengan filter yang diterapkan</p>
                                <a href="add.php" class="btn btn-primary me-2">
                                    <i class="fas fa-plus me-2"></i>Buat Transaksi Pertama
                                </a>
                                <a href="index.php" class="btn btn-outline-secondary">
                                    <i class="fas fa-redo me-2"></i>Tampilkan Semua
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php else: ?>
                    <?php foreach($penjualan as $index => $item): ?>
                    <tr>
                        <td class="text-center align-middle">
                            <span class="badge bg-light text-dark"><?php echo $offset + $index + 1; ?></span>
                        </td>
                        <td class="text-center align-middle">
                            <small class="d-block"><?php echo date('d/m/Y', strtotime($item['tanggal'])); ?></small>
                            <small class="text-muted"><?php echo date('H:i', strtotime($item['tanggal'])); ?></small>
                        </td>
                        <td class="text-center align-middle">
                            <strong class="text-primary">#<?php echo $item['id_penjualan']; ?></strong>
                        </td>
                        <td class="text-end align-middle">
                            <div class="fw-bold"><?php echo formatRupiah($item['total']); ?></div>
                        </td>
                        <td class="text-end align-middle">
                            <div class="text-success"><?php echo formatRupiah($item['bayar']); ?></div>
                        </td>
                        <td class="text-end align-middle">
                            <div class="text-info"><?php echo formatRupiah($item['kembalian']); ?></div>
                        </td>
                        <td class="text-center align-middle">
                            <?php echo getPaymentBadge($item['metode_pembayaran']); ?>
                        </td>
                        <td class="text-center align-middle">
                            <?php echo getStatusBadge($item['status_bayar']); ?>
                        </td>
                        <td class="text-center align-middle">
                            <div class="btn-group btn-group-sm" role="group">
                                <a href="../penjualan_detail/index.php?penjualan_id=<?php echo $item['id_penjualan']; ?>" 
                                   class="btn btn-outline-info" 
                                   data-bs-toggle="tooltip" title="Detail Transaksi">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="edit.php?id=<?php echo $item['id_penjualan']; ?>" 
                                   class="btn btn-outline-warning"
                                   data-bs-toggle="tooltip" title="Edit Transaksi">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="delete.php?id=<?php echo $item['id_penjualan']; ?>" 
                                   class="btn btn-outline-danger"
                                   onclick="return confirm('Yakin ingin menghapus transaksi ini?')"
                                   data-bs-toggle="tooltip" title="Hapus Transaksi">
                                    <i class="fas fa-trash"></i>
                                </a>
                                <button type="button" class="btn btn-outline-primary"
                                        data-bs-toggle="tooltip" title="Cetak Struk">
                                    <i class="fas fa-print"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Pagination -->
        <?php if($totalPages > 1): ?>
        <nav aria-label="Page navigation" class="mt-4">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted">
                        Menampilkan <strong><?php echo min($limit, count($penjualan)); ?></strong> dari 
                        <strong><?php echo $totalRecords; ?></strong> transaksi
                    </small>
                </div>
                <ul class="pagination mb-0">
                    <?php if($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?php echo $page-1; ?>&start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>&status=<?php echo $status; ?>&search=<?php echo urlencode($search); ?>">
                            <i class="fas fa-chevron-left me-1"></i>Sebelumnya
                        </a>
                    </li>
                    <?php else: ?>
                    <li class="page-item disabled">
                        <span class="page-link">
                            <i class="fas fa-chevron-left me-1"></i>Sebelumnya
                        </span>
                    </li>
                    <?php endif; ?>
                    
                    <?php 
                    $startPage = max(1, $page - 2);
                    $endPage = min($totalPages, $page + 2);
                    
                    for($i = $startPage; $i <= $endPage; $i++): 
                    ?>
                    <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $i; ?>&start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>&status=<?php echo $status; ?>&search=<?php echo urlencode($search); ?>">
                            <?php echo $i; ?>
                        </a>
                    </li>
                    <?php endfor; ?>
                    
                    <?php if($page < $totalPages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?php echo $page+1; ?>&start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>&status=<?php echo $status; ?>&search=<?php echo urlencode($search); ?>">
                            Selanjutnya<i class="fas fa-chevron-right ms-1"></i>
                        </a>
                    </li>
                    <?php else: ?>
                    <li class="page-item disabled">
                        <span class="page-link">
                            Selanjutnya<i class="fas fa-chevron-right ms-1"></i>
                        </span>
                    </li>
                    <?php endif; ?>
                </ul>
                <div>
                    <small class="text-muted">
                        Halaman <strong><?php echo $page; ?></strong> dari <strong><?php echo $totalPages; ?></strong>
                    </small>
                </div>
            </div>
        </nav>
        <?php endif; ?>
    </div>
</div>

<!-- Quick Stats -->
<div class="row mt-4">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="bg-primary bg-opacity-10 rounded-circle p-3 me-3">
                        <i class="fas fa-chart-pie text-primary fa-2x"></i>
                    </div>
                    <div>
                        <h6 class="mb-1">Statistik Cepat</h6>
                        <p class="text-muted mb-0 small">Ringkasan performa penjualan</p>
                    </div>
                </div>
                <div class="mt-3">
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Rata Transaksi:</span>
                        <span class="fw-bold"><?php echo formatRupiah($avgTransaction); ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Transaksi Hari Ini:</span>
                        <span class="fw-bold text-success"><?php 
                            $todayCountSql = "SELECT COUNT(*) as count FROM penjualan WHERE DATE(tanggal) = CURDATE()";
                            $todayCountResult = $db->query($todayCountSql);
                            echo $todayCountResult->fetch_assoc()['count'] ?? 0;
                        ?></span>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span class="text-muted">Nilai Tertinggi:</span>
                        <span class="fw-bold"><?php 
                            $maxSql = "SELECT MAX(total) as max FROM penjualan $where";
                            $maxStmt = $db->prepare($maxSql);
                            $maxStmt->bind_param(substr($types, 0, -2), ...array_slice($params, 0, count($params)-2));
                            $maxStmt->execute();
                            $maxResult = $maxStmt->get_result()->fetch_assoc();
                            echo formatRupiah($maxResult['max'] ?? 0);
                        ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <h6 class="mb-3"><i class="fas fa-lightbulb text-warning me-2"></i>Tips Manajemen Penjualan</h6>
                <div class="row">
                    <div class="col-md-6">
                        <div class="d-flex mb-3">
                            <div class="flex-shrink-0">
                                <i class="fas fa-check-circle text-success"></i>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <small class="fw-bold">Monitor Pembayaran</small>
                                <p class="text-muted small mb-0">Pantau transaksi belum lunas secara berkala</p>
                            </div>
                        </div>
                        <div class="d-flex">
                            <div class="flex-shrink-0">
                                <i class="fas fa-check-circle text-success"></i>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <small class="fw-bold">Analisis Periode</small>
                                <p class="text-muted small mb-0">Bandingkan performa antar periode waktu</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="d-flex mb-3">
                            <div class="flex-shrink-0">
                                <i class="fas fa-check-circle text-success"></i>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <small class="fw-bold">Metode Pembayaran</small>
                                <p class="text-muted small mb-0">Analisis preferensi pembayaran pelanggan</p>
                            </div>
                        </div>
                        <div class="d-flex">
                            <div class="flex-shrink-0">
                                <i class="fas fa-check-circle text-success"></i>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <small class="fw-bold">Backup Data</small>
                                <p class="text-muted small mb-0">Ekspor data penjualan secara berkala</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Initialize tooltips
document.addEventListener('DOMContentLoaded', function() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});
</script>

<?php
$content = ob_get_clean();
include '../views/default/header.php';
?>