<?php
require_once '../lib/auth.php';
require_once '../lib/functions.php';

$auth = new Auth();
$auth->checkAuth();

$db = Database::getInstance()->getConnection();

$penjualan_id = $_GET['penjualan_id'] ?? 0;

// Check if penjualan exists
$checkStmt = $db->prepare("SELECT * FROM penjualan WHERE id_penjualan = ?");
$checkStmt->bind_param("i", $penjualan_id);
$checkStmt->execute();
$penjualan = $checkStmt->get_result()->fetch_assoc();

if (!$penjualan) {
    flash('flash_message', 'Transaksi tidak ditemukan!', 'alert alert-danger');
    redirect('../penjualan/index.php');
}

// Get barang list
$barangStmt = $db->prepare("SELECT * FROM barang WHERE stok > 0 ORDER BY nama_barang");
$barangStmt->execute();
$barangList = $barangStmt->get_result()->fetch_all(MYSQLI_ASSOC);

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_barang = $_POST['id_barang'] ?? 0;
    $qty = $_POST['qty'] ?? 0;
    
    if ($id_barang == 0 || $qty <= 0) {
        $error = 'Data tidak valid!';
    } else {
        // Get barang info
        $barangStmt = $db->prepare("SELECT * FROM barang WHERE id_barang = ?");
        $barangStmt->bind_param("i", $id_barang);
        $barangStmt->execute();
        $barang = $barangStmt->get_result()->fetch_assoc();
        
        if (!$barang) {
            $error = 'Barang tidak ditemukan!';
        } elseif ($barang['stok'] < $qty) {
            $error = 'Stok tidak mencukupi! Stok tersedia: ' . $barang['stok'];
        } else {
            // Check if item already in penjualan_detail
            $checkDetailStmt = $db->prepare("SELECT * FROM penjualan_detail WHERE id_penjualan = ? AND id_barang = ?");
            $checkDetailStmt->bind_param("ii", $penjualan_id, $id_barang);
            $checkDetailStmt->execute();
            $existingDetail = $checkDetailStmt->get_result()->fetch_assoc();
            
            $db->begin_transaction();
            
            try {
                if ($existingDetail) {
                    // Update existing detail
                    $newQty = $existingDetail['qty'] + $qty;
                    $subtotal = $newQty * $barang['harga'];
                    
                    $updateStmt = $db->prepare("UPDATE penjualan_detail SET qty = ?, subtotal = ? WHERE id_detail = ?");
                    $updateStmt->bind_param("iii", $newQty, $subtotal, $existingDetail['id_detail']);
                    $updateStmt->execute();
                } else {
                    // Insert new detail
                    $subtotal = $qty * $barang['harga'];
                    
                    $insertStmt = $db->prepare("INSERT INTO penjualan_detail (id_penjualan, id_barang, qty, harga, subtotal) VALUES (?, ?, ?, ?, ?)");
                    $insertStmt->bind_param("iiiii", $penjualan_id, $id_barang, $qty, $barang['harga'], $subtotal);
                    $insertStmt->execute();
                }
                
                // Update stock
                $updateStockStmt = $db->prepare("UPDATE barang SET stok = stok - ? WHERE id_barang = ?");
                $updateStockStmt->bind_param("ii", $qty, $id_barang);
                $updateStockStmt->execute();
                
                // Update total in penjualan
                $updateTotalStmt = $db->prepare("
                    UPDATE penjualan p
                    SET p.total = (
                        SELECT SUM(subtotal) 
                        FROM penjualan_detail 
                        WHERE id_penjualan = p.id_penjualan
                    )
                    WHERE p.id_penjualan = ?
                ");
                $updateTotalStmt->bind_param("i", $penjualan_id);
                $updateTotalStmt->execute();
                
                $db->commit();
                flash('flash_message', 'Barang berhasil ditambahkan ke transaksi!', 'alert alert-success');
                redirect("index.php?penjualan_id=$penjualan_id");
                
            } catch (Exception $e) {
                $db->rollback();
                $error = 'Gagal menambahkan barang: ' . $e->getMessage();
            }
        }
    }
}

$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => '../admin/index.php', 'active' => false],
    ['name' => 'Penjualan', 'url' => '../penjualan/index.php', 'active' => false],
    ['name' => 'Detail Transaksi', 'url' => "index.php?penjualan_id=$penjualan_id", 'active' => false],
    ['name' => 'Tambah Barang', 'url' => 'add.php', 'active' => true]
];

$pageTitle = 'Tambah Barang ke Transaksi #' . $penjualan_id;

ob_start();
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Tambah Barang ke Transaksi</h5>
            </div>
            <div class="card-body">
                <?php if($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <div class="alert alert-info">
                    <strong>Informasi Transaksi:</strong><br>
                    No. Transaksi: #<?php echo $penjualan['id_penjualan']; ?><br>
                    Tanggal: <?php echo date('d/m/Y H:i', strtotime($penjualan['tanggal'])); ?>
                </div>
                
                <form method="POST" action="">
                    <input type="hidden" name="penjualan_id" value="<?php echo $penjualan_id; ?>">
                    
                    <div class="mb-3">
                        <label for="id_barang" class="form-label">Pilih Barang</label>
                        <select class="form-select" id="id_barang" name="id_barang" required>
                            <option value="">-- Pilih Barang --</option>
                            <?php foreach($barangList as $barang): ?>
                            <option value="<?php echo $barang['id_barang']; ?>" 
                                    data-stok="<?php echo $barang['stok']; ?>"
                                    data-harga="<?php echo $barang['harga']; ?>">
                                <?php echo htmlspecialchars($barang['nama_barang']); ?> 
                                - <?php echo formatRupiah($barang['harga']); ?> 
                                (Stok: <?php echo $barang['stok']; ?>)
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="qty" class="form-label">Quantity</label>
                        <input type="number" class="form-control" id="qty" name="qty" min="1" value="1" required>
                        <small class="text-muted">Stok tersedia: <span id="stok-info">0</span></small>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Harga Satuan</label>
                        <input type="text" class="form-control" id="harga-display" readonly>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Subtotal</label>
                        <input type="text" class="form-control" id="subtotal-display" readonly>
                    </div>
                    
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <a href="index.php?penjualan_id=<?php echo $penjualan_id; ?>" class="btn btn-secondary me-md-2">
                            <i class="fas fa-arrow-left"></i> Kembali
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Tambah Barang
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function updateInfo() {
    const select = document.getElementById('id_barang');
    const selectedOption = select.options[select.selectedIndex];
    const qtyInput = document.getElementById('qty');
    const stokInfo = document.getElementById('stok-info');
    const hargaDisplay = document.getElementById('harga-display');
    const subtotalDisplay = document.getElementById('subtotal-display');
    
    if (selectedOption.value) {
        const stok = selectedOption.getAttribute('data-stok');
        const harga = selectedOption.getAttribute('data-harga');
        
        stokInfo.textContent = stok;
        hargaDisplay.value = 'Rp ' + parseInt(harga).toLocaleString('id-ID');
        
        // Update qty max
        qtyInput.max = stok;
        
        // Calculate subtotal
        const qty = parseInt(qtyInput.value) || 1;
        const subtotal = qty * parseInt(harga);
        subtotalDisplay.value = 'Rp ' + subtotal.toLocaleString('id-ID');
    } else {
        stokInfo.textContent = '0';
        hargaDisplay.value = '';
        subtotalDisplay.value = '';
        qtyInput.max = '';
    }
}

function calculateSubtotal() {
    const select = document.getElementById('id_barang');
    const selectedOption = select.options[select.selectedIndex];
    const qtyInput = document.getElementById('qty');
    const subtotalDisplay = document.getElementById('subtotal-display');
    
    if (selectedOption.value) {
        const harga = selectedOption.getAttribute('data-harga');
        const qty = parseInt(qtyInput.value) || 1;
        const subtotal = qty * parseInt(harga);
        subtotalDisplay.value = 'Rp ' + subtotal.toLocaleString('id-ID');
    }
}

// Event listeners
document.getElementById('id_barang').addEventListener('change', updateInfo);
document.getElementById('qty').addEventListener('input', calculateSubtotal);

// Initialize
updateInfo();
</script>

<?php
$content = ob_get_clean();

include '../views/default/header.php';
?>