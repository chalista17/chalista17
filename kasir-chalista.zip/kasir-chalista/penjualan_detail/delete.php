<?php
require_once '../lib/auth.php';
require_once '../lib/functions.php';

$auth = new Auth();
$auth->checkAuth();

$db = Database::getInstance()->getConnection();

$id_detail = $_GET['id'] ?? 0;

// Get detail data
$detailSql = "SELECT pd.* FROM penjualan_detail pd WHERE pd.id_detail = ?";
$detailStmt = $db->prepare($detailSql);
$detailStmt->bind_param("i", $id_detail);
$detailStmt->execute();
$detail = $detailStmt->get_result()->fetch_assoc();

if (!$detail) {
    flash('flash_message', 'Detail tidak ditemukan!', 'alert alert-danger');
    redirect('../penjualan/index.php');
}

$penjualan_id = $detail['id_penjualan'];

$db->begin_transaction();

try {
    // Restore stock
    $restoreStockStmt = $db->prepare("UPDATE barang SET stok = stok + ? WHERE id_barang = ?");
    $restoreStockStmt->bind_param("ii", $detail['qty'], $detail['id_barang']);
    $restoreStockStmt->execute();
    
    // Delete detail
    $deleteStmt = $db->prepare("DELETE FROM penjualan_detail WHERE id_detail = ?");
    $deleteStmt->bind_param("i", $id_detail);
    $deleteStmt->execute();
    
    // Update total in penjualan
    $updateTotalStmt = $db->prepare("
        UPDATE penjualan p
        SET p.total = (
            SELECT COALESCE(SUM(subtotal), 0)
            FROM penjualan_detail 
            WHERE id_penjualan = p.id_penjualan
        )
        WHERE p.id_penjualan = ?
    ");
    $updateTotalStmt->bind_param("i", $penjualan_id);
    $updateTotalStmt->execute();
    
    // Check if no more details
    $checkDetailsStmt = $db->prepare("SELECT COUNT(*) as count FROM penjualan_detail WHERE id_penjualan = ?");
    $checkDetailsStmt->bind_param("i", $penjualan_id);
    $checkDetailsStmt->execute();
    $countResult = $checkDetailsStmt->get_result()->fetch_assoc();
    
    if ($countResult['count'] == 0) {
        // Delete penjualan if no details left
        $deletePenjualanStmt = $db->prepare("DELETE FROM penjualan WHERE id_penjualan = ?");
        $deletePenjualanStmt->bind_param("i", $penjualan_id);
        $deletePenjualanStmt->execute();
        
        $db->commit();
        flash('flash_message', 'Detail dan transaksi berhasil dihapus!', 'alert alert-success');
        redirect('../penjualan/index.php');
    } else {
        $db->commit();
        flash('flash_message', 'Detail berhasil dihapus!', 'alert alert-success');
        redirect("index.php?penjualan_id=$penjualan_id");
    }
    
} catch (Exception $e) {
    $db->rollback();
    flash('flash_message', 'Gagal menghapus detail: ' . $e->getMessage(), 'alert alert-danger');
    redirect("index.php?penjualan_id=$penjualan_id");
}
?>