<?php
require_once '../lib/auth.php';
require_once '../lib/functions.php';

$auth = new Auth();
$auth->checkAuth();

$db = Database::getInstance()->getConnection();

$penjualan_id = $_GET['penjualan_id'] ?? 0;

// Validasi penjualan_id
if (!is_numeric($penjualan_id) || $penjualan_id <= 0) {
    $_SESSION['flash_message'] = [
        'message' => 'ID Transaksi tidak valid!',
        'type' => 'danger'
    ];
    header('Location: ../penjualan/index.php');
    exit();
}

// Get penjualan info
$penjualanStmt = $db->prepare("SELECT * FROM penjualan WHERE id_penjualan = ?");
if (!$penjualanStmt) {
    die("Error preparing statement: " . $db->error);
}

$penjualanStmt->bind_param("i", $penjualan_id);
$penjualanStmt->execute();
$penjualan = $penjualanStmt->get_result()->fetch_assoc();

if (!$penjualan) {
    $_SESSION['flash_message'] = [
        'message' => 'Transaksi tidak ditemukan!',
        'type' => 'danger'
    ];
    header('Location: ../penjualan/index.php');
    exit();
}

// Get penjualan details - DIPERBAIKI: Hapus kode_barang dari query
$detailSql = "SELECT pd.*, b.nama_barang 
              FROM penjualan_detail pd 
              JOIN barang b ON pd.id_barang = b.id_barang 
              WHERE pd.id_penjualan = ? 
              ORDER BY pd.id_detail";

$detailStmt = $db->prepare($detailSql);
if (!$detailStmt) {
    die("Error preparing detail statement: " . $db->error . "<br>SQL: " . $detailSql);
}

$detailStmt->bind_param("i", $penjualan_id);
$detailStmt->execute();
$details = $detailStmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Calculate summary
$total_items = 0;
foreach ($details as $detail) {
    $total_items += $detail['qty'];
}

$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => '../admin/index.php', 'icon' => 'fas fa-home'],
    ['name' => 'Penjualan', 'url' => '../penjualan/index.php', 'icon' => 'fas fa-shopping-cart'],
    ['name' => 'Detail Transaksi #' . $penjualan_id, 'url' => 'index.php?penjualan_id=' . $penjualan_id, 'active' => true]
];

$pageTitle = 'Detail Transaksi #' . $penjualan_id;

$actionButtons = [
    [
        'url' => '../penjualan/index.php',
        'class' => 'btn btn-outline-secondary',
        'icon' => 'fas fa-arrow-left',
        'text' => 'Kembali'
    ],
    [
        'url' => 'add.php?penjualan_id=' . $penjualan_id,
        'class' => 'btn btn-success',
        'icon' => 'fas fa-plus',
        'text' => 'Tambah Barang'
    ]
];

ob_start();
?>

<!-- Transaction Information Card -->
<div class="row mb-4">
    <div class="col-md-8">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white border-0 py-3">
                <h5 class="mb-1"><i class="fas fa-info-circle text-primary me-2"></i>Informasi Transaksi</h5>
                <p class="text-muted mb-0 small">Detail lengkap transaksi penjualan</p>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <table class="table table-borderless table-sm">
                            <tbody>
                                <tr>
                                    <td width="150" class="text-muted small">No. Transaksi</td>
                                    <td class="fw-bold text-primary">#<?php echo $penjualan['id_penjualan']; ?></td>
                                </tr>
                                <tr>
                                    <td class="text-muted small">Tanggal & Waktu</td>
                                    <td class="fw-bold">
                                        <?php echo date('d/m/Y', strtotime($penjualan['tanggal'])); ?>
                                        <small class="text-muted ms-2">
                                            <?php echo date('H:i:s', strtotime($penjualan['tanggal'])); ?>
                                        </small>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-muted small">Metode Pembayaran</td>
                                    <td>
                                        <?php echo getPaymentBadge($penjualan['metode_pembayaran']); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-muted small">Status Pembayaran</td>
                                    <td>
                                        <?php echo getStatusBadge($penjualan['status_bayar']); ?>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <table class="table table-borderless table-sm">
                            <tbody>
                                <tr>
                                    <td width="150" class="text-muted small">Total Transaksi</td>
                                    <td class="fw-bold fs-5 text-end text-success">
                                        <?php echo formatRupiah($penjualan['total']); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-muted small">Jumlah Bayar</td>
                                    <td class="text-end text-info">
                                        <?php echo formatRupiah($penjualan['bayar']); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-muted small">Kembalian</td>
                                    <td class="text-end text-primary">
                                        <?php echo formatRupiah($penjualan['kembalian']); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-muted small">Total Item</td>
                                    <td class="text-end">
                                        <span class="badge bg-primary"><?php echo $total_items; ?> item</span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-white border-0 py-3">
                <h5 class="mb-1"><i class="fas fa-cogs text-warning me-2"></i>Aksi Cepat</h5>
                <p class="text-muted mb-0 small">Kelola transaksi ini</p>
            </div>
            <div class="card-body d-flex flex-column justify-content-center">
                <div class="d-grid gap-2">
                    <a href="../penjualan/edit.php?id=<?php echo $penjualan_id; ?>" 
                       class="btn btn-outline-warning">
                        <i class="fas fa-edit me-2"></i>Edit Transaksi
                    </a>
                    <button onclick="printReceipt()" class="btn btn-outline-info">
                        <i class="fas fa-print me-2"></i>Cetak Struk
                    </button>
                    <a href="../penjualan/delete.php?id=<?php echo $penjualan_id; ?>" 
                       class="btn btn-outline-danger"
                       onclick="return confirm('Yakin hapus transaksi ini? Semua detail akan dihapus dan stok akan dikembalikan.')">
                        <i class="fas fa-trash me-2"></i>Hapus Transaksi
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Transaction Details Card -->
<div class="card border-0 shadow-sm mb-4">
    <div class="card-header bg-white border-0 py-3">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h5 class="mb-1"><i class="fas fa-boxes text-success me-2"></i>Detail Barang</h5>
                <p class="text-muted mb-0 small">Daftar barang dalam transaksi ini</p>
            </div>
            <div>
                <span class="badge bg-success me-2"><?php echo count($details); ?> jenis</span>
                <span class="badge bg-primary"><?php echo $total_items; ?> total item</span>
            </div>
        </div>
    </div>
    <div class="card-body">
        <?php if(empty($details)): ?>
        <div class="text-center py-5">
            <i class="fas fa-box-open fa-4x text-muted mb-3"></i>
            <h5 class="text-muted">Tidak Ada Barang</h5>
            <p class="text-muted mb-4">Belum ada barang dalam transaksi ini</p>
            <a href="add.php?penjualan_id=<?php echo $penjualan_id; ?>" class="btn btn-success">
                <i class="fas fa-plus me-2"></i>Tambah Barang Pertama
            </a>
        </div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead class="table-light">
                    <tr>
                        <th width="50" class="text-center">#</th>
                        <th width="100" class="text-center">ID Barang</th>
                        <th>Nama Barang</th>
                        <th width="150" class="text-end">Harga Satuan</th>
                        <th width="100" class="text-center">Qty</th>
                        <th width="150" class="text-end">Subtotal</th>
                        <th width="120" class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($details as $index => $detail): ?>
                    <tr>
                        <td class="text-center align-middle">
                            <span class="badge bg-light text-dark"><?php echo $index + 1; ?></span>
                        </td>
                        <td class="text-center align-middle">
                            <small class="text-muted"><?php echo $detail['id_barang']; ?></small>
                        </td>
                        <td class="align-middle">
                            <div class="fw-bold"><?php echo htmlspecialchars($detail['nama_barang']); ?></div>
                        </td>
                        <td class="text-end align-middle">
                            <?php echo formatRupiah($detail['harga']); ?>
                        </td>
                        <td class="text-center align-middle">
                            <span class="badge bg-info"><?php echo $detail['qty']; ?></span>
                        </td>
                        <td class="text-end align-middle">
                            <div class="fw-bold text-success"><?php echo formatRupiah($detail['subtotal']); ?></div>
                        </td>
                        <td class="text-center align-middle">
                            <div class="btn-group btn-group-sm" role="group">
                                <a href="edit.php?id=<?php echo $detail['id_detail']; ?>" 
                                   class="btn btn-outline-warning"
                                   data-bs-toggle="tooltip" title="Edit Barang">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="delete.php?id=<?php echo $detail['id_detail']; ?>" 
                                   class="btn btn-outline-danger"
                                   onclick="return confirm('Hapus barang ini dari transaksi?')"
                                   data-bs-toggle="tooltip" title="Hapus Barang">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot class="table-active">
                    <tr>
                        <td colspan="4" class="text-end fw-bold">GRAND TOTAL</td>
                        <td class="text-center fw-bold"><?php echo $total_items; ?></td>
                        <td colspan="2" class="text-end fw-bold fs-5 text-success">
                            <?php echo formatRupiah($penjualan['total']); ?>
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Receipt Preview Card -->
<div class="card border-0 shadow-sm">
    <div class="card-header bg-white border-0 py-3">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h5 class="mb-1"><i class="fas fa-receipt text-info me-2"></i>Preview Struk</h5>
                <p class="text-muted mb-0 small">Pratinjau struk untuk dicetak</p>
            </div>
            <div>
                <button onclick="printReceipt()" class="btn btn-info btn-sm">
                    <i class="fas fa-print me-2"></i>Cetak Struk
                </button>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div id="struk_preview" class="mx-auto" style="max-width: 300px;">
            <!-- Receipt Header -->
            <div class="text-center border-bottom pb-2 mb-2">
                <h4 class="fw-bold text-primary mb-1">Chalista Hijab</h4>
                <p class="text-muted small mb-1">Jl. Contoh No. 123, Jakarta</p>
                <p class="text-muted small mb-1">Telp: 0812-3456-7890</p>
                <hr class="my-2">
            </div>
            
            <!-- Transaction Info -->
            <div class="text-center mb-3">
                <p class="mb-1"><strong>TRANSACTION #<?php echo $penjualan['id_penjualan']; ?></strong></p>
                <p class="text-muted small mb-2">
                    <?php echo date('d/m/Y H:i:s', strtotime($penjualan['tanggal'])); ?>
                </p>
                <hr class="my-2">
            </div>
            
            <!-- Items List -->
            <div class="mb-3">
                <?php foreach($details as $detail): ?>
                <div class="d-flex justify-content-between mb-1">
                    <div>
                        <small class="fw-bold"><?php echo $detail['nama_barang']; ?></small><br>
                        <small class="text-muted">
                            <?php echo $detail['qty']; ?> x <?php echo formatRupiah($detail['harga']); ?>
                        </small>
                    </div>
                    <div class="text-end">
                        <small><?php echo formatRupiah($detail['subtotal']); ?></small>
                    </div>
                </div>
                <?php endforeach; ?>
                <hr class="my-2">
            </div>
            
            <!-- Payment Summary -->
            <div class="mb-3">
                <div class="d-flex justify-content-between mb-1">
                    <span>Total:</span>
                    <span class="fw-bold"><?php echo formatRupiah($penjualan['total']); ?></span>
                </div>
                <div class="d-flex justify-content-between mb-1">
                    <span>Bayar:</span>
                    <span><?php echo formatRupiah($penjualan['bayar']); ?></span>
                </div>
                <div class="d-flex justify-content-between mb-1">
                    <span>Kembali:</span>
                    <span><?php echo formatRupiah($penjualan['kembalian']); ?></span>
                </div>
                <div class="d-flex justify-content-between mb-1">
                    <span>Metode:</span>
                    <span><?php echo $penjualan['metode_pembayaran']; ?></span>
                </div>
                <hr class="my-2">
            </div>
            
            <!-- Footer -->
            <div class="text-center">
                <p class="text-muted small mb-1">Terima kasih atas kunjungan Anda</p>
                <p class="text-muted small">Barang yang sudah dibeli tidak dapat ditukar/dikembalikan</p>
                <hr class="my-2">
                <p class="small">*** STRUK INI SEBAGAI BUKTI PEMBAYARAN YANG SAH ***</p>
            </div>
        </div>
    </div>
</div>

<!-- Quick Stats -->
<div class="row mt-4">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="bg-primary bg-opacity-10 rounded-circle p-3 me-3">
                        <i class="fas fa-boxes text-primary fa-2x"></i>
                    </div>
                    <div>
                        <h6 class="mb-1">Ringkasan Barang</h6>
                        <p class="text-muted mb-0 small">Total item dalam transaksi</p>
                    </div>
                </div>
                <div class="mt-3">
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Jumlah Jenis:</span>
                        <span class="fw-bold"><?php echo count($details); ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Total Item:</span>
                        <span class="fw-bold text-primary"><?php echo $total_items; ?></span>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span class="text-muted">Rata Qty:</span>
                        <span class="fw-bold">
                            <?php echo count($details) > 0 ? round($total_items / count($details), 1) : 0; ?>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-8">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <h6 class="mb-3"><i class="fas fa-lightbulb text-warning me-2"></i>Tips Transaksi</h6>
                <div class="row">
                    <div class="col-md-6">
                        <div class="d-flex mb-3">
                            <div class="flex-shrink-0">
                                <i class="fas fa-check-circle text-success"></i>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <small class="fw-bold">Verifikasi Barang</small>
                                <p class="text-muted small mb-0">Pastikan semua barang sudah benar sebelum cetak struk</p>
                            </div>
                        </div>
                        <div class="d-flex">
                            <div class="flex-shrink-0">
                                <i class="fas fa-check-circle text-success"></i>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <small class="fw-bold">Update Stok</small>
                                <p class="text-muted small mb-0">Penjualan akan mengurangi stok barang secara otomatis</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="d-flex mb-3">
                            <div class="flex-shrink-0">
                                <i class="fas fa-check-circle text-success"></i>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <small class="fw-bold">Arsip Struk</small>
                                <p class="text-muted small mb-0">Simpan salinan struk untuk keperluan audit</p>
                            </div>
                        </div>
                        <div class="d-flex">
                            <div class="flex-shrink-0">
                                <i class="fas fa-check-circle text-success"></i>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <small class="fw-bold">Validasi Data</small>
                                <p class="text-muted small mb-0">Periksa kembali data sebelum menyimpan perubahan</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Initialize tooltips
document.addEventListener('DOMContentLoaded', function() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});

function printReceipt() {
    const printContent = document.getElementById('struk_preview').innerHTML;
    
    // Create receipt content
    const receiptContent = `
        <!DOCTYPE html>
        <html>
        <head>
            <title>Struk Transaksi #<?php echo $penjualan['id_penjualan']; ?></title>
            <style>
                @page {
                    size: 80mm auto;
                    margin: 0;
                }
                body {
                    width: 80mm;
                    margin: 0 auto;
                    padding: 10px;
                    font-family: 'Courier New', monospace;
                    font-size: 12px;
                    line-height: 1.3;
                }
                .text-center { text-align: center; }
                .text-right { text-align: right; }
                .fw-bold { font-weight: bold; }
                .border-bottom { border-bottom: 1px dashed #000; }
                hr { border-top: 1px dashed #000; margin: 5px 0; }
                .mb-1 { margin-bottom: 4px; }
                .mb-2 { margin-bottom: 8px; }
                .mb-3 { margin-bottom: 12px; }
            </style>
        </head>
        <body>
            <div style="width: 100%;">
                ${printContent}
            </div>
        </body>
        </html>
    `;
    
    // Open print window
    const printWindow = window.open('', '_blank');
    printWindow.document.write(receiptContent);
    printWindow.document.close();
    printWindow.focus();
    
    // Wait a moment before printing
    setTimeout(function() {
        printWindow.print();
        // Optional: close window after print
        // printWindow.close();
    }, 500);
}
</script>

<?php
$content = ob_get_clean();

// Include layout components
include '../views/default/header.php';
?>