<?php
session_start();
require_once '../lib/functions.php';
require_once '../lib/auth.php';

requireAuth();
requireModuleAccess('penjualan_detail');

require_once '../config/database.php';

$id = (int) ($_GET['id'] ?? 0);
if (!$id) redirect('index.php');

$stmt = mysqli_prepare($connection, "SELECT id_detail, id_penjualan, id_barang, qty, harga, subtotal FROM `penjualan_detail` WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$penjualan_detail = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$penjualan_detail) {
    redirect('index.php');
}

$error = $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_detail_post = trim($_POST['id_detail'] ?? '');
    $id_penjualan_post = trim($_POST['id_penjualan'] ?? '');
    $id_barang_post = trim($_POST['id_barang'] ?? '');
    $qty_post = trim($_POST['qty'] ?? '');
    $harga_post = trim($_POST['harga'] ?? '');
    $subtotal_post = trim($_POST['subtotal'] ?? '');
    if (empty($id_detail_post) || empty($id_penjualan_post) || empty($id_barang_post) || empty($qty_post) || empty($harga_post) || empty($subtotal_post)) {
        $error = "Id Detail dan Id Penjualan dan Id Barang dan Qty dan Harga dan Subtotal wajib diisi.";
    }
    if (!$error) {
        $stmt = mysqli_prepare($connection, "UPDATE `penjualan_detail` SET `id_detail` = ?, `id_penjualan` = ?, `id_barang` = ?, `qty` = ?, `harga` = ?, `subtotal` = ? WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "iiiiiii", $id_detail_post, $id_penjualan_post, $id_barang_post, $qty_post, $harga_post, $subtotal_post, $id);

        if (mysqli_stmt_execute($stmt)) {
            $success = "Penjualan Detail berhasil diperbarui.";
            mysqli_stmt_close($stmt);
            $stmt = mysqli_prepare($connection, "SELECT id_detail, id_penjualan, id_barang, qty, harga, subtotal FROM `penjualan_detail` WHERE id = ?");
            mysqli_stmt_bind_param($stmt, "i", $id);
            mysqli_stmt_execute($stmt);
            $penjualan_detail = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
            echo "<script>
                setTimeout(function() {
                    window.location.href = 'index.php';
                }, 2000);
            </script>";
        } else {
            $error = "Gagal memperbarui: " . mysqli_error($connection);
        }
        mysqli_stmt_close($stmt);
    }
}
?>

<?php include '../views/'.$THEME.'/header.php'; ?>
<?php include '../views/'.$THEME.'/sidebar.php'; ?>
<?php include '../views/'.$THEME.'/topnav.php'; ?>
<?php include '../views/'.$THEME.'/upper_block.php'; ?>

            <h2>Edit Penjualan Detail</h2>
            <?php if ($error): ?>
                <?= showAlert($error, 'danger') ?>
            <?php endif; ?>
            <?php if ($success): ?>
                <?= showAlert($success, 'success') ?>
            <?php endif; ?>
            <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Id Detail*</label>
                        <input type="number" name="id_detail" class="form-control" value="<?= $penjualan_detail['id_detail'] ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Id Penjualan*</label>
                        <input type="number" name="id_penjualan" class="form-control" value="<?= $penjualan_detail['id_penjualan'] ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Id Barang*</label>
                        <input type="number" name="id_barang" class="form-control" value="<?= $penjualan_detail['id_barang'] ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Qty*</label>
                        <input type="number" name="qty" class="form-control" value="<?= $penjualan_detail['qty'] ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Harga*</label>
                        <input type="number" name="harga" class="form-control" value="<?= $penjualan_detail['harga'] ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Subtotal*</label>
                        <input type="number" name="subtotal" class="form-control" value="<?= $penjualan_detail['subtotal'] ?>">
                    </div>
                <button type="submit" class="btn btn-primary">Perbarui</button>
                <a href="index.php" class="btn btn-secondary">Batal</a>
            </form>


<?php include '../views/'.$THEME.'/lower_block.php'; ?>
<?php include '../views/'.$THEME.'/footer.php'; ?>
