<?php
require_once '../lib/auth.php';
require_once '../lib/functions.php';

$auth = new Auth();
$auth->checkAuth();

$db = Database::getInstance()->getConnection();

$id = $_GET['id'] ?? 0;

// Check if barang exists
$stmt = $db->prepare("SELECT * FROM barang WHERE id_barang = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    flash('flash_message', 'Barang tidak ditemukan!', 'alert alert-danger');
    redirect('index.php');
}

// Check if barang used in penjualan
$checkStmt = $db->prepare("SELECT COUNT(*) as count FROM penjualan_detail WHERE id_barang = ?");
$checkStmt->bind_param("i", $id);
$checkStmt->execute();
$checkResult = $checkStmt->get_result()->fetch_assoc();

if ($checkResult['count'] > 0) {
    flash('flash_message', 'Barang tidak dapat dihapus karena sudah ada dalam transaksi!', 'alert alert-danger');
    redirect('index.php');
}

// Delete barang
$deleteStmt = $db->prepare("DELETE FROM barang WHERE id_barang = ?");
$deleteStmt->bind_param("i", $id);

if ($deleteStmt->execute()) {
    flash('flash_message', 'Barang berhasil dihapus!', 'alert alert-success');
} else {
    flash('flash_message', 'Gagal menghapus barang!', 'alert alert-danger');
}

redirect('index.php');
?>