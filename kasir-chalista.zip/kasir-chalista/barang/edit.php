<?php
require_once '../lib/auth.php';
require_once '../lib/functions.php';

$auth = new Auth();
$auth->checkAuth();

$db = Database::getInstance()->getConnection();

$id = $_GET['id'] ?? 0;

// Get barang data
$stmt = $db->prepare("SELECT * FROM barang WHERE id_barang = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$barang = $result->fetch_assoc();

if (!$barang) {
    flash('flash_message', 'Barang tidak ditemukan!', 'alert alert-danger');
    redirect('index.php');
}

// Calculate current values
$nilai_stok_lama = $barang['harga'] * $barang['stok'];

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_barang = trim($_POST['nama_barang'] ?? '');
    $harga = trim($_POST['harga'] ?? '');
    $stok = trim($_POST['stok'] ?? '');
    
    // Validation
    if (empty($nama_barang) || empty($harga) || empty($stok)) {
        $error = 'Semua field harus diisi!';
    } elseif (!is_numeric($harga) || $harga < 0) {
        $error = 'Harga harus angka positif!';
    } elseif (!is_numeric($stok) || $stok < 0) {
        $error = 'Stok harus angka positif!';
    } else {
        // Clean numeric values
        $harga = (int)$harga;
        $stok = (int)$stok;
        
        $stmt = $db->prepare("UPDATE barang SET nama_barang = ?, harga = ?, stok = ? WHERE id_barang = ?");
        $stmt->bind_param("siii", $nama_barang, $harga, $stok, $id);
        
        if ($stmt->execute()) {
            flash('flash_message', 'Barang berhasil diperbarui!', 'alert alert-success');
            redirect('index.php');
        } else {
            $error = 'Gagal memperbarui barang! ' . $db->error;
        }
    }
}

// Get statistics for comparison
$statsSql = "SELECT 
    COUNT(*) as total_barang,
    SUM(harga * stok) as total_nilai,
    AVG(harga) as avg_harga
    FROM barang";
$statsResult = $db->query($statsSql);
$stats = $statsResult->fetch_assoc();

$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => '../admin/index.php', 'icon' => 'fas fa-home'],
    ['name' => 'Barang', 'url' => 'index.php', 'icon' => 'fas fa-box'],
    ['name' => 'Edit Barang', 'url' => 'edit.php', 'active' => true]
];

$pageTitle = 'Edit Barang - ' . htmlspecialchars($barang['nama_barang']);

$actionButtons = [
    [
        'url' => 'index.php',
        'class' => 'btn btn-outline-secondary',
        'icon' => 'fas fa-arrow-left',
        'text' => 'Kembali ke Daftar'
    ]
];

ob_start();
?>


<!-- Main Form Card -->
<div class="row justify-content-center">
    <div class="col-lg-10">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white border-0 py-3">
                <div class="d-flex align-items-center">
                    <div class="bg-warning bg-opacity-10 rounded-circle p-3 me-3">
                        <i class="fas fa-edit fa-2x text-warning"></i>
                    </div>
                    <div>
                        <h5 class="mb-1">Edit Barang - <?php echo htmlspecialchars($barang['nama_barang']); ?></h5>
                        <p class="text-muted mb-0 small">ID Barang: #<?php echo $barang['id_barang']; ?> | Perbarui informasi barang dengan hati-hati</p>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <!-- Barang Info Alert -->
                <div class="alert alert-info border-0 shadow-sm mb-4">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-info-circle fa-lg me-3"></i>
                        <div>
                            <h6 class="mb-1">Informasi Barang Saat Ini</h6>
                            <p class="mb-0 small">Perubahan yang Anda buat akan langsung diterapkan ke sistem. Pastikan data yang dimasukkan sudah benar.</p>
                        </div>
                    </div>
                </div>
                
                <?php if($error): ?>
                <div class="alert alert-danger border-0 shadow-sm mb-4">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-exclamation-circle fa-lg me-3"></i>
                        <div>
                            <h6 class="mb-1">Terjadi Kesalahan</h6>
                            <p class="mb-0"><?php echo $error; ?></p>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Current Data Summary -->
                <div class="row mb-4">
                    <div class="col-md-4 mb-3">
                        <div class="card border-0 bg-light h-100">
                            <div class="card-body text-center">
                                <div class="bg-primary bg-opacity-10 rounded-circle p-3 d-inline-block mb-3">
                                    <i class="fas fa-tag fa-2x text-primary"></i>
                                </div>
                                <h6 class="card-title">Nama Saat Ini</h6>
                                <p class="text-primary fw-bold mb-0"><?php echo htmlspecialchars($barang['nama_barang']); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card border-0 bg-light h-100">
                            <div class="card-body text-center">
                                <div class="bg-success bg-opacity-10 rounded-circle p-3 d-inline-block mb-3">
                                    <i class="fas fa-money-bill-wave fa-2x text-success"></i>
                                </div>
                                <h6 class="card-title">Harga Saat Ini</h6>
                                <p class="text-success fw-bold mb-0"><?php echo formatRupiah($barang['harga']); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card border-0 bg-light h-100">
                            <div class="card-body text-center">
                                <div class="bg-warning bg-opacity-10 rounded-circle p-3 d-inline-block mb-3">
                                    <i class="fas fa-layer-group fa-2x text-warning"></i>
                                </div>
                                <h6 class="card-title">Stok Saat Ini</h6>
                                <p class="text-warning fw-bold mb-0"><?php echo $barang['stok']; ?> pcs</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <form method="POST" action="" class="needs-validation" novalidate>
                    <div class="row">
                        <!-- Nama Barang -->
                        <div class="col-md-6 mb-4">
                            <div class="card border-0 bg-light h-100">
                                <div class="card-body">
                                    <label for="nama_barang" class="form-label fw-bold">
                                        <i class="fas fa-tag text-primary me-2"></i>Nama Barang
                                    </label>
                                    <input type="text" 
                                           class="form-control form-control-lg border-0 bg-white" 
                                           id="nama_barang" 
                                           name="nama_barang" 
                                           value="<?php echo htmlspecialchars($barang['nama_barang']); ?>" 
                                           required>
                                    <div class="form-text mt-2">
                                        <i class="fas fa-info-circle text-info me-1"></i>
                                        Ubah nama barang jika diperlukan
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Harga -->
                        <div class="col-md-3 mb-4">
                            <div class="card border-0 bg-light h-100">
                                <div class="card-body">
                                    <label for="harga" class="form-label fw-bold">
                                        <i class="fas fa-money-bill-wave text-success me-2"></i>Harga Baru
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-white border-0">
                                            <i class="fas fa-dollar-sign text-muted"></i>
                                        </span>
                                        <input type="number" 
                                               class="form-control form-control-lg border-0 bg-white" 
                                               id="harga" 
                                               name="harga" 
                                               value="<?php echo $barang['harga']; ?>" 
                                               min="0" 
                                               step="1000" 
                                               required>
                                    </div>
                                    <div class="form-text mt-2">
                                        <i class="fas fa-info-circle text-info me-1"></i>
                                        Harga per unit
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Stok -->
                        <div class="col-md-3 mb-4">
                            <div class="card border-0 bg-light h-100">
                                <div class="card-body">
                                    <label for="stok" class="form-label fw-bold">
                                        <i class="fas fa-layer-group text-warning me-2"></i>Stok Baru
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-white border-0">
                                            <i class="fas fa-box text-muted"></i>
                                        </span>
                                        <input type="number" 
                                               class="form-control form-control-lg border-0 bg-white" 
                                               id="stok" 
                                               name="stok" 
                                               value="<?php echo $barang['stok']; ?>" 
                                               min="0" 
                                               required>
                                        <span class="input-group-text bg-white border-0">pcs</span>
                                    </div>
                                    <div class="form-text mt-2">
                                        <i class="fas fa-info-circle text-info me-1"></i>
                                        Jumlah stok yang tersedia
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Preview Changes -->
                    <div class="card border-0 bg-light mb-4">
                        <div class="card-header bg-white border-0">
                            <h6 class="mb-0"><i class="fas fa-exchange-alt text-info me-2"></i>Preview Perubahan</h6>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="text-center">
                                        <div class="bg-primary bg-opacity-10 rounded-circle p-4 d-inline-block mb-3">
                                            <i class="fas fa-tag fa-3x text-primary"></i>
                                        </div>
                                        <h6 class="mb-1">Nama Barang</h6>
                                        <p class="text-muted mb-0 small" id="preview-nama"><?php echo htmlspecialchars($barang['nama_barang']); ?></p>
                                        <small class="text-info">Akan diperbarui</small>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="text-center">
                                        <div class="bg-success bg-opacity-10 rounded-circle p-4 d-inline-block mb-3">
                                            <i class="fas fa-money-bill-wave fa-3x text-success"></i>
                                        </div>
                                        <h6 class="mb-1">Harga Baru</h6>
                                        <p class="text-muted mb-0 small" id="preview-harga"><?php echo formatRupiah($barang['harga']); ?></p>
                                        <small class="text-info"><?php echo $barang['harga'] == $barang['harga'] ? 'Tidak berubah' : 'Akan diubah'; ?></small>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="text-center">
                                        <div class="bg-warning bg-opacity-10 rounded-circle p-4 d-inline-block mb-3">
                                            <i class="fas fa-layer-group fa-3x text-warning"></i>
                                        </div>
                                        <h6 class="mb-1">Stok Baru</h6>
                                        <p class="text-muted mb-0 small" id="preview-stok"><?php echo $barang['stok']; ?> pcs</p>
                                        <small class="text-info"><?php echo $barang['stok'] == $barang['stok'] ? 'Tidak berubah' : 'Akan diubah'; ?></small>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Nilai Stok Comparison -->
                            <div class="row mt-4">
                                <div class="col-md-6">
                                    <div class="card border-0 bg-white">
                                        <div class="card-body text-center">
                                            <h6 class="card-title">Nilai Stok Saat Ini</h6>
                                            <h4 class="text-primary"><?php echo formatRupiah($nilai_stok_lama); ?></h4>
                                            <small class="text-muted">Harga × Stok lama</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="card border-0 bg-white">
                                        <div class="card-body text-center">
                                            <h6 class="card-title">Nilai Stok Baru</h6>
                                            <h4 class="text-success" id="preview-nilai-stok"><?php echo formatRupiah($nilai_stok_lama); ?></h4>
                                            <small class="text-muted">Harga baru × Stok baru</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Action Buttons -->
                    <div class="row mt-4">
                        <div class="col-12">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <a href="index.php" class="btn btn-outline-secondary">
                                        <i class="fas fa-arrow-left me-2"></i>Batal & Kembali
                                    </a>
                                </div>
                                <div class="d-flex gap-3">
                                    <button type="reset" class="btn btn-outline-warning">
                                        <i class="fas fa-redo me-2"></i>Reset Perubahan
                                    </button>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save me-2"></i>Simpan Perubahan
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Important Notes Card -->
        <div class="card border-0 shadow-sm mt-4">
            <div class="card-header bg-white border-0 py-3">
                <h6 class="mb-0"><i class="fas fa-exclamation-triangle text-warning me-2"></i>Penting untuk Diperhatikan</h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <div class="d-flex">
                            <div class="flex-shrink-0">
                                <i class="fas fa-check-circle text-success"></i>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <small class="fw-bold d-block">Perubahan Harga</small>
                                <p class="text-muted small mb-0">Perubahan harga akan mempengaruhi transaksi berikutnya</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <div class="d-flex">
                            <div class="flex-shrink-0">
                                <i class="fas fa-check-circle text-success"></i>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <small class="fw-bold d-block">Update Stok</small>
                                <p class="text-muted small mb-0">Pastikan stok yang diupdate sesuai dengan fisik di gudang</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="alert alert-warning border-0 mt-3">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-lightbulb fa-lg me-3"></i>
                        <div>
                            <h6 class="mb-1">Tips Editing Barang</h6>
                            <ul class="mb-0 small">
                                <li>Perubahan harga tidak mempengaruhi transaksi yang sudah terjadi</li>
                                <li>Update stok secara real-time untuk akurasi inventori</li>
                                <li>Simpan perubahan secara berkala untuk menghindari kehilangan data</li>
                                <li>Periksa kembali sebelum menyimpan perubahan permanen</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript untuk Preview Real-time -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Elements
    const namaInput = document.getElementById('nama_barang');
    const hargaInput = document.getElementById('harga');
    const stokInput = document.getElementById('stok');
    const previewNama = document.getElementById('preview-nama');
    const previewHarga = document.getElementById('preview-harga');
    const previewStok = document.getElementById('preview-stok');
    const previewNilaiStok = document.getElementById('preview-nilai-stok');
    
    // Original values
    const originalHarga = <?php echo $barang['harga']; ?>;
    const originalStok = <?php echo $barang['stok']; ?>;
    
    // Format currency
    function formatCurrency(value) {
        return 'Rp ' + parseInt(value || 0).toLocaleString('id-ID');
    }
    
    // Calculate stock value
    function calculateStockValue(harga, stok) {
        return harga * stok;
    }
    
    // Update preview function
    function updatePreview() {
        // Update nama
        previewNama.textContent = namaInput.value || '<?php echo htmlspecialchars($barang['nama_barang']); ?>';
        
        // Update harga
        const hargaValue = parseInt(hargaInput.value) || originalHarga;
        previewHarga.textContent = formatCurrency(hargaValue);
        
        // Update stok
        const stokValue = parseInt(stokInput.value) || originalStok;
        previewStok.textContent = stokValue + ' pcs';
        
        // Update nilai stok
        const nilaiStok = calculateStockValue(hargaValue, stokValue);
        previewNilaiStok.textContent = formatCurrency(nilaiStok);
        
        // Update change indicators
        const hargaChanged = hargaValue !== originalHarga;
        const stokChanged = stokValue !== originalStok;
        
        // You could add visual indicators for changes here
    }
    
    // Add event listeners
    namaInput.addEventListener('input', updatePreview);
    hargaInput.addEventListener('input', updatePreview);
    stokInput.addEventListener('input', updatePreview);
    
    // Initial update
    updatePreview();
    
    // Form validation
    const forms = document.querySelectorAll('.needs-validation');
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });
    
    // Auto-format harga input
    hargaInput.addEventListener('blur', function() {
        if (this.value) {
            this.value = parseInt(this.value).toLocaleString('id-ID');
        }
    });
    
    hargaInput.addEventListener('focus', function() {
        if (this.value) {
            this.value = this.value.replace(/[^0-9]/g, '');
        }
    });
    
    // Reset button functionality
    const resetButton = document.querySelector('button[type="reset"]');
    resetButton.addEventListener('click', function() {
        setTimeout(updatePreview, 100);
    });
});
</script>

<?php
$content = ob_get_clean();
include '../views/default/header.php';
?>