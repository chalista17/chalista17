<?php
require_once '../lib/auth.php';
require_once '../lib/functions.php';

$auth = new Auth();
$auth->checkAuth();

$db = Database::getInstance()->getConnection();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_barang = trim($_POST['nama_barang'] ?? '');
    $harga = trim($_POST['harga'] ?? '');
    $stok = trim($_POST['stok'] ?? '');
    
    // DEBUG: Log POST data
    error_log("POST Data: nama=$nama_barang, harga=$harga, stok=$stok");
    
    // Validation
    if (empty($nama_barang) || empty($harga) || empty($stok)) {
        $error = 'Semua field harus diisi!';
    } elseif (!is_numeric($harga) || $harga < 0) {
        $error = 'Harga harus angka positif!';
    } elseif (!is_numeric($stok) || $stok < 0) {
        $error = 'Stok harus angka positif!';
    } else {
        // Clean numeric values - remove any formatting
        $harga = (int) preg_replace('/[^0-9]/', '', $harga);
        $stok = (int) $stok;
        
        error_log("Cleaned Values: nama=$nama_barang, harga=$harga, stok=$stok");
        
        try {
            $stmt = $db->prepare("INSERT INTO barang (nama_barang, harga, stok) VALUES (?, ?, ?)");
            
            if (!$stmt) {
                throw new Exception("Prepare failed: " . $db->error);
            }
            
            $stmt->bind_param("sii", $nama_barang, $harga, $stok);
            
            if ($stmt->execute()) {
                $last_id = $db->insert_id;
                error_log("Insert successful! ID: $last_id");
                
                flash('flash_message', 'Barang berhasil ditambahkan! ID: #' . $last_id, 'alert alert-success');
                redirect('index.php');
                exit;
            } else {
                throw new Exception("Execute failed: " . $stmt->error);
            }
        } catch (Exception $e) {
            $error = 'Gagal menambahkan barang! ' . $e->getMessage();
            error_log("Database error: " . $e->getMessage());
        }
    }
}

// Get statistics for quick info
$statsSql = "SELECT 
    COUNT(*) as total_barang,
    SUM(harga * stok) as total_nilai,
    AVG(harga) as avg_harga
    FROM barang";
$statsResult = $db->query($statsSql);
$stats = $statsResult ? $statsResult->fetch_assoc() : [
    'total_barang' => 0,
    'total_nilai' => 0,
    'avg_harga' => 0
];

$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => '../admin/index.php', 'icon' => 'fas fa-home'],
    ['name' => 'Barang', 'url' => 'index.php', 'icon' => 'fas fa-box'],
    ['name' => 'Tambah Barang', 'url' => 'add.php', 'active' => true]
];

$pageTitle = 'Tambah Barang Baru';

$actionButtons = [
    [
        'url' => 'index.php',
        'class' => 'btn btn-outline-secondary',
        'icon' => 'fas fa-arrow-left',
        'text' => 'Kembali ke Daftar'
    ]
];

ob_start();
?>

<!-- Main Form Card -->
<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white border-0 py-3">
                <div class="d-flex align-items-center">
                    <div class="bg-primary bg-opacity-10 rounded-circle p-3 me-3">
                        <i class="fas fa-plus-circle fa-2x text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-1">Tambah Barang Baru</h5>
                        <p class="text-muted mb-0 small">Lengkapi form di bawah untuk menambahkan barang baru ke inventori</p>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?php if($error): ?>
                <div class="alert alert-danger border-0 shadow-sm">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-exclamation-circle fa-lg me-3"></i>
                        <div>
                            <h6 class="mb-1">Terjadi Kesalahan</h6>
                            <p class="mb-0"><?php echo htmlspecialchars($error); ?></p>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <form method="POST" action="" class="needs-validation" novalidate>
                    <div class="row">
                        <!-- Nama Barang -->
                        <div class="col-md-6 mb-4">
                            <div class="card border-0 bg-light h-100">
                                <div class="card-body">
                                    <label for="nama_barang" class="form-label fw-bold">
                                        <i class="fas fa-tag text-primary me-2"></i>Nama Barang
                                    </label>
                                    <input type="text" 
                                           class="form-control form-control-lg border-0 bg-white" 
                                           id="nama_barang" 
                                           name="nama_barang" 
                                           placeholder="Contoh: Kerudung Paris Premium" 
                                           required
                                           value="<?php echo isset($_POST['nama_barang']) ? htmlspecialchars($_POST['nama_barang']) : ''; ?>">
                                    <div class="form-text mt-2">
                                        <i class="fas fa-info-circle text-info me-1"></i>
                                        Gunakan nama yang jelas dan mudah dikenali
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Harga -->
                        <div class="col-md-3 mb-4">
                            <div class="card border-0 bg-light h-100">
                                <div class="card-body">
                                    <label for="harga" class="form-label fw-bold">
                                        <i class="fas fa-money-bill-wave text-success me-2"></i>Harga
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-white border-0">
                                            <i class="fas fa-dollar-sign text-muted"></i>
                                        </span>
                                        <input type="text" 
                                               class="form-control form-control-lg border-0 bg-white" 
                                               id="harga" 
                                               name="harga" 
                                               min="0" 
                                               step="1000" 
                                               placeholder="0" 
                                               required
                                               value="<?php echo isset($_POST['harga']) ? htmlspecialchars($_POST['harga']) : ''; ?>"
                                               pattern="[0-9,]*">
                                    </div>
                                    <div class="form-text mt-2">
                                        <i class="fas fa-info-circle text-info me-1"></i>
                                        Masukkan angka saja (contoh: 50000)
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Stok -->
                        <div class="col-md-3 mb-4">
                            <div class="card border-0 bg-light h-100">
                                <div class="card-body">
                                    <label for="stok" class="form-label fw-bold">
                                        <i class="fas fa-layer-group text-warning me-2"></i>Stok Awal
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-white border-0">
                                            <i class="fas fa-box text-muted"></i>
                                        </span>
                                        <input type="number" 
                                               class="form-control form-control-lg border-0 bg-white" 
                                               id="stok" 
                                               name="stok" 
                                               min="0" 
                                               placeholder="0" 
                                               required
                                               value="<?php echo isset($_POST['stok']) ? htmlspecialchars($_POST['stok']) : ''; ?>">
                                        <span class="input-group-text bg-white border-0">pcs</span>
                                    </div>
                                    <div class="form-text mt-2">
                                        <i class="fas fa-info-circle text-info me-1"></i>
                                        Jumlah stok awal yang tersedia
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Preview Card -->
                    <div class="card border-0 bg-light mb-4">
                        <div class="card-header bg-white border-0">
                            <h6 class="mb-0"><i class="fas fa-eye text-info me-2"></i>Preview Barang</h6>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="text-center">
                                        <div class="bg-primary bg-opacity-10 rounded-circle p-4 d-inline-block mb-3">
                                            <i class="fas fa-box fa-3x text-primary"></i>
                                        </div>
                                        <h6 class="mb-1">Nama Barang</h6>
                                        <p class="text-muted mb-0 small" id="preview-nama">-</p>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="text-center">
                                        <div class="bg-success bg-opacity-10 rounded-circle p-4 d-inline-block mb-3">
                                            <i class="fas fa-money-bill-wave fa-3x text-success"></i>
                                        </div>
                                        <h6 class="mb-1">Harga</h6>
                                        <p class="text-muted mb-0 small" id="preview-harga">Rp 0</p>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="text-center">
                                        <div class="bg-warning bg-opacity-10 rounded-circle p-4 d-inline-block mb-3">
                                            <i class="fas fa-layer-group fa-3x text-warning"></i>
                                        </div>
                                        <h6 class="mb-1">Stok Awal</h6>
                                        <p class="text-muted mb-0 small" id="preview-stok">0 pcs</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Action Buttons -->
                    <div class="row mt-4">
                        <div class="col-12">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <a href="index.php" class="btn btn-outline-secondary">
                                        <i class="fas fa-arrow-left me-2"></i>Batal & Kembali
                                    </a>
                                </div>
                                <div class="d-flex gap-3">
                                    <button type="reset" class="btn btn-outline-warning">
                                        <i class="fas fa-redo me-2"></i>Reset Form
                                    </button>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save me-2"></i>Simpan Barang
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Quick Help Card -->
        <div class="card border-0 shadow-sm mt-4">
            <div class="card-header bg-white border-0 py-3">
                <h6 class="mb-0"><i class="fas fa-question-circle text-info me-2"></i>Panduan Pengisian</h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <div class="d-flex">
                            <div class="flex-shrink-0">
                                <i class="fas fa-check-circle text-success"></i>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <small class="fw-bold d-block">Nama Barang</small>
                                <p class="text-muted small mb-0">Gunakan nama yang spesifik dan mudah dikenali pelanggan</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="d-flex">
                            <div class="flex-shrink-0">
                                <i class="fas fa-check-circle text-success"></i>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <small class="fw-bold d-block">Harga Jual</small>
                                <p class="text-muted small mb-0">Masukkan angka saja tanpa titik/koma (contoh: 50000)</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="d-flex">
                            <div class="flex-shrink-0">
                                <i class="fas fa-check-circle text-success"></i>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <small class="fw-bold d-block">Stok Awal</small>
                                <p class="text-muted small mb-0">Masukkan jumlah stok yang tersedia saat ini</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="alert alert-info border-0 mt-3">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-lightbulb fa-lg me-3"></i>
                        <div>
                            <h6 class="mb-1">Tips Penambahan Barang</h6>
                            <ul class="mb-0 small">
                                <li>Pastikan nama barang unik untuk menghindari duplikasi</li>
                                <li>Periksa harga dengan kompetitor untuk tetap kompetitif</li>
                                <li>Update stok secara berkala untuk akurasi inventori</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript untuk Preview Real-time -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Elements
    const namaInput = document.getElementById('nama_barang');
    const hargaInput = document.getElementById('harga');
    const stokInput = document.getElementById('stok');
    const previewNama = document.getElementById('preview-nama');
    const previewHarga = document.getElementById('preview-harga');
    const previewStok = document.getElementById('preview-stok');
    
    // Format currency
    function formatCurrency(value) {
        // Remove any non-numeric characters
        const numericValue = parseInt(value.toString().replace(/[^0-9]/g, '')) || 0;
        return 'Rp ' + numericValue.toLocaleString('id-ID');
    }
    
    // Clean harga input for submission
    function cleanHargaValue(value) {
        return value.toString().replace(/[^0-9]/g, '');
    }
    
    // Update preview function
    function updatePreview() {
        // Update nama
        previewNama.textContent = namaInput.value || '-';
        
        // Update harga
        previewHarga.textContent = formatCurrency(hargaInput.value);
        
        // Update stok
        if (stokInput.value) {
            previewStok.textContent = stokInput.value + ' pcs';
        } else {
            previewStok.textContent = '0 pcs';
        }
    }
    
    // Add event listeners
    namaInput.addEventListener('input', updatePreview);
    hargaInput.addEventListener('input', updatePreview);
    stokInput.addEventListener('input', updatePreview);
    
    // Format harga on blur
    hargaInput.addEventListener('blur', function() {
        if (this.value) {
            this.value = formatCurrency(this.value);
        }
    });
    
    // Clean harga on focus
    hargaInput.addEventListener('focus', function() {
        if (this.value) {
            this.value = cleanHargaValue(this.value);
        }
    });
    
    // Clean harga before form submission
    const form = document.querySelector('form');
    form.addEventListener('submit', function() {
        hargaInput.value = cleanHargaValue(hargaInput.value);
    });
    
    // Initial update
    updatePreview();
    
    // Form validation
    const forms = document.querySelectorAll('.needs-validation');
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', function(event) {
            // Clean harga before validation
            hargaInput.value = cleanHargaValue(hargaInput.value);
            
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            
            form.classList.add('was-validated');
        }, false);
    });
});
</script>

<?php
$content = ob_get_clean();
include '../views/default/header.php';
?>