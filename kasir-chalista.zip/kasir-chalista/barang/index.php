<?php
require_once '../lib/auth.php';
require_once '../lib/functions.php';

$auth = new Auth();
$auth->checkAuth();

$db = Database::getInstance()->getConnection();

// Handle search
$search = $_GET['search'] ?? '';
$where = '';
$params = [];
$types = '';

if (!empty($search)) {
    $where = " WHERE nama_barang LIKE ?";
    $params[] = "%$search%";
    $types = "s";
}

// Get total records for pagination
if (!empty($where)) {
    $stmt = $db->prepare("SELECT COUNT(*) as total FROM barang $where");
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $totalResult = $stmt->get_result();
} else {
    $stmt = $db->prepare("SELECT COUNT(*) as total FROM barang");
    $stmt->execute();
    $totalResult = $stmt->get_result();
}
$totalRecords = $totalResult->fetch_assoc()['total'];

// Pagination
$limit = 10;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;
$offset = ($page - 1) * $limit;
$totalPages = ceil($totalRecords / $limit);

// Get barang data
if (!empty($where)) {
    $sql = "SELECT * FROM barang $where ORDER BY id_barang DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    $types .= "ii";
    
    $stmt = $db->prepare($sql);
    $stmt->bind_param($types, ...$params);
} else {
    $sql = "SELECT * FROM barang ORDER BY id_barang DESC LIMIT ? OFFSET ?";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("ii", $limit, $offset);
}

$stmt->execute();
$result = $stmt->get_result();
$barang = $result->fetch_all(MYSQLI_ASSOC);

// Calculate total value
$totalValueSql = "SELECT SUM(harga * stok) as total_nilai FROM barang";
$totalValueResult = $db->query($totalValueSql);
$totalValue = $totalValueResult->fetch_assoc()['total_nilai'] ?? 0;

$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => '../admin/index.php', 'active' => false],
    ['name' => 'Barang', 'url' => 'index.php', 'active' => true]
];

$pageTitle = 'Manajemen Barang';

$actionButtons = [
    [
        'url' => 'add.php',
        'class' => 'btn btn-success',
        'icon' => 'fas fa-plus',
        'text' => 'Tambah Barang'
    ]
];

ob_start();
?>

<!-- Summary -->
<div class="row mb-4">
    <div class="col-md-6">
        <div class="card stat-card bg-primary bg-gradient text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-subtitle mb-1 opacity-75">Total Barang</h6>
                        <h2 class="card-title mb-0"><?php echo $totalRecords; ?></h2>
                        <small class="opacity-75">item tersedia</small>
                    </div>
                    <div class="bg-white bg-opacity-25 rounded-circle p-3">
                        <i class="fas fa-box fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card stat-card bg-success bg-gradient text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-subtitle mb-1 opacity-75">Total Nilai Stok</h6>
                        <h2 class="card-title mb-0"><?php echo formatRupiah($totalValue); ?></h2>
                        <small class="opacity-75">nilai inventori</small>
                    </div>
                    <div class="bg-white bg-opacity-25 rounded-circle p-3">
                        <i class="fas fa-money-bill-wave fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Search Bar -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" action="" class="row g-3">
            <div class="col-md-8">
                <div class="input-group">
                    <input type="text" name="search" class="form-control" 
                           placeholder="Cari nama barang..." 
                           value="<?php echo htmlspecialchars($search); ?>">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search me-1"></i>Cari
                    </button>
                    <?php if(!empty($search)): ?>
                    <a href="index.php" class="btn btn-outline-secondary">
                        <i class="fas fa-times me-1"></i>Reset
                    </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-4 text-end">
                <div class="btn-group">
                    <a href="add.php" class="btn btn-success">
                        <i class="fas fa-plus me-1"></i>Tambah Barang
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Barang Table -->
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Daftar Barang</h5>
        <span class="badge bg-primary"><?php echo $totalRecords; ?> item</span>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th width="50">#</th>
                        <th>Nama Barang</th>
                        <th width="150" class="text-end">Harga</th>
                        <th width="120" class="text-center">Stok</th>
                        <th width="150" class="text-end">Nilai Stok</th>
                        <th width="150" class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($barang)): ?>
                    <tr>
                        <td colspan="6" class="text-center py-4">
                            <i class="fas fa-box fa-3x text-muted mb-3"></i>
                            <p class="text-muted">Tidak ada data barang</p>
                            <?php if(!empty($search)): ?>
                            <a href="index.php" class="btn btn-outline-primary btn-sm">
                                <i class="fas fa-redo me-1"></i>Tampilkan Semua
                            </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php else: ?>
                    <?php 
                    $counter = ($page - 1) * $limit + 1;
                    foreach($barang as $item): 
                        $nilai_stok = $item['harga'] * $item['stok'];
                    ?>
                    <tr>
                        <td class="text-muted"><?php echo $counter++; ?></td>
                        <td>
                            <div class="d-flex align-items-center">
                                <div class="bg-light rounded p-2 me-3">
                                    <i class="fas fa-box text-primary"></i>
                                </div>
                                <div>
                                    <h6 class="mb-0"><?php echo htmlspecialchars($item['nama_barang']); ?></h6>
                                    <small class="text-muted">ID: #<?php echo $item['id_barang']; ?></small>
                                </div>
                            </div>
                        </td>
                        <td class="text-end">
                            <strong><?php echo formatRupiah($item['harga']); ?></strong>
                        </td>
                        <td class="text-center">
                            <?php echo getStockBadge($item['stok']); ?>
                        </td>
                        <td class="text-end">
                            <strong><?php echo formatRupiah($nilai_stok); ?></strong>
                        </td>
                        <td class="text-center">
                            <div class="btn-group btn-group-sm" role="group">
                                <a href="edit.php?id=<?php echo $item['id_barang']; ?>" 
                                   class="btn btn-outline-warning" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="delete.php?id=<?php echo $item['id_barang']; ?>" 
                                   class="btn btn-outline-danger" 
                                   onclick="return confirm('Yakin ingin menghapus barang ini?')" title="Hapus">
                                    <i class="fas fa-trash"></i>
                                </a>
                                <button type="button" class="btn btn-outline-info" 
                                        data-bs-toggle="tooltip" title="ID: <?php echo $item['id_barang']; ?>">
                                    <i class="fas fa-info-circle"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Pagination -->
        <?php if($totalPages > 1): ?>
        <nav aria-label="Page navigation" class="mt-4">
            <ul class="pagination justify-content-center">
                <?php if($page > 1): ?>
                <li class="page-item">
                    <a class="page-link" href="?page=<?php echo $page-1; ?>&search=<?php echo urlencode($search); ?>">
                        <i class="fas fa-chevron-left me-1"></i>Sebelumnya
                    </a>
                </li>
                <?php else: ?>
                <li class="page-item disabled">
                    <span class="page-link">
                        <i class="fas fa-chevron-left me-1"></i>Sebelumnya
                    </span>
                </li>
                <?php endif; ?>
                
                <?php 
                $startPage = max(1, $page - 2);
                $endPage = min($totalPages, $page + 2);
                
                for($i = $startPage; $i <= $endPage; $i++): 
                ?>
                <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>">
                        <?php echo $i; ?>
                    </a>
                </li>
                <?php endfor; ?>
                
                <?php if($page < $totalPages): ?>
                <li class="page-item">
                    <a class="page-link" href="?page=<?php echo $page+1; ?>&search=<?php echo urlencode($search); ?>">
                        Selanjutnya<i class="fas fa-chevron-right ms-1"></i>
                    </a>
                </li>
                <?php else: ?>
                <li class="page-item disabled">
                    <span class="page-link">
                        Selanjutnya<i class="fas fa-chevron-right ms-1"></i>
                    </span>
                </li>
                <?php endif; ?>
            </ul>
            <p class="text-center text-muted small mt-2">
                Menampilkan <?php echo min($limit, count($barang)); ?> dari <?php echo $totalRecords; ?> barang
            </p>
        </nav>
        <?php endif; ?>
    </div>
</div>

<?php
$content = ob_get_clean();

// INCLUDE HEADER SAJA - sudah lengkap
include '../views/default/header.php';
?>