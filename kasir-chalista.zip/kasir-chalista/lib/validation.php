<?php
class Validation {
    
    public static function required($fields) {
        foreach ($fields as $field => $value) {
            if (empty(trim($value))) {
                return "$field tidak boleh kosong";
            }
        }
        return true;
    }
    
    public static function email($email) {
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return "Format email tidak valid";
        }
        return true;
    }
    
    public static function numeric($value, $field) {
        if (!is_numeric($value)) {
            return "$field harus berupa angka";
        }
        return true;
    }
    
    public static function positiveNumber($value, $field) {
        if (!is_numeric($value) || $value < 0) {
            return "$field harus angka positif";
        }
        return true;
    }
    
    public static function minLength($value, $min, $field) {
        if (strlen(trim($value)) < $min) {
            return "$field minimal $min karakter";
        }
        return true;
    }
    
    public static function stockAvailable($db, $id_barang, $qty) {
        $stmt = $db->prepare("SELECT stok FROM barang WHERE id_barang = ?");
        $stmt->bind_param("i", $id_barang);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        
        if (!$result) {
            return "Barang tidak ditemukan";
        }
        
        if ($result['stok'] < $qty) {
            return "Stok tidak mencukupi. Stok tersedia: " . $result['stok'];
        }
        
        return true;
    }
    
    public static function paymentAmount($total, $bayar, $status) {
        if ($status == 'LUNAS' && $bayar < $total) {
            return "Pembayaran kurang dari total transaksi";
        }
        
        if ($bayar < 0) {
            return "Jumlah bayar tidak valid";
        }
        
        return true;
    }
    
    public static function sanitize($input) {
        if (is_array($input)) {
            return array_map([self::class, 'sanitize'], $input);
        }
        
        $input = trim($input);
        $input = stripslashes($input);
        $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
        
        return $input;
    }
}
?>