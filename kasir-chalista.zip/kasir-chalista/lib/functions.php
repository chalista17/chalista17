<?php
session_start();
require_once __DIR__ . '/../config/database.php';

function getMenu($role = 'admin') {
    $menuFile = __DIR__ . '/../config/menu.json';
    if (file_exists($menuFile)) {
        $menus = json_decode(file_get_contents($menuFile), true);
        return $menus[$role] ?? [];
    }
    return [];
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function redirect($url) {
    header("Location: $url");
    exit();
}

function flash($name, $message = '', $class = 'alert alert-success') {
    if (!empty($message)) {
        $_SESSION[$name] = ['message' => $message, 'class' => $class];
    } elseif (isset($_SESSION[$name])) {
        $flash = $_SESSION[$name];
        unset($_SESSION[$name]);
        return $flash;
    }
    return null;
}

function formatRupiah($angka) {
    return CURRENCY_SYMBOL . ' ' . number_format($angka, 0, ',', '.');
}

function getCurrentPage() {
    $page = basename($_SERVER['PHP_SELF']);
    return $page;
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function requireAdmin() {
    if (!isAdmin()) {
        flash('flash_message', 'Akses ditolak. Hanya admin yang dapat mengakses halaman ini.', 'alert alert-danger');
        redirect('index.php');
    }
}

function generateInvoiceNumber() {
    $prefix = 'INV';
    $date = date('ymd');
    $random = strtoupper(substr(md5(uniqid()), 0, 4));
    
    return $prefix . '-' . $date . '-' . $random;
}

function getDayName($date) {
    $days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    $day_index = date('w', strtotime($date));
    
    return $days[$day_index];
}

function calculateAge($birth_date) {
    $birthday = new DateTime($birth_date);
    $today = new DateTime('today');
    $age = $today->diff($birthday)->y;
    
    return $age;
}

// Simple validation functions
function validateRequired($fields) {
    foreach ($fields as $field => $value) {
        if (empty(trim($value))) {
            return "$field tidak boleh kosong";
        }
    }
    return true;
}

function validateNumeric($value, $field) {
    if (!is_numeric($value)) {
        return "$field harus berupa angka";
    }
    return true;
}

function validatePositiveNumber($value, $field) {
    if (!is_numeric($value) || $value < 0) {
        return "$field harus angka positif";
    }
    return true;
}

function sanitizeInput($input) {
    if (is_array($input)) {
        return array_map('sanitizeInput', $input);
    }
    
    $input = trim($input);
    $input = stripslashes($input);
    $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
    
    return $input;
}

function checkStockAvailable($db, $id_barang, $qty) {
    $stmt = $db->prepare("SELECT stok FROM barang WHERE id_barang = ?");
    $stmt->bind_param("i", $id_barang);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    
    if (!$result) {
        return "Barang tidak ditemukan";
    }
    
    if ($result['stok'] < $qty) {
        return "Stok tidak mencukupi. Stok tersedia: " . $result['stok'];
    }
    
    return true;
}

function validatePayment($total, $bayar, $status) {
    if ($status == 'LUNAS' && $bayar < $total) {
        return "Pembayaran kurang dari total transaksi";
    }
    
    if ($bayar < 0) {
        return "Jumlah bayar tidak valid";
    }
    
    return true;
}

function getStatusBadge($status) {
    $badge_class = $status == 'LUNAS' ? 'success' : 'warning';
    return '<span class="badge bg-' . $badge_class . '">' . $status . '</span>';
}

function getPaymentBadge($method) {
    $badge_class = 'info';
    if ($method == 'CASH') {
        $badge_class = 'primary';
    } elseif ($method == 'TRANSFER') {
        $badge_class = 'success';
    } elseif ($method == 'QRIS') {
        $badge_class = 'dark';
    }
    return '<span class="badge bg-' . $badge_class . '">' . $method . '</span>';
}

function getStockBadge($stok) {
    if ($stok <= 3) {
        $class = 'danger';
    } elseif ($stok <= 10) {
        $class = 'warning';
    } else {
        $class = 'success';
    }
    return '<span class="badge bg-' . $class . '">' . $stok . ' pcs</span>';
}
?>