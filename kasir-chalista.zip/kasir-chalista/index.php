<?php
require_once 'lib/auth.php';
require_once 'lib/functions.php';

$auth = new Auth();
$auth->checkAuth();

redirect('admin/index.php');
?>