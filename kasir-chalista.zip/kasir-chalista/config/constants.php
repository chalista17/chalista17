<?php
// Application Constants
define('APP_NAME', 'Kasir Chalista Hijab');
define('APP_VERSION', '1.0.0');
define('APP_URL', 'http://localhost/kasir_chalista');

// Database Constants (from your provided database)
define('DB_HOST', 'localhost');
define('DB_NAME', 'kasir_chalista');
define('DB_USER', 'root');
define('DB_PASS', '');

// Session Constants
define('SESSION_TIMEOUT', 7200); // 2 hours in seconds

// File Constants
define('MAX_FILE_SIZE', 5242880); // 5MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif']);

// Pagination Constants
define('ITEMS_PER_PAGE', 10);

// Currency Constants
define('CURRENCY', 'IDR');
define('CURRENCY_SYMBOL', 'Rp');

// Date Format Constants
define('DATE_FORMAT', 'd/m/Y');
define('DATETIME_FORMAT', 'd/m/Y H:i:s');

// Security Constants
define('PASSWORD_MIN_LENGTH', 6);
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCKOUT_TIME', 900); // 15 minutes in seconds

// Status Constants
define('STATUS_ACTIVE', 1);
define('STATUS_INACTIVE', 0);

// Payment Constants (from your database enum values)
define('PAYMENT_CASH', 'CASH');
define('PAYMENT_TRANSFER', 'TRANSFER');
define('PAYMENT_QRIS', 'QRIS');

// Stock Constants
define('MIN_STOCK_ALERT', 10);
define('CRITICAL_STOCK_ALERT', 3);

// Error Messages
define('ERROR_DB_CONNECTION', 'Koneksi database gagal. Silakan coba lagi.');
define('ERROR_LOGIN_FAILED', 'Username atau password salah.');
define('ERROR_UNAUTHORIZED', 'Anda tidak memiliki izin untuk mengakses halaman ini.');
define('ERROR_NOT_FOUND', 'Halaman tidak ditemukan.');
define('ERROR_VALIDATION', 'Harap periksa kembali data yang dimasukkan.');

// Success Messages
define('SUCCESS_LOGIN', 'Login berhasil.');
define('SUCCESS_LOGOUT', 'Logout berhasil.');
define('SUCCESS_SAVE', 'Data berhasil disimpan.');
define('SUCCESS_UPDATE', 'Data berhasil diperbarui.');
define('SUCCESS_DELETE', 'Data berhasil dihapus.');

// Default Values
define('DEFAULT_TIMEZONE', 'Asia/Jakarta');
define('DEFAULT_LANGUAGE', 'id_ID');

// Check if running in development
define('IS_DEVELOPMENT', true);

// Set timezone
date_default_timezone_set(DEFAULT_TIMEZONE);

// Error reporting based on environment
if (IS_DEVELOPMENT) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}
?>