<?php
require_once '../lib/auth.php';
require_once '../lib/functions.php';

$auth = new Auth();
$auth->checkAuth();

$db = Database::getInstance()->getConnection();

// Get statistics from existing tables only
$statsSql = "
    SELECT 
        (SELECT COUNT(*) FROM barang) AS total_barang,
        (SELECT COUNT(*) FROM penjualan WHERE DATE(tanggal) = CURDATE()) AS penjualan_hari_ini,
        (SELECT COALESCE(SUM(total),0) FROM penjualan WHERE DATE(tanggal) = CURDATE()) AS total_hari_ini,
        (SELECT COALESCE(SUM(stok),0) FROM barang) AS total_stok,
        (SELECT COUNT(*) FROM users) AS total_users
";


$statsResult = $db->query($statsSql);
$stats = $statsResult->fetch_assoc();

// Get recent transactions
$recentSql = "SELECT p.* FROM penjualan p ORDER BY p.tanggal DESC LIMIT 5";
$recentResult = $db->query($recentSql);
$recentTransactions = $recentResult->fetch_all(MYSQLI_ASSOC);

// Get low stock items
$lowStockSql = "SELECT * FROM barang WHERE stok <= 10 ORDER BY stok ASC LIMIT 5";
$lowStockResult = $db->query($lowStockSql);
$lowStockItems = $lowStockResult->fetch_all(MYSQLI_ASSOC);

// Get daily sales for chart (last 7 days)
$dailySalesSql = $dailySalesSql = "
    SELECT 
        d.tanggal,
        COALESCE(SUM(p.total), 0) AS total,
        COALESCE(COUNT(p.id_penjualan), 0) AS transactions
    FROM (
        SELECT CURDATE() - INTERVAL n DAY AS tanggal
        FROM (
            SELECT 0 n UNION ALL SELECT 1 UNION ALL SELECT 2 
            UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6
        ) x
    ) d
    LEFT JOIN penjualan p 
        ON DATE(p.tanggal) = d.tanggal
    GROUP BY d.tanggal
    ORDER BY d.tanggal
";

$dailySalesResult = $db->query($dailySalesSql);
$dailySales = $dailySalesResult->fetch_all(MYSQLI_ASSOC);

// Get weekly sales for comparison
$weeklyComparisonSql = $weeklyComparisonSql = "
    SELECT 
        COALESCE(SUM(CASE 
            WHEN DATE(tanggal) BETWEEN CURDATE() - INTERVAL 6 DAY AND CURDATE()
            THEN total END),0) AS week_1,
        COALESCE(SUM(CASE 
            WHEN DATE(tanggal) BETWEEN CURDATE() - INTERVAL 13 DAY AND CURDATE() - INTERVAL 7 DAY
            THEN total END),0) AS week_2
    FROM penjualan
";

$weeklyResult = $db->query($weeklyComparisonSql);
$weeklyData = $weeklyResult->fetch_assoc();

// Get top selling products
$topProductsSql = "
    SELECT b.nama_barang, SUM(pd.qty) as total_qty, SUM(pd.subtotal) as total_sales
    FROM penjualan_detail pd
    JOIN barang b ON pd.id_barang = b.id_barang
    GROUP BY pd.id_barang
    ORDER BY total_qty DESC
    LIMIT 5
";
$topProductsResult = $db->query($topProductsSql);
$topProducts = $topProductsResult->fetch_all(MYSQLI_ASSOC);

// Prepare chart data
$dates = [];
$amounts = [];
$transactions = [];

foreach ($dailySales as $sale) {
    $dates[] = date('d/m', strtotime($sale['tanggal']));
    $amounts[] = (int)$sale['total'];
    $transactions[] = (int)$sale['transactions'];
}


// Calculate growth percentage
$growth = 0;
if ($weeklyData['week_2'] > 0) {
    $growth = (($weeklyData['week_1'] - $weeklyData['week_2']) / $weeklyData['week_2']) * 100;
}

$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => 'index.php', 'active' => true]
];

$pageTitle = 'Dashboard Admin';

ob_start();
?>

<!-- Spacing Top -->
<div style="height: 30px;"></div>

<!-- Welcome Header -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card border-0 bg-light">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h4 class="mb-2">Selamat Datang, <?php echo isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'Admin'; ?>!</h4>
                        <p class="text-muted mb-0">
                            <i class="fas fa-calendar-alt me-1"></i>
                            <?php echo date('l, d F Y'); ?> | 
                            <i class="fas fa-clock ms-3 me-1"></i>
                            <?php echo date('H:i'); ?>
                        </p>
                    </div>
                    <div class="text-end">
                        <div class="badge bg-success">
                            <i class="fas fa-check-circle me-1"></i>
                            Sistem Online
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Statistic Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-lg-6 mb-4">
        <div class="card stat-card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <h6 class="card-subtitle mb-2 text-muted">Total Barang</h6>
                        <h2 class="card-title mb-0 text-primary"><?php echo $stats['total_barang']; ?></h2>
                        <small class="text-muted">item tersedia</small>
                    </div>
                    <div class="bg-primary bg-opacity-10 rounded-circle p-3">
                        <i class="fas fa-box fa-2x text-primary"></i>
                    </div>
                </div>
                <div class="mt-3">
                    <a href="../barang/index.php" class="btn btn-outline-primary btn-sm w-100">
                        <i class="fas fa-eye me-1"></i>Lihat Semua
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-lg-6 mb-4">
        <div class="card stat-card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <h6 class="card-subtitle mb-2 text-muted">Transaksi Hari Ini</h6>
                        <h2 class="card-title mb-0 text-success"><?php echo $stats['penjualan_hari_ini']; ?></h2>
                        <small class="text-muted">transaksi hari ini</small>
                    </div>
                    <div class="bg-success bg-opacity-10 rounded-circle p-3">
                        <i class="fas fa-shopping-cart fa-2x text-success"></i>
                    </div>
                </div>
                <div class="mt-3">
                    <a href="../penjualan/index.php" class="btn btn-outline-success btn-sm w-100">
                        <i class="fas fa-list me-1"></i>Lihat Transaksi
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-lg-6 mb-4">
        <div class="card stat-card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <h6 class="card-subtitle mb-2 text-muted">Pendapatan Hari Ini</h6>
                        <h2 class="card-title mb-0 text-info"><?php echo formatRupiah($stats['total_hari_ini'] ?? 0); ?></h2>
                        <small class="text-muted">total pendapatan</small>
                    </div>
                    <div class="bg-info bg-opacity-10 rounded-circle p-3">
                        <i class="fas fa-money-bill-wave fa-2x text-info"></i>
                    </div>
                </div>
                <div class="mt-3">
                    <div class="progress" style="height: 6px;">
                        <div class="progress-bar bg-info" role="progressbar" style="width: 75%"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-lg-6 mb-4">
        <div class="card stat-card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <h6 class="card-subtitle mb-2 text-muted">Total Stok</h6>
                        <h2 class="card-title mb-0 text-warning"><?php echo $stats['total_stok']; ?></h2>
                        <small class="text-muted">unit tersedia</small>
                    </div>
                    <div class="bg-warning bg-opacity-10 rounded-circle p-3">
                        <i class="fas fa-layer-group fa-2x text-warning"></i>
                    </div>
                </div>
                <div class="mt-3">
                    <div class="d-flex justify-content-between">
                        <small class="text-muted">Nilai Stok:</small>
                        <small class="fw-bold"><?php 
                            $nilaiSql = "SELECT SUM(harga * stok) as total FROM barang";
                            $nilaiResult = $db->query($nilaiSql);
                            $nilai = $nilaiResult->fetch_assoc()['total'] ?? 0;
                            echo formatRupiah($nilai);
                        ?></small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Main Dashboard Content -->
<div class="row">
    <!-- Sales Chart -->
    <div class="col-lg-8 mb-4">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-white border-0 py-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="mb-1"><i class="fas fa-chart-line text-primary me-2"></i>Analisis Penjualan</h5>
                        <p class="text-muted mb-0 small">Perkembangan penjualan 7 hari terakhir</p>
                    </div>
                    <div class="dropdown">
                        <button class="btn btn-outline-secondary btn-sm dropdown-toggle" type="button" 
                                data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-filter me-1"></i>Filter Periode
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item active" href="#">7 Hari Terakhir</a></li>
                            <li><a class="dropdown-item" href="#">30 Hari Terakhir</a></li>
                            <li><a class="dropdown-item" href="#">Bulan Ini</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="#">Custom Range</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="chart-container" style="position: relative; height: 300px;">
                    <canvas id="salesChart"></canvas>
                </div>
                
                <!-- Chart Statistics -->
                <div class="row mt-4 text-center">
                    <div class="col-md-3 col-6 mb-3">
                        <div class="border rounded p-3">
                            <small class="text-muted d-block">Total 7 Hari</small>
                            <h4 class="text-success mb-0"><?php echo formatRupiah(array_sum($amounts)); ?></h4>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 mb-3">
                        <div class="border rounded p-3">
                            <small class="text-muted d-block">Rata-rata Harian</small>
                            <h4 class="text-primary mb-0">
                                <?php 
                                $avg = count($amounts) ? array_sum($amounts) / 7 : 0;
                                echo formatRupiah($avg);
                                ?>
                            </h4>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 mb-3">
                        <div class="border rounded p-3">
                            <small class="text-muted d-block">Total Transaksi</small>
                            <h4 class="text-info mb-0"><?php echo array_sum($transactions); ?></h4>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 mb-3">
                        <div class="border rounded p-3">
                            <small class="text-muted d-block">Pertumbuhan</small>
                            <h4 class="<?php echo $growth >= 0 ? 'text-success' : 'text-danger'; ?> mb-0">
                                <?php echo number_format($growth, 1); ?>%
                                <i class="fas <?php echo $growth >= 0 ? 'fa-arrow-up' : 'fa-arrow-down'; ?> ms-1"></i>
                            </h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Right Side - Quick Stats & Low Stock -->
    <div class="col-lg-4 mb-4">
        <!-- Low Stock Alert -->
        <div class="card border-start border-danger border-4 shadow-sm mb-4">
            <div class="card-header bg-white border-0 py-3">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="mb-0 text-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i>Stok Menipis
                    </h5>
                    <span class="badge bg-danger"><?php echo count($lowStockItems); ?></span>
                </div>
            </div>
            <div class="card-body">
                <?php if(empty($lowStockItems)): ?>
                    <div class="text-center py-4">
                        <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                        <h6 class="text-success">Semua Stok Aman</h6>
                        <p class="text-muted small mb-0">Tidak ada barang dengan stok rendah</p>
                    </div>
                <?php else: ?>
                    <div class="list-group list-group-flush">
                        <?php foreach($lowStockItems as $item): 
                            $percentage = min(100, ($item['stok']/10)*100);
                        ?>
                        <div class="list-group-item border-0 px-0 py-2">
                            <div class="d-flex justify-content-between align-items-start">
                                <div class="d-flex align-items-center">
                                    <div class="bg-danger bg-opacity-10 rounded-circle p-2 me-3">
                                        <i class="fas fa-box text-danger"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-1"><?php echo htmlspecialchars($item['nama_barang']); ?></h6>
                                        <small class="text-muted">Harga: <?php echo formatRupiah($item['harga']); ?></small>
                                    </div>
                                </div>
                                <div class="text-end">
                                    <?php echo getStockBadge($item['stok']); ?>
                                </div>
                            </div>
                            <div class="mt-2">
                                <div class="d-flex justify-content-between small mb-1">
                                    <span class="text-muted">Stok tersisa</span>
                                    <span class="fw-bold"><?php echo $item['stok']; ?> unit</span>
                                </div>
                                <div class="progress" style="height: 6px;">
                                    <div class="progress-bar bg-danger" role="progressbar" 
                                         style="width: <?php echo $percentage; ?>%">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="text-center mt-3">
                        <a href="../barang/index.php" class="btn btn-outline-danger btn-sm">
                            <i class="fas fa-boxes me-1"></i>Kelola Stok
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Quick Stats -->
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white border-0 py-3">
                <h5 class="mb-0"><i class="fas fa-chart-pie text-info me-2"></i>Statistik Cepat</h5>
            </div>
            <div class="card-body">
                <div class="list-group list-group-flush">
                    <?php
                    // Get monthly sales
                    $monthlySql = "SELECT SUM(total) as total FROM penjualan WHERE MONTH(tanggal) = MONTH(CURDATE())";
                    $monthlyResult = $db->query($monthlySql);
                    $monthlySales = $monthlyResult->fetch_assoc()['total'] ?? 0;
                    
                    // Get pending transactions
                    $pendingSql = "SELECT COUNT(*) as total FROM penjualan WHERE status_bayar = 'BELUM LUNAS'";
                    $pendingResult = $db->query($pendingSql);
                    $pendingCount = $pendingResult->fetch_assoc()['total'];
                    ?>
                    
                    <div class="list-group-item border-0 px-0 py-2">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-calendar-check text-primary me-3"></i>
                                <div>
                                    <small class="d-block text-muted">Penjualan Bulan Ini</small>
                                    <strong class="text-primary"><?php echo formatRupiah($monthlySales); ?></strong>
                                </div>
                            </div>
                            <span class="badge bg-primary"><?php echo date('M'); ?></span>
                        </div>
                    </div>
                    
                    <div class="list-group-item border-0 px-0 py-2">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-clock text-warning me-3"></i>
                                <div>
                                    <small class="d-block text-muted">Menunggu Pembayaran</small>
                                    <strong class="text-warning"><?php echo $pendingCount; ?> transaksi</strong>
                                </div>
                            </div>
                            <a href="../penjualan/index.php?status=BELUM+LUNAS" class="btn btn-sm btn-outline-warning">
                                Cek
                            </a>
                        </div>
                    </div>
                    
                    <div class="list-group-item border-0 px-0 py-2">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-users text-success me-3"></i>
                                <div>
                                    <small class="d-block text-muted">Total Pengguna</small>
                                    <strong class="text-success"><?php echo $stats['total_users']; ?> user</strong>
                                </div>
                            </div>
                            <span class="badge bg-success">Admin</span>
                        </div>
                    </div>
                    
                    <div class="list-group-item border-0 px-0 py-2">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-percentage text-info me-3"></i>
                                <div>
                                    <small class="d-block text-muted">Target Bulanan</small>
                                    <strong class="text-info">75% tercapai</strong>
                                </div>
                            </div>
                            <div class="progress" style="width: 60px; height: 6px;">
                                <div class="progress-bar bg-info" role="progressbar" style="width: 75%"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bottom Row: Recent Transactions & Top Products -->
<div class="row mt-4">
    <!-- Recent Transactions -->
    <div class="col-lg-6 mb-4">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-white border-0 py-3 d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="mb-1"><i class="fas fa-history text-info me-2"></i>Transaksi Terbaru</h5>
                    <p class="text-muted mb-0 small">5 transaksi terakhir</p>
                </div>
                <a href="../penjualan/index.php" class="btn btn-outline-info btn-sm">
                    <i class="fas fa-list me-1"></i>Lihat Semua
                </a>
            </div>
            <div class="card-body">
                <?php if(empty($recentTransactions)): ?>
                    <div class="text-center py-4">
                        <i class="fas fa-shopping-cart fa-3x text-muted mb-3"></i>
                        <h6 class="text-muted">Belum Ada Transaksi</h6>
                        <p class="text-muted small mb-0">Mulai transaksi pertama Anda</p>
                        <a href="../penjualan/add.php" class="btn btn-primary btn-sm mt-2">
                            <i class="fas fa-plus me-1"></i>Transaksi Baru
                        </a>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Waktu</th>
                                    <th class="text-end">Total</th>
                                    <th class="text-center">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($recentTransactions as $transaction): ?>
                                <tr>
                                    <td>
                                        <strong>#<?php echo $transaction['id_penjualan']; ?></strong>
                                    </td>
                                    <td>
                                        <small><?php echo date('d/m H:i', strtotime($transaction['tanggal'])); ?></small>
                                    </td>
                                    <td class="text-end">
                                        <strong><?php echo formatRupiah($transaction['total']); ?></strong>
                                    </td>
                                    <td class="text-center">
                                        <?php echo getStatusBadge($transaction['status_bayar']); ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Top Products -->
    <div class="col-lg-6 mb-4">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-white border-0 py-3 d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="mb-1"><i class="fas fa-trophy text-warning me-2"></i>Produk Terlaris</h5>
                    <p class="text-muted mb-0 small">5 produk terbaik bulan ini</p>
                </div>
                <a href="../barang/index.php" class="btn btn-outline-warning btn-sm">
                    <i class="fas fa-chart-bar me-1"></i>Analisis
                </a>
            </div>
            <div class="card-body">
                <?php if(empty($topProducts)): ?>
                    <div class="text-center py-4">
                        <i class="fas fa-chart-bar fa-3x text-muted mb-3"></i>
                        <h6 class="text-muted">Belum Ada Data</h6>
                        <p class="text-muted small mb-0">Belum ada penjualan produk</p>
                    </div>
                <?php else: ?>
                    <div class="list-group list-group-flush">
                        <?php foreach($topProducts as $index => $product): ?>
                        <div class="list-group-item border-0 px-0 py-3">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="d-flex align-items-center">
                                    <span class="badge bg-warning me-3">#<?php echo $index + 1; ?></span>
                                    <div>
                                        <h6 class="mb-1"><?php echo htmlspecialchars($product['nama_barang']); ?></h6>
                                        <small class="text-muted">Terjual: <?php echo $product['total_qty']; ?> unit</small>
                                    </div>
                                </div>
                                <div class="text-end">
                                    <div class="fw-bold text-success"><?php echo formatRupiah($product['total_sales']); ?></div>
                                    <small class="text-muted">Pendapatan</small>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="row mt-4">
    <div class="col-12">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white border-0 py-3">
                <h5 class="mb-0"><i class="fas fa-bolt text-success me-2"></i>Aksi Cepat</h5>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-xl-3 col-md-6">
                        <a href="../penjualan/add.php" class="btn btn-success w-100 h-100 d-flex flex-column align-items-center justify-content-center py-4 border-0 rounded-3 shadow-sm">
                            <div class="bg-success bg-opacity-10 rounded-circle p-3 mb-3">
                                <i class="fas fa-cash-register fa-2x text-success"></i>
                            </div>
                            <h6 class="mb-1">Transaksi Baru</h6>
                            <small class="opacity-75">Mulai transaksi baru</small>
                        </a>
                    </div>
                    <div class="col-xl-3 col-md-6">
                        <a href="../barang/add.php" class="btn btn-primary w-100 h-100 d-flex flex-column align-items-center justify-content-center py-4 border-0 rounded-3 shadow-sm">
                            <div class="bg-primary bg-opacity-10 rounded-circle p-3 mb-3">
                                <i class="fas fa-plus fa-2x text-primary"></i>
                            </div>
                            <h6 class="mb-1">Tambah Barang</h6>
                            <small class="opacity-75">Tambah produk baru</small>
                        </a>
                    </div>
                    <div class="col-xl-3 col-md-6">
                        <a href="../penjualan/index.php?status=BELUM+LUNAS" class="btn btn-warning w-100 h-100 d-flex flex-column align-items-center justify-content-center py-4 border-0 rounded-3 shadow-sm">
                            <div class="bg-warning bg-opacity-10 rounded-circle p-3 mb-3">
                                <i class="fas fa-clock fa-2x text-warning"></i>
                            </div>
                            <h6 class="mb-1">Belum Lunas</h6>
                            <small class="opacity-75">Cek transaksi tertunda</small>
                        </a>
                    </div>
                    <div class="col-xl-3 col-md-6">
                        <a href="../barang/index.php" class="btn btn-info w-100 h-100 d-flex flex-column align-items-center justify-content-center py-4 border-0 rounded-3 shadow-sm">
                            <div class="bg-info bg-opacity-10 rounded-circle p-3 mb-3">
                                <i class="fas fa-boxes fa-2x text-info"></i>
                            </div>
                            <h6 class="mb-1">Stok Barang</h6>
                            <small class="opacity-75">Kelola inventori</small>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Chart Script -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const salesChart = document.getElementById('salesChart');
    if (salesChart) {
        const ctx = salesChart.getContext('2d');
        const chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($dates); ?>,
                datasets: [{
                    label: 'Pendapatan (Rp)',
                    data: <?php echo json_encode($amounts); ?>,
                    backgroundColor: 'rgba(111, 66, 193, 0.1)',
                    borderColor: 'rgba(111, 66, 193, 1)',
                    borderWidth: 3,
                    tension: 0.4,
                    fill: true,
                    pointBackgroundColor: 'rgba(111, 66, 193, 1)',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 5,
                    pointHoverRadius: 7
                }, {
                    label: 'Jumlah Transaksi',
                    data: <?php echo json_encode($transactions); ?>,
                    backgroundColor: 'rgba(40, 167, 69, 0.1)',
                    borderColor: 'rgba(40, 167, 69, 1)',
                    borderWidth: 2,
                    tension: 0.4,
                    fill: false,
                    borderDash: [5, 5],
                    pointBackgroundColor: 'rgba(40, 167, 69, 1)',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 4,
                    yAxisID: 'y1'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top',
                        labels: {
                            color: '#495057',
                            font: {
                                size: 12,
                                family: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
                            },
                            padding: 20
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: '#fff',
                        bodyColor: '#fff',
                        borderColor: 'rgba(255, 255, 255, 0.1)',
                        borderWidth: 1,
                        padding: 12,
                        cornerRadius: 8,
                        callbacks: {
                            label: function(context) {
                                if (context.dataset.label === 'Pendapatan (Rp)') {
                                    return 'Pendapatan: Rp ' + context.raw.toLocaleString('id-ID');
                                } else {
                                    return 'Transaksi: ' + context.raw + ' kali';
                                }
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: true,
                            color: 'rgba(0, 0, 0, 0.05)'
                        },
                        ticks: {
                            color: '#6c757d',
                            font: {
                                size: 11
                            }
                        }
                    },
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        },
                        ticks: {
                            color: '#6c757d',
                            callback: function(value) {
                                if (value >= 1000000) {
                                    return 'Rp ' + (value / 1000000).toFixed(1) + ' jt';
                                } else if (value >= 1000) {
                                    return 'Rp ' + (value / 1000).toFixed(0) + ' rb';
                                }
                                return 'Rp ' + value;
                            }
                        },
                        title: {
                            display: true,
                            text: 'Pendapatan (Rp)',
                            color: '#6c757d'
                        }
                    },
                    y1: {
                        beginAtZero: true,
                        position: 'right',
                        grid: {
                            drawOnChartArea: false,
                        },
                        ticks: {
                            color: '#28a745',
                            callback: function(value) {
                                return value + ' transaksi';
                            }
                        },
                        title: {
                            display: true,
                            text: 'Jumlah Transaksi',
                            color: '#28a745'
                        }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                }
            }
        });
    }
});
</script>

<?php
$content = ob_get_clean();
include '../views/default/header.php';
?>