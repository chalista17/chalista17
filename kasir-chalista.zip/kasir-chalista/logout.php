<?php
require_once 'lib/auth.php';

$auth = new Auth();
$auth->logout();
?>